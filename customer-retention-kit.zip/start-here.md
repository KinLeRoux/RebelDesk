---
type: note
title: Start here — Customer retention & success kit
category: Customer retention kit
tags: retention, start, kit
searchable: true
---

# Start here — Customer retention & success kit

This kit helps you **keep customers longer**: support standards, onboarding, health checks, churn saves, retention KPIs, and practical tools.

## Fastest path

1. In DeskMemory, open **Memory packs** → install **Customer retention & success kit**.
2. Tap **Start in chat** → press **Send**.
3. Pick a mode on the coach (snapshot, support & onboarding, health & churn, operations, tech stack).

## What you get

- **customer-retention-coach.md** — menu of modes (retention-first, support included).
- **reference-customer-retention-guide.md** — support, churn/health, tech stack.
- **Output templates** — filled as you work; they become your living retention playbook.

## Tip

If you already use **Business operations kit** for client onboarding, install both — Start in chat can attach your filled onboarding note when it exists.
