---
type: note
title: Retention operations — output template
category: Customer retention kit
tags: kpi, communication, voice of customer, output
searchable: true
---

# Retention operations — output template

_Combined retention KPIs, customer communications, and voice-of-customer rhythm._

## Review cadence (weekly / monthly)

## Metrics we track

| Metric | Definition (plain) | Target | Source (where number lives) | Owner |
| ------ | ------------------ | ------ | --------------------------- | ----- |
| Logo churn % | | [TBD] | | |
| Revenue churn / GRR / NRR | | [TBD] | | |
| Renewal rate | | [TBD] | | |
| CSAT | | [TBD] | | |
| NPS | | [TBD] | | |
| Time to first value | | [TBD] | | |
| Silent churn (inactive) | | [TBD] | | |

## Last period actuals

| Metric | Value | vs target |
| ------ | ----- | --------- |
| | | |

## One systemic fix this period

## Expansion plays (optional)

---

## Customer communications

### Situation

### Tone constraints

### Template A — subject + body

**Subject:**

**Body:**

### Template B — subject + body

**Subject:**

**Body:**

### Template C — subject + body

**Subject:**

**Body:**

### Before-send checklist

- [ ] Facts correct
- [ ] Next step and date clear
- [ ] Matches brand voice

---

## Voice of customer

### Decisions we need feedback for

### How we collect feedback today

### Rhythm

| Activity | Frequency | Owner | Tool |
| -------- | --------- | ----- | ---- |
| Short pulse / CSAT | | | |
| NPS or satisfaction survey | | | |
| Customer interviews | | | |
| Review mining (public reviews) | | | |

### Survey questions (max 5)

1.
2.
3.

### Closing the loop (how customers hear we acted)

### Backlog — top 3 themes → actions

| Theme | Action | Status |
| ----- | ------ | ------ |
| | | |
