---
type: note
title: Support & onboarding — output template
category: Customer retention kit
tags: support, onboarding, playbook, output
searchable: true
---

# Support & onboarding — output template

_Combined support playbook and customer onboarding success plan._

## Channels we support

## Hours & response targets

| Severity | First response | Resolution target |
| -------- | -------------- | ----------------- |
| Urgent | | |
| Normal | | |
| Low | | |

## Tone rules

## Top FAQs (answer bullets)

1.
2.
3.
4.
5.

## Macro snippets

## Escalation (when to involve owner)

## Weekly ticket review (15 min)

- [ ] Top 3 themes
- [ ] One FAQ or process update

---

## Onboarding success

### First value (what "win" looks like)

### Typical time to first value

### Day 1 — customer checklist

- [ ]

### Week 1 — customer checklist

- [ ]

### Day 30 — customer checklist

- [ ]

### Internal checklist (our team)

- [ ]

### Check-in cadence

| When | Channel | Purpose |
| ---- | ------- | ------- |
| | | |

### Stuck points we watch for
