---
type: note
title: Retention health snapshot — output template
category: Customer retention kit
tags: retention, snapshot, output
searchable: true
---

# Retention health snapshot — output template

_Filled in by the Customer retention coach (Mode 0)._

## Business model

## Rough customer count

## How we know when someone leaves

## Clarity scores (1–5)

| Area | Score | Note |
| ---- | ----- | ---- |
| Onboarding / first value | | |
| Support responsiveness | | |
| Proactive check-ins | | |
| Measurement (KPIs) | | |

## Top 3 retention risks

1.
2.
3.

## One action this week

## Expansion / loyalty notes (optional)
