---
type: note
title: Customer retention guide (reference)
category: Customer retention kit
tags: retention, support, churn, health, tech, reference
searchable: true
---

# Customer retention guide (reference)

One guide for the **Customer retention coach** — support, churn/health, and retention tech.

## Part A — Support and service excellence

How small teams deliver reliable support without enterprise bureaucracy.

### Principles

- **Speed + clarity** beat perfect prose. Acknowledge fast, solve next.
- **One owner** per ticket until closed (even if others help).
- **Document answers** that repeat — future you saves hours.
- **Tone:** calm, accountable, no blame toward the customer.

### Channels (pick what you can sustain)

| Channel | Best for | Risk if understaffed |
| ------- | -------- | -------------------- |
| Email | Async B2B, attachments | Inbox dread, slow SLA |
| Chat widget | Quick questions | Always-on expectation |
| Phone | High-trust services | No paper trail unless noted |
| Help center / FAQ | Deflect repeat questions | Stale articles erode trust |
| Social DM | Consumer brands | Public complaints |

### Response-time targets (SMB realistic)

| Tier | First response | Resolution goal |
| ---- | -------------- | ----------------- |
| Urgent (down, payment failed) | Same business day | 24–48 h |
| Normal | 1 business day | 3–5 days |
| Low | 2–3 days | When scheduled |

State targets **on your website or welcome email** so expectations match reality.

### Ticket lifecycle (simple)

1. **Intake** — who, what product, severity.
2. **Triage** — bug vs how-to vs billing vs complaint.
3. **Work** — one owner researches and acts.
4. **Close** — confirm with customer; tag for FAQ if repeat.
5. **Review weekly** — top themes, one process fix.

### Escalation ladder

1. Front-line (you or VA) — macros + FAQ.
2. Specialist — technical or billing depth.
3. Owner — refunds, legal tone, VIP save.
4. **Stop** — harassment, threats, out-of-scope; polite boundary.

### Macros (patterns, not scripts)

- **Acknowledge:** "Thanks for flagging this — I'm looking into it and will update you by [day]."
- **Need info:** "To fix this I need [X] — can you send by [date]?"
- **Resolved:** "Here's what we did … Does that cover it?"
- **Apology (no over-promising):** "That wasn't the experience we want — here's the next step …"

### CSAT (one question)

After resolved ticket: "How easy was it to get help?" (1–5). Track monthly average; investigate any score of 1–2.

Bad support is a **leading churn driver**. Fixing top 3 ticket themes often beats discounting at renewal.

## Part B — Retention, churn, and customer health

Plain-language retention science for owners who are not data teams.

### Why retention beats only new sales

- Keeping a customer usually costs **less** than acquiring a replacement.
- Happy customers **refer** and buy more.
- Churn is often **fixable** with onboarding, support, or product fixes — not price alone.

### Types of churn

| Type | Meaning | Example signal |
| ---- | ------- | -------------- |
| **Logo churn** | Customer leaves entirely | Cancelled subscription |
| **Revenue churn** | Paying less | Downgrade, fewer seats |
| **Silent churn** | Stops using but still pays | No login 90 days |
| **Involuntary** | Payment failed | Card expired |
| **Competitive** | Switched vendor | "We went with X" |

Track **why** when you learn it (exit interview or short form).

### Leading vs lagging indicators

**Lagging** — you already lost them: churn rate, cancelled contracts.

**Leading** — act before cancel:

- Usage drop (logins, orders, projects opened)
- Support spike or **zero** contact (ghosting)
- Late payments, disputed invoices
- NPS/CSAT drop
- Champion left the company (B2B)
- Missed onboarding milestones

### Customer health score (DIY)

Pick **5–7 signals** you can observe without a data warehouse:

| Signal | Green | Amber | Red |
| ------ | ----- | ----- | --- |
| Product usage | Weekly active | Monthly only | None 30+ days |
| Support sentiment | Positive/neutral | Frustrated ticket | Escalation / threat to leave |
| Payment | On time | 1 late | Stopped / disputed |
| Relationship | Replies < 48h | Slow replies | Ghosting |
| Outcomes | Hitting goals | Stalled | Says "not working" |

**Score:** count red = 2, amber = 1. Review **reds weekly**, ambers biweekly.

### Core retention KPIs (define before targeting)

| Metric | Plain definition | Notes |
| ------ | ---------------- | ----- |
| **Customer churn rate** | % customers lost in period | Logo churn |
| **Revenue churn** | % MRR/ARR lost | Subscriptions |
| **GRR** | Retained revenue without expansion | ≤ 100% |
| **NRR** | Retained + expansion − churn | > 100% is healthy SaaS |
| **Retention rate** | 100% − churn (same period) | |
| **NPS** | "Recommend 0–10?" promoters − detractors | Quarterly max for tiny teams |
| **CSAT** | Satisfaction after interaction | Per ticket |
| **Time to first value** | First meaningful win | Onboarding KPI |
| **Renewal rate** | % contracts renewed | B2B annual |

Use **one review rhythm** (e.g. monthly 30-min): update numbers, pick **one** systemic fix.

### Churn prevention playbook (pattern)

1. **Detect early** — health score amber 2+ weeks.
2. **Human outreach** — curious call, not defensive.
3. **Diagnose** — fit, value, service, price, timing.
4. **Offer path** — training, plan change, pause, credit (last resort).
5. **Learn** — tag reason; fix product/process if repeated.

### Anti-patterns

- Discounting every renewal without fixing cause.
- Measuring only "tickets closed."
- No owner for at-risk list.
- Surveys with no **closed loop** ("we heard you, we did X").

## Part C — Retention tech and automation

Tool categories that reduce churn — without buying a stack you won't maintain.

### Stack layers (what each layer does)

| Layer | Job | If missing, churn risk |
| ----- | --- | ---------------------- |
| **CRM / customer record** | Who they are, deal stage, notes | Forgotten renewals, no history |
| **Helpdesk** | Tickets, SLAs, macros | Lost emails, slow replies |
| **Product analytics** | Usage, feature adoption | Silent churn |
| **Email / lifecycle** | Onboarding drips, renewals | Weak first 30 days |
| **Billing** | Subscriptions, dunning | Involuntary churn |
| **Surveys** | NPS, CSAT | Blind to sentiment |
| **Knowledge base** | Self-serve FAQ | Repeat ticket load |

You do **not** need all layers on day one. Add when pain is weekly.

### Automation that actually helps retention

| Automation | Benefit | Caution |
| ---------- | ------- | ------- |
| Onboarding drip | Faster time-to-value | Not spammy |
| Inactivity alert (internal) | Catch silent churn | Tune thresholds |
| Renewal reminder 30/14/7 days | Fewer accidental lapses | Personalize |
| Failed payment retry | Saves involuntary churn | Comply with card rules |
| Post-ticket CSAT | Measure support | Only after resolved |
| NPS follow-up to detractors | Save at-risk | Owner must act |

### When to defer buying

- Fewer than ~20 paying customers — spreadsheet + discipline may win.
- Churn reasons unknown — fix interviews before buying "AI churn prediction."

### Retention review ritual (tech-enabled)

Monthly: export cancel reasons + health reds → one product fix + one support fix + one comms fix.
