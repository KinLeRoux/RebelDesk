---
type: note
title: My retention worksheet
category: Customer retention kit
tags: retention, worksheet, scratch
searchable: true
---

# My retention worksheet

Scratch space during coach sessions. The coach may skip questions you already answered here.

## Business

## Customer type (B2B / B2C / mix)

## Top retention worry right now

## Notes
