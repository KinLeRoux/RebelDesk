---
type: note
title: Account health & churn — output template
category: Customer retention kit
tags: health score, churn, save, output
searchable: true
---

# Account health & churn — output template

_Combined account health scorecard and churn risk save plan._

## Health signals (5–7)

| Signal | Green | Amber | Red | Weight |
| ------ | ----- | ----- | --- | ------ |
| | | | | |
| | | | | |

## Scoring rule

## Accounts — green

| Account | Last check | Note |
| ------- | ---------- | ---- |
| | | |

## Accounts — amber

| Account | Why amber | Next action | Owner |
| ------- | --------- | ----------- | ----- |
| | | | |

## Accounts — red

| Account | Why red | Save plan started? | Owner |
| ------- | ------- | ------------------ | ----- |
| | | | |

## Weekly review ritual (15 min)

---

## At-risk customer or segment

## Warning signs

## Last contact

## What they still value

## Likely root cause (validate on call)

## Save playbook

| Step | Action | By when | Owner |
| ---- | ------ | ------- | ----- |
| 1 | Outreach (curious, not defensive) | | |
| 2 | Listen / diagnose | | |
| 3 | Offer path (training, plan, pause — not default discount) | | |
| 4 | Confirm in writing | | |

## Call / meeting bullets

## What we will not offer (boundaries)

## Outcome

## Lesson for product or process
