---
type: note
title: Retention tech stack — output template
category: Customer retention kit
tags: tools, crm, helpdesk, output
searchable: true
---

# Retention tech stack — output template

_Filled in by the Customer retention coach (Mode 8)._

## Budget band

## Current tools

| Layer | Tool | Works? (Y/N) | Pain |
| ----- | ---- | ------------ | ---- |
| CRM / customer record | | | |
| Helpdesk | | | |
| Email / lifecycle | | | |
| Billing / subscriptions | | | |
| Surveys | | | |
| Product usage | | | |
| Knowledge base | | | |

## Gaps hurting retention

## One integration or purchase priority

## Defer until later (avoid stack bloat)

## Admin time budget (hours/month)
