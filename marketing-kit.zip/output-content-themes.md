---
type: note
title: Content themes — output template
category: Marketing kit
tags: content, calendar, output
searchable: true
---

# 90-day content themes — output template

_Filled in by the Marketing kit coach (Mode 5)._

## Content pillars (3–5)

1.
2.
3.

## Audience reminder

## Rhythm

**Email:**

**Social:**

**Blog / long form:**

## Seasonal or event hooks

| When | Theme |
| ---- | ----- |
| | |

## 10 starter topics

| # | Topic | Pillar | Format |
| - | ----- | ------ | ------ |
| 1 | | | |
| 2 | | | |

## Repurpose rule

_One idea → how many formats:_
