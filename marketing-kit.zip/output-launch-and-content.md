---
type: note
title: Launch & content plan — output template
category: Marketing kit
tags: launch, content, calendar, output
searchable: true
---

# Launch & content plan — output template

_Filled by the Marketing kit coach (Mode 4). Launch checklist and 90-day content themes together._

## Launch summary

**What launches:** · **Date:** · **Primary goal:**

## Pre-launch

- [ ] Offer narrative / pricing confirmed
- [ ] Landing page or sales page live
- [ ] Email to list scheduled
- [ ] Social posts drafted
- [ ] Assets (images, video) ready
- [ ] Team / partners briefed
- [ ] Support FAQs ready

## Launch week

| Day | Task | Owner |
| --- | ---- | ----- |
| | | |

## Post-launch

- [ ] Thank-you / nurture sequence
- [ ] Metrics reviewed
- [ ] Feedback collected
- [ ] Iterate message for round 2

**Metrics to watch:**

---

## Content pillars (3–5)

1. · 2. · 3.

**Audience reminder:**

### Rhythm

**Email:** · **Social:** · **Blog / long form:**

### Seasonal or event hooks

| When | Theme |
| ---- | ----- |
| | |

### 10 starter topics

| # | Topic | Pillar | Format |
| - | ----- | ------ | ------ |
| 1 | | | |
| 2 | | | |

**Repurpose rule:** _One idea → how many formats:_
