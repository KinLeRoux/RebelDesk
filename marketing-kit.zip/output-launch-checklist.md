---
type: note
title: Launch checklist — output template
category: Marketing kit
tags: launch, checklist, output
searchable: true
---

# Launch checklist — output template

_Filled in by the Marketing kit coach (Mode 4)._

## Launch summary

**What launches:**

**Date:**

**Primary goal:**

## Pre-launch

- [ ] Offer narrative / pricing confirmed
- [ ] Landing page or sales page live
- [ ] Email to list scheduled
- [ ] Social posts drafted
- [ ] Assets (images, video) ready
- [ ] Team / partners briefed
- [ ] Support FAQs ready

## Launch week

| Day | Task | Owner |
| --- | ---- | ----- |
| | | |

## Post-launch

- [ ] Thank-you / nurture sequence
- [ ] Metrics reviewed
- [ ] Feedback collected
- [ ] Iterate message for round 2

## Metrics to watch
