---
type: note
title: Offer narrative — output template
category: Marketing kit
tags: offer, sales, output
searchable: true
---

# Offer narrative — output template

_Filled in by the Marketing kit coach (Mode 3)._

## Offer in one sentence

## What’s included

## Transformation (before → after)

## Why the price is fair

**Price / model:**

**Gain frame:**

**Risk reversal / guarantee:**

## Proof

## Top 5 objections + answers

| Objection | Response |
| --------- | -------- |
| | |

## FAQ (short)

## CTA

## Ethical check

_Only claims we can prove:_
