---
type: note
title: Psychology of sales (reference)
category: Marketing kit
tags: sales, psychology, marketing, reference
searchable: true
---

# Psychology of sales (reference)

How buyers change their minds, click, and self-select — for the **Marketing kit coach** or any chat on its own.

## Part 1 — Changing minds (without trickery)

### Framing
- **Gain frame:** “Save 5 hours a week.”
- **Loss frame:** “Stop losing 5 hours a week.”  
Pick based on audience (risk-averse often respond to loss; aspirational to gain).

### Reframing the problem
Shift from price to outcome: “Not a $200 expense — a tool that pays for itself in 30 days.”

### Cognitive dissonance
Highlight gap between where they are and where they want to be — then offer the bridge.

### Identity & story
Sell the **person they want to become**, not a feature list. Mini stories beat bullet dumps.

### Presuppositions
“When you’ve doubled leads…” assumes success and focuses on how, not if.

---

## Part 2 — Wow & contrast

- **Peak-end rule:** One memorable high point + strong finish (onboarding surprise, fast reply).
- **Before/after:** Show transformation clearly — sliders, stories, numbers.
- **Authentic scarcity:** Limited access to *you* or *quality* (mentorship caps), not fake timers.

---

## Part 3 — Getting the click (CTA psychology)

- **First person:** “Start my free trial” vs “Start your…”
- **Benefit verb:** “Get the blueprint” vs “Download PDF”
- **Risk reversal:** “Reserve my spot — no charge until approved”
- **Micro-commitments:** Small yes steps before the big ask (foot-in-the-door)
- **Visual path:** Problem → agitate → solution → benefit → button

---

## Part 4 — Right customers (quality over volume)

### Awareness stages
| Stage | They need |
| ----- | ----------- |
| Problem-unaware | Education, not hard pitch |
| Problem-aware | Options, validation |
| Solution-aware | Comparison, proof |
| Most-aware | Risk removal, clear CTA |

Match message to stage — do not pitch a demo to someone still defining the problem.

### Psychographics over demographics
Values, triggers (urgency vs innovation), language they use in reviews and forums.

---

## Prompts to use alone

- “Frame this offer for risk-averse small business owners.”
- “Write three CTA variants with different emotional drivers.”
- “What awareness stage is this audience? Adjust this email.”

Pair with **reference-psychology-of-persuasion.md** and **reference-copywriting-formulas.md**.
