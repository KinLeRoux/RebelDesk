---
type: note
title: My marketing worksheet
category: Marketing kit
tags: marketing, worksheet
searchable: true
---

# My marketing worksheet

Rough notes for the **Marketing kit coach**.

## Business & offer

**What we sell:**

**Price / model:**

## Audience

**Ideal customer:**

**Main pain:**

## Campaign (current)

**Goal:**

**Deadline:**

**Channels:**

## Proof & objections

**Proof we have:**

**Top objections:**

## Session log

| Date | Mode | Done? |
| ---- | ---- | ----- |
| | | |
