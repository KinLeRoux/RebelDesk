---
type: note
title: Psychology of persuasion (reference)
category: Marketing kit
tags: persuasion, cialdini, marketing, reference
searchable: true
---

# Psychology of persuasion (reference)

Based on Robert Cialdini’s seven principles — use with the **Marketing kit coach** or attach alone when rewriting copy.

## Why it matters

Buyers decide with emotion and justify with logic. These triggers nudge toward “yes” when used **honestly** (real proof, real limits).

## The 7 principles

### 1. Reciprocity
Give value first — tip, checklist, audit — then make a fair ask.

### 2. Commitment & consistency
Small “yes” first (quiz, reply, trial); later steps feel natural.

### 3. Social proof
Reviews, logos, numbers, stories — “people like me chose this.”

### 4. Authority
Expertise, data, certifications, press — trust without boasting.

### 5. Liking
Similarity, humour, vulnerability, real faces — sound human.

### 6. Scarcity
Real limits — seats, time, cohort size — not fake countdowns.

### 7. Unity
Shared identity — “for founders,” “for teachers,” tribe language.

## Combine principles

Example email arc: **Reciprocity** (useful tip) → **Social proof** (mini case) → **Scarcity** (genuine deadline).

## Prompts to use alone

- “Rewrite this page using three persuasion principles — don’t name them in the copy.”
- “Why might this ad fail? Analyze through these lenses.”
- “Cold email using authority + liking for skeptical B2B buyers.”

## Ethical rule

If you cannot back a claim with proof, do not fake scarcity or social proof.
