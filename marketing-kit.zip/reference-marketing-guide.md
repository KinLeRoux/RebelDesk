---
type: note
title: Marketing guide (reference)
category: Marketing kit
tags: persuasion, sales, copywriting, marketing, reference
searchable: true
---

# Marketing guide (reference)

One guide for the **Marketing kit coach** — persuasion, buyer psychology, and copy formulas.

## Part A — Persuasion (Cialdini's 7 principles)

Buyers decide with emotion and justify with logic. Use **honestly** — real proof, real limits.

1. **Reciprocity** — give value first, then a fair ask.
2. **Commitment & consistency** — small "yes" first; later steps feel natural.
3. **Social proof** — reviews, logos, numbers — "people like me chose this."
4. **Authority** — expertise, data, certifications — trust without boasting.
5. **Liking** — similarity, humour, vulnerability, real faces.
6. **Scarcity** — real limits (seats, time, cohort) — not fake countdowns.
7. **Unity** — shared identity — "for founders," tribe language.

**Combine:** reciprocity (useful tip) → social proof (mini case) → scarcity (genuine deadline). If you cannot back a claim, do not fake scarcity or proof.

## Part B — Sales psychology

### Framing & reframing
- **Gain frame:** "Save 5 hours a week." · **Loss frame:** "Stop losing 5 hours."
- Reframe price to outcome: "Not a $200 expense — pays for itself in 30 days."
- **Identity & story:** sell the person they want to become, not a feature list.

### Wow & contrast
- **Peak-end rule:** one memorable high point + strong finish.
- **Before/after:** show transformation clearly.
- **Authentic scarcity:** limited access to *you* or *quality*, not fake timers.

### CTA psychology
- First person: "Start my free trial."
- Benefit verb: "Get the blueprint" vs "Download PDF."
- Risk reversal: "Reserve my spot — no charge until approved."
- Micro-commitments before the big ask.

### Awareness stages

| Stage | They need |
| ----- | ----------- |
| Problem-unaware | Education, not hard pitch |
| Problem-aware | Options, validation |
| Solution-aware | Comparison, proof |
| Most-aware | Risk removal, clear CTA |

Match message to stage. Psychographics (values, triggers, language in reviews) beat demographics alone.

## Part C — Copywriting formulas

| Formula | Structure |
| ------- | --------- |
| **PAS** | Problem → agitate → solve |
| **AIDA** | Attention → interest → desire → action |
| **Before–After–Bridge** | Painful now → vivid future → your bridge |
| **4 U's** (headlines) | Useful, urgent, unique, ultra-specific — aim for 3+ |
| **FAB** | Features → advantages → benefits |
| **Star–Story–Solution** | Hero → struggle → resolution |
| **One-sentence** | "If you [do X], you'll get [benefit] in [timeframe] without [pain]." |

**"So what?" test:** after every line, if the answer isn't a sharp benefit, cut or rewrite.

Attach **output-brand-brief.md** or voice guide when you have them. Launch planning → Mode 4 → `output-launch-and-content.md`.
