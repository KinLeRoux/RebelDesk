---
type: note
title: Campaign brief — output template
category: Marketing kit
tags: campaign, brief, output
searchable: true
---

# Campaign brief — output template

_Filled in by the Marketing kit coach (Mode 1)._

## Campaign name

## Goal (one sentence)

## Audience

**Who:**

**What they care about:**

**Awareness stage:** (unaware / problem-aware / solution-aware / ready to buy)

## Offer / action

**What we promote:**

**Primary CTA:**

## Key message

**Must remember:**

**Proof points:**

## Channels

| Channel | Role | Timing |
| ------- | ---- | ------ |
| | | |

## Timeline

**Start:**

**End / launch date:**

**Milestones:**

## Success metric

## Headline options

1.
2.
3.

## Notes / constraints
