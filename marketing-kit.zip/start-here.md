---
type: note
title: Start here — Marketing kit
category: Marketing kit
tags: marketing, kit, start
searchable: true
---

# Marketing kit

Campaigns, offers, launches, and sharper copy — without marketing degree speak.

## Simple path

1. **Settings → Chat Settings → Memory packs** → install **Marketing kit**.
2. Tap **Start in chat**.
3. Press **Send** and choose what you need.

Best after **Brand kit** (your brief attaches automatically when it exists).

## What's inside

| Kind | Use |
| ---- | --- |
| **Marketing kit coach** | Guided interviews and planning |
| **Research** | Marketing guide (persuasion, sales psychology, copy formulas) — attached on Start in chat; open alone anytime |
| **output-*** files | Your campaign brief, persona, offer story, launch & content plan |

## Example later

Attach only the **Marketing guide** + your filled **output-campaign-brief.md** and ask: *"Rewrite this landing page hero using three persuasion principles."*
