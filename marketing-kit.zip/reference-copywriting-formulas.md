---
type: note
title: Copywriting formulas (reference)
category: Marketing kit
tags: copywriting, formulas, marketing, reference
searchable: true
---

# Copywriting formulas (reference)

Story engines for email, landing pages, and ads. Attach with the **Marketing kit coach** or alone.

## PAS — Problem, Agitate, Solve
Name pain → make it felt → present solution as the logical answer.

## AIDA — Attention, Interest, Desire, Action
Hook → why care → crave outcome → clear next step.

## Before–After–Bridge
Painful now → vivid future → your product is the bridge.

## The 4 U’s (headlines)
**Useful, Urgent, Unique, Ultra-specific** — aim for 3+ on every headline.

## FAB — Features, Advantages, Benefits
What it is → what that enables → why it matters emotionally.

## SLAP — Stop, Look, Act, Purchase
Pattern interrupt → surprise → low-friction step → buy.

## QUEST — Qualify, Understand, Educate, Stimulate, Transition
Long sales pages: who it’s for → empathy → teach → imagine → invite.

## One-sentence persuasion
“If you [do X], you’ll get [benefit] in [timeframe] without [pain].”

## Star – Story – Solution
Hero → struggle → resolution (video, email, talk).

## “So what?” test
After every line: if the answer isn’t a sharp benefit, cut or rewrite.

## How to ask the AI

> Pick the best formula for [medium] and [audience]. Explain in one sentence why. Then write the copy in our brand voice.

Attach **output-brand-brief.md** or voice guide when you have them.
