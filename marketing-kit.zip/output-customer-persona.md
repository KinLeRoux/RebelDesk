---
type: note
title: Customer persona — output template
category: Marketing kit
tags: persona, customer, output
searchable: true
---

# Customer persona — output template

_Filled in by the Marketing kit coach (Mode 2)._

## Persona name (fictional label)

## Snapshot

**Age / life stage:**

**Job or situation:**

**One-line description:**

## Day in the life

## Goals

## Frustrations & fears (before you)

## Triggers (why they act now)

## Objections

## What success looks like (after)

## Where they discover you

## Words they use / words to avoid

## Quote (something they might say)
