---
type: note
title: Meal plan week — output template
category: Personal & life
tags: meal plan, output
searchable: true
---

# Meal plan week — output template

## Week of

## Diet style (if any)

**Not medical advice — preferences only:**

## Overview

| Day | Breakfast | Lunch | Dinner |
| --- | --------- | ----- | ------ |
| Mon | | | |
| Tue | | | |
| Wed | | | |
| Thu | | | |
| Fri | | | |
| Sat | | | |
| Sun | | | |

## Shopping list (grouped)

**Produce:**

**Protein:**

**Dairy / alt:**

**Pantry:**

## Prep ahead (optional)

-
