---
type: note
title: Travel and holiday planning (reference)
category: Personal & life
tags: travel, holiday, route, reference
searchable: true
---

# Travel and holiday planning (reference)

Trips, holidays, routes, and packing — for **Personal & life coach** or attach alone.

## Trip types

| Type | Plan focus |
| ---- | ---------- |
| **City break** | Walkable zones, one home base, museums/food |
| **Road trip** | Drive times, stops, fuel/rest, flexible weather |
| **Beach / resort** | Slow days, gear, sun, reservations |
| **Family holiday** | Pace, naps, kid-friendly blocks, backups |
| **Multi-country** | Borders, visas [confirm], bag limits, currency |

## Planning steps

1. **Dates & budget vibe** (frugal / mid / splurge)  
2. **Must-see vs nice-to-see**  
3. **Book early:** flights, peak lodging, popular restaurants  
4. **Daily pace:** max 2–3 major things per day for most adults  
5. **Buffer:** travel days, weather day, rest half-day  

## Route / day planner (driving or multi-stop)

For each day:

- **Wake / leave** time  
- **Stop 1** — duration, parking/transit note  
- **Lunch area**  
- **Stop 2**  
- **Overnight town**  
- **Drive time totals** — round up 15–20% for breaks  

Use maps for real times; AI estimates are rough — user should verify.

## Holiday-specific

- Who’s coming, dietary needs, traditions  
- Gift list + budget  
- Food prep timeline (T-7, T-3, day-of)  
- House guests: linens, bathroom, wifi note  

## Packing categories

- Documents (ID, insurance, tickets)  
- Clothes (layers, one dressier outfit)  
- Toiletries + meds **in carry-on**  
- Chargers + adapters  
- Snacks + empty water bottle  

## Prompts alone

- “7-day Italy itinerary: Rome 3 nights, Florence 2, Venice 2 — train between.”  
- “Road trip Chicago to Denver with two kids under 8 — scenic stops.”  
- “Christmas week planner: gifts, meals, house prep checklist.”

Output: **output-trip-itinerary.md** or **output-family-events-planner.md**.
