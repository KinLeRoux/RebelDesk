---
type: note
title: Example recipes (reference)
category: Personal & life
tags: recipes, examples, reference
searchable: true
---

# Example recipes (reference)

Starter dishes to **scale**, adapt, or combine with **Flavor and spice science**. Save your versions in **output-recipe-card.md**.

## Creamy tomato pasta (2 servings)

**Ingredients:** 200 g pasta, 1 tbsp olive oil, 2 garlic cloves, 1 can crushed tomatoes, ½ cup cream, salt, pepper, basil.

**Steps:**

1. Boil pasta until al dente; reserve ½ cup pasta water.
2. Sauté garlic in oil; add tomatoes; simmer 10 minutes.
3. Stir in cream; loosen with pasta water if thick.
4. Toss pasta; season; top with basil.

## Lemon herb roast chicken thighs (4 pieces)

**Ingredients:** 4 bone-in thighs, 1 lemon (zest + juice), 2 tsp dried herbs, 1 tbsp oil, salt.

**Steps:**

1. Rub thighs with oil, zest, herbs, salt.
2. Roast at 200°C / 400°F for 35–40 min until 74°C internal.
3. Rest 5 minutes; finish with lemon juice.

## Smoky curry jam marinade (for skewers)

**Ingredients:** 3 tbsp jam or honey, 1 tbsp curry powder, 1 tbsp oil, 1 tbsp vinegar, salt, chili optional.

**Steps:** Mix; coat protein or veg 30 min–2 hr; grill until done.

## How to use with AI

- “Scale creamy tomato pasta to 6 servings and add shopping list.”  
- “Make this marinade work for cauliflower steaks.”  
- “Lower-carb side to go with lemon chicken.”
