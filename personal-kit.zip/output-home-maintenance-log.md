---
type: note
title: Home maintenance log — output template
category: Personal & life
tags: home, maintenance, output
searchable: true
---

# Home maintenance log — output template

## Address / home (optional)

## Appliances & systems

| Item | Brand/model | Bought | Warranty / service | Notes |
| ---- | ----------- | ------ | ------------------ | ----- |
| | | | | |

## Who to call

| Job | Contact |
| --- | ------- |
| Plumber | |
| Electrician | |

## Seasonal checklist

### Spring
- [ ]

### Summer
- [ ]

### Autumn
- [ ]

### Winter
- [ ]

## Last done / next due

| Task | Last | Next |
| ---- | ---- | ---- |
| | | |
