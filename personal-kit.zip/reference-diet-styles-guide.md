---
type: note
title: Diet styles guide (reference)
category: Personal & life
tags: diet, nutrition, health, reference
searchable: true
---

# Diet styles guide (reference)

**Lifestyle overview only — not medical advice.** People with diabetes, heart disease, pregnancy, eating disorders, or on medication should talk to a qualified professional before changing diet.

Use with **Personal & life coach** Mode 3 for **meal ideas**, not diagnosis or weight promises.

---

## 1. Balanced / “plate method”

- Half veg, quarter protein, quarter starch; varied whole foods.  
- **Good for:** general family eating, flexible.

## 2. Mediterranean

- Olive oil, fish, veg, legumes, whole grains, moderate wine optional.  
- **Limits:** heavy processed meat, refined sugar.  
- **Meal idea:** grilled fish, salad, chickpeas, herb oil.

## 3. Vegetarian

- No meat/fish; eggs/dairy often OK.  
- **Watch:** protein (legumes, dairy, eggs), B12 supplement often discussed with doctor.  
- **Meal idea:** lentil curry + yogurt + greens.

## 4. Vegan

- No animal products.  
- **Watch:** B12, iron, omega-3 — plan variety (tofu, beans, nuts, fortified foods).  
- **Meal idea:** tofu stir-fry, peanut sauce, broccoli, rice.

## 5. Keto / very low carb

- High fat, moderate protein, very low carbohydrate.  
- **Often avoids:** bread, sugar, most fruit, starchy veg.  
- **Meal idea:** salmon, avocado salad, olive oil dressing.  
- **Note:** medical keto differs from casual “keto”; supervision matters for some.

## 6. Carnivore (animal-based)

- Emphasis on meat, fish, eggs; some include dairy; plants minimal or none depending on strictness.  
- **Meal idea:** ribeye, eggs, bone broth — variety across animal foods still matters to many advocates.  
- **Controversial / restrictive** — not for everyone; doctor consult strongly advised.

## 7. Paleo-ish

- Whole foods; avoids highly processed foods, grains, legumes for strict paleo; lean meats, veg, nuts, fruit.  
- **Meal idea:** chicken thighs, roasted root veg (strict paleo may skip potatoes — ask user’s version).

## 8. Intermittent fasting (pattern, not one food list)

- Eating window (e.g. 8 hours) vs fasting period — **what** you eat still matters.  
- **Not recommended** without medical OK for: pregnancy, some diabetes, history of ED.

## 9. Low FODMAP (often for digestion comfort)

- Short-term elimination phase under professional guidance often recommended — complex.  
- Coach gives only **gentle ideas** unless user says they are on supervised low FODMAP.

---

## How the coach should help

- Ask: goals (energy, simplicity, ethics, weight — without promising outcomes).  
- Ask: allergies, culture, cooking time.  
- Suggest **3 breakfasts, 3 lunches, 3 dinners** in their chosen style.  
- Never shame other diets; never claim cure.

## Prompts alone

- “Five carnivore-friendly dinners, family of four.”  
- “Vegan high-protein lunch prep ideas.”  
- “Compare Mediterranean vs keto for someone who loves pasta — neutral pros/cons.”
