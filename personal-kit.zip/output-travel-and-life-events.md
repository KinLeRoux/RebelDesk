---
type: note
title: Travel and life events — output template
category: Personal & life
tags: travel, trip, family, events, holiday, output
searchable: true
---

# Travel and life events — output template

_Filled in by the Personal & life coach. Use Part A for trips, holidays, and routes; use Part B for family gatherings, birthdays, and seasonal events._

---

## Part A — Trip itinerary

_Use for holidays, vacations, road trips, or multi-day routes._

### Trip name

### Dates

### Travelers

### Budget vibe

### Transport

**Fly / train / car / mix:**

### Base locations (nights)

| Place | Nights | Notes |
| ----- | ------ | ----- |
| | | |

### Day-by-day plan

#### Day 1 — [date]

**Location:**

| Time | Activity | Notes |
| ---- | -------- | ----- |
| | | |

**Meals:**

**Lodging:**

_(repeat per day)_

### Driving / route summary (if applicable)

| Leg | Est. time | Stops |
| --- | --------- | ----- |
| | | |

### Reservations to book

- [ ]

### Packing reminders

### Budget notes (optional)

### Verify on maps

_Times are estimates — confirm before travel._

---

## Part B — Family events planner

### Event

**Date:**

**Who:**

### Food & dietary needs

| Person | Likes / avoids |
| ------ | -------------- |
| | |

### Menu or food plan

### Traditions to keep

### Gifts (if applicable)

| Person | Idea | Budget |
| ------ | ---- | ------ |
| | | |

### Tasks timeline

| When | Task | Who |
| ---- | ---- | --- |
| | | |

### Shopping list

### Day-of schedule
