---
type: note
title: Start here — Personal & life kit
category: Personal & life
tags: personal, life, start
searchable: true
---

# Personal & life kit

Recipes, flavor pairing, diet-friendly meal ideas, trips, holidays, family plans, and home upkeep — for real life, not tech manuals.

## Simple path

1. Install **Personal & life kit** in **Settings → Chat Settings → Memory packs**.
2. Tap **Start in chat**.
3. Press **Send** and choose what you need.

## What’s inside

| Kind | Examples |
| ---- | -------- |
| **Coach** | Recipes, trips, weekly life admin |
| **Personal life guide** | One reference for flavor, recipes, diet styles, and travel |
| **Outputs** | Food & meals, travel & events, home log, week planner |

## Outputs

- **output-food-and-meals.md** — recipe cards or weekly meal plans
- **output-travel-and-life-events.md** — trip itineraries or family event plans
- **output-home-maintenance-log.md** — appliances and seasonal upkeep
- **output-personal-week-planner.md** — errands, meals, and personal priorities

**Not medical advice** — diet help is general lifestyle information; check with your doctor for health conditions.

## Attach the guide alone

Example: attach **Personal life guide** and ask *“What herbs go with lamb and lemon?”*
