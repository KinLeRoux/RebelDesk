---
type: note
title: Start here — Personal & life kit
category: Personal & life
tags: personal, life, start
searchable: true
---

# Personal & life kit

Recipes, flavor pairing, diet-friendly meal ideas, trips, holidays, family plans, and home upkeep — for real life, not tech manuals.

## Simple path

1. Install **Personal & life kit** in **Settings → Chat Settings → Memory packs**.
2. Tap **Start in chat**.
3. Press **Send** and choose what you need.

## What’s inside

| Kind | Examples |
| ---- | -------- |
| **Coach** | Recipes, trips, weekly life admin |
| **Research** | Spice & flavor science, diet styles overview, travel planning — plus extra references you can attach alone |
| **Outputs** | Recipe cards, meal plan, trip itinerary, family events, home log |

**Not medical advice** — diet help is general lifestyle information; check with your doctor for health conditions.

## Attach references alone

Example: attach **Flavor and spice science** and ask *“What herbs go with lamb and lemon?”*
