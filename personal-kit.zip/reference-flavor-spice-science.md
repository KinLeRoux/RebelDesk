---
type: note
title: Flavor and spice science (reference)
category: Personal & life
tags: cooking, flavor, spice, reference
searchable: true
---

# Flavor and spice science (reference)

How tastes work together — for the **Personal & life coach** or attach alone.

## Five tastes (building blocks)

| Taste | Role | Examples |
| ----- | ---- | -------- |
| **Salt** | Amplifies, balances | Finish dishes; salt acid foods |
| **Sweet** | Rounds heat & acid | Honey, caramelized onion, carrot |
| **Sour / acid** | Brightens, cuts richness | Lemon, vinegar, yogurt, tomato |
| **Bitter** | Depth (use small) | Coffee, cocoa, charred greens |
| **Umami** | Savory “full” | Soy, parmesan, mushrooms, tomato paste |

**Fat** carries flavor (olive oil, butter, coconut milk).

**Heat** (chili, pepper) — optional layer, not a sixth taste but essential in many cuisines.

## Balancing a dish

- Too flat → salt + acid.  
- Too rich → acid + fresh herb.  
- Too harsh → fat + sweet.  
- Too bland → salt + umami + acid.

## Spice ≠ only heat

**Aromatic:** cumin, coriander, fennel, cardamom  
**Warm:** cinnamon, nutmeg, clove  
**Earthy:** paprika, turmeric, sumac  
**Herbs (fresh/dried):** basil, thyme, oregano, mint, cilantro  
**Heat:** cayenne, chili flakes, black pepper, ginger

## Classic pairings (starting points)

| Main ingredient | Herbs / spices | Acid / finish |
| --------------- | -------------- | ------------- |
| Chicken | thyme, rosemary, paprika | lemon |
| Beef | black pepper, garlic, bay | red wine vinegar or mustard |
| Lamb | mint, cumin, rosemary | yogurt, lemon |
| Fish | dill, parsley, fennel | lemon, capers |
| Beans / lentils | cumin, smoked paprika | lime, vinegar |
| Roasted veg | rosemary, thyme, chili | balsamic |

## Regional blend ideas (make your own)

- **Mediterranean:** oregano, garlic, lemon zest, olive oil  
- **Middle Eastern:** cumin, coriander, cinnamon pinch, sumac  
- **South Asian:** cumin, turmeric, garam masala, ginger, chili  
- **Latin:** cumin, smoked paprika, lime, cilantro  
- **BBQ rub:** paprika, brown sugar, garlic, black pepper, chili

## Marinade logic

**Acid + fat + salt + flavor** — 30 min to overnight depending on protein. Acid too long on fish = ceviche effect (okay if intended).

## Prompts alone

- “I have chicken, rice, and broccoli — suggest a spice profile and sauce.”  
- “Something tastes too greasy — how to fix?”  
- “Build a dry rub for pork shoulder, medium heat.”

See **reference-recipe-building-blocks.md** for ratios and methods.
