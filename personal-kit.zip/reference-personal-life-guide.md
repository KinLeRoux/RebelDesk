---
type: note
title: Personal life guide (reference)
category: Personal & life
tags: cooking, travel, diet, recipes, reference
searchable: true
---

# Personal life guide (reference)

Food, flavor, diet styles, recipes, and travel — attach for the **Personal & life coach** or alone.

**Not medical advice.** People with diabetes, heart disease, pregnancy, eating disorders, or on medication should talk to a qualified professional before changing diet.

---

## Flavor and spice science

### Five tastes (building blocks)

| Taste | Role | Examples |
| ----- | ---- | -------- |
| **Salt** | Amplifies, balances | Finish dishes; salt acid foods |
| **Sweet** | Rounds heat & acid | Honey, caramelized onion, carrot |
| **Sour / acid** | Brightens, cuts richness | Lemon, vinegar, yogurt, tomato |
| **Bitter** | Depth (use small) | Coffee, cocoa, charred greens |
| **Umami** | Savory “full” | Soy, parmesan, mushrooms, tomato paste |

**Fat** carries flavor (olive oil, butter, coconut milk). **Heat** (chili, pepper) — optional layer, essential in many cuisines.

### Balancing a dish

- Too flat → salt + acid.
- Too rich → acid + fresh herb.
- Too harsh → fat + sweet.
- Too bland → salt + umami + acid.

### Spice ≠ only heat

**Aromatic:** cumin, coriander, fennel, cardamom  
**Warm:** cinnamon, nutmeg, clove  
**Earthy:** paprika, turmeric, sumac  
**Herbs (fresh/dried):** basil, thyme, oregano, mint, cilantro  
**Heat:** cayenne, chili flakes, black pepper, ginger

### Classic pairings (starting points)

| Main ingredient | Herbs / spices | Acid / finish |
| --------------- | -------------- | ------------- |
| Chicken | thyme, rosemary, paprika | lemon |
| Beef | black pepper, garlic, bay | red wine vinegar or mustard |
| Lamb | mint, cumin, rosemary | yogurt, lemon |
| Fish | dill, parsley, fennel | lemon, capers |
| Beans / lentils | cumin, smoked paprika | lime, vinegar |
| Roasted veg | rosemary, thyme, chili | balsamic |

### Regional blend ideas

- **Mediterranean:** oregano, garlic, lemon zest, olive oil
- **Middle Eastern:** cumin, coriander, cinnamon pinch, sumac
- **South Asian:** cumin, turmeric, garam masala, ginger, chili
- **Latin:** cumin, smoked paprika, lime, cilantro
- **BBQ rub:** paprika, brown sugar, garlic, black pepper, chili

### Marinade logic

**Acid + fat + salt + flavor** — 30 min to overnight depending on protein. Acid too long on fish = ceviche effect (okay if intended).

---

## Recipe building blocks

### Sauces (mother ideas)

| Sauce | Base | Use |
| ----- | ---- | --- |
| White | butter + flour + milk (béchamel) | pasta bake, gratins |
| Tomato | onion + garlic + tomato | pasta, stew |
| Pan sauce | fond + wine/stock + butter | steak, chops |
| Vinaigrette | 3 oil : 1 acid + salt | salads |

### Rice & grains (approx)

- **Rice:** 1 cup rice : 1.5–2 cups water (varies by type)
- **Pasta:** abundant salted water; save pasta water for sauce
- **Oats:** 1 cup oats : 2 cups liquid

### Proteins — safe internal temps (°C / °F guide)

| Protein | Target |
| ------- | ------ |
| Chicken pieces | 74°C / 165°F |
| Ground meat | 71°C / 160°F |
| Fish (flakes) | 63°C / 145°F typical |
| Medium beef steak | user preference — note food safety for ground vs whole cuts |

Always rest meat 5–10 min after cooking.

### Vegetable methods

- **Roast:** high heat, oil, salt, space on tray
- **Sauté:** hot pan, don’t crowd
- **Steam:** preserve color, nutrient-sensitive veg

### Scaling recipes

Multiply ingredients except: strong spice/chili (increase ~75% first, taste). Salt in small steps.

### Shopping list by aisle

Produce → protein → dairy → pantry → frozen — coach groups list this way.

---

## Example recipes

Starter dishes to **scale**, adapt, or combine with flavor science above. Save your versions in **output-food-and-meals.md**.

### Creamy tomato pasta (2 servings)

**Ingredients:** 200 g pasta, 1 tbsp olive oil, 2 garlic cloves, 1 can crushed tomatoes, ½ cup cream, salt, pepper, basil.

**Steps:**

1. Boil pasta until al dente; reserve ½ cup pasta water.
2. Sauté garlic in oil; add tomatoes; simmer 10 minutes.
3. Stir in cream; loosen with pasta water if thick.
4. Toss pasta; season; top with basil.

### Lemon herb roast chicken thighs (4 pieces)

**Ingredients:** 4 bone-in thighs, 1 lemon (zest + juice), 2 tsp dried herbs, 1 tbsp oil, salt.

**Steps:**

1. Rub thighs with oil, zest, herbs, salt.
2. Roast at 200°C / 400°F for 35–40 min until 74°C internal.
3. Rest 5 minutes; finish with lemon juice.

### Smoky curry jam marinade (for skewers)

**Ingredients:** 3 tbsp jam or honey, 1 tbsp curry powder, 1 tbsp oil, 1 tbsp vinegar, salt, chili optional.

**Steps:** Mix; coat protein or veg 30 min–2 hr; grill until done.

---

## Diet styles overview

Use for **meal ideas**, not diagnosis or weight promises.

### 1. Balanced / “plate method”

Half veg, quarter protein, quarter starch; varied whole foods. **Good for:** general family eating.

### 2. Mediterranean

Olive oil, fish, veg, legumes, whole grains. **Limits:** heavy processed meat, refined sugar.

### 3. Vegetarian

No meat/fish; eggs/dairy often OK. **Watch:** protein, B12.

### 4. Vegan

No animal products. **Watch:** B12, iron, omega-3.

### 5. Keto / very low carb

High fat, moderate protein, very low carbohydrate. **Note:** medical keto differs from casual “keto.”

### 6. Carnivore (animal-based)

Emphasis on meat, fish, eggs. **Controversial / restrictive** — doctor consult strongly advised.

### 7. Paleo-ish

Whole foods; avoids highly processed foods; lean meats, veg, nuts, fruit.

### 8. Intermittent fasting (pattern)

Eating window vs fasting period — **what** you eat still matters.

### 9. Low FODMAP

Short-term elimination phase under professional guidance often recommended.

### How the coach should help

- Ask: goals (energy, simplicity, ethics — without promising outcomes).
- Ask: allergies, culture, cooking time.
- Suggest **3 breakfasts, 3 lunches, 3 dinners** in their chosen style.
- Never shame other diets; never claim cure.

---

## Travel and holiday planning

### Trip types

| Type | Plan focus |
| ---- | ---------- |
| **City break** | Walkable zones, one home base, museums/food |
| **Road trip** | Drive times, stops, fuel/rest, flexible weather |
| **Beach / resort** | Slow days, gear, sun, reservations |
| **Family holiday** | Pace, naps, kid-friendly blocks, backups |
| **Multi-country** | Borders, visas [confirm], bag limits, currency |

### Planning steps

1. **Dates & budget vibe** (frugal / mid / splurge)
2. **Must-see vs nice-to-see**
3. **Book early:** flights, peak lodging, popular restaurants
4. **Daily pace:** max 2–3 major things per day for most adults
5. **Buffer:** travel days, weather day, rest half-day

### Route / day planner (driving or multi-stop)

For each day: wake/leave time, stops with duration, lunch area, overnight town, drive time totals (round up 15–20% for breaks). Use maps for real times; AI estimates are rough — user should verify.

### Holiday-specific

- Who’s coming, dietary needs, traditions
- Gift list + budget
- Food prep timeline (T-7, T-3, day-of)
- House guests: linens, bathroom, wifi note

### Packing categories

Documents, clothes (layers), toiletries + meds **in carry-on**, chargers + adapters, snacks + empty water bottle.

---

## Prompts alone

- “I have chicken, rice, and broccoli — suggest a spice profile and sauce.”
- “Five carnivore-friendly dinners, family of four.”
- “Scale creamy tomato pasta to 6 servings and add shopping list.”
- “7-day Italy itinerary: Rome 3 nights, Florence 2, Venice 2 — train between.”
- “Christmas week planner: gifts, meals, house prep checklist.”

**Outputs:** **output-food-and-meals.md**, **output-travel-and-life-events.md**, **output-home-maintenance-log.md**, **output-personal-week-planner.md**.
