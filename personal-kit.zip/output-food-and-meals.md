---
type: note
title: Food and meals — output template
category: Personal & life
tags: recipe, meal plan, food, output
searchable: true
---

# Food and meals — output template

_Filled in by the Personal & life coach. Use the recipe section for one dish; use the meal plan section for a week of meals._

---

## Part A — Recipe card

### Dish name

### Servings

### Diet / allergies noted

### Ingredients

| Item | Amount |
| ---- | ------ |
| | |

### Steps

1.

### Time

**Prep:**

**Cook:**

### Tips / substitutions

### Shopping list (this recipe only)

---

## Part B — Meal plan week

### Week of

### Diet style (if any)

**Not medical advice — preferences only:**

### Overview

| Day | Breakfast | Lunch | Dinner |
| --- | --------- | ----- | ------ |
| Mon | | | |
| Tue | | | |
| Wed | | | |
| Thu | | | |
| Fri | | | |
| Sat | | | |
| Sun | | | |

### Shopping list (grouped)

**Produce:**

**Protein:**

**Dairy / alt:**

**Pantry:**

### Prep ahead (optional)

-
