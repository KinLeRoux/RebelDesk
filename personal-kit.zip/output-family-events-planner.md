---
type: note
title: Family events planner — output template
category: Personal & life
tags: family, events, holiday, output
searchable: true
---

# Family events planner — output template

## Event

**Date:**

**Who:**

## Food & dietary needs

| Person | Likes / avoids |
| ------ | -------------- |
| | |

## Menu or food plan

## Traditions to keep

## Gifts (if applicable)

| Person | Idea | Budget |
| ------ | ---- | ------ |
| | | |

## Tasks timeline

| When | Task | Who |
| ---- | ---- | --- |
| | | |

## Shopping list

## Day-of schedule
