---
type: note
title: Recipe building blocks (reference)
category: Personal & life
tags: recipes, cooking, reference
searchable: true
---

# Recipe building blocks (reference)

Ratios and methods — attach with **Flavor and spice science** for full cooking help.

## Sauces (mother ideas)

| Sauce | Base | Use |
| ----- | ---- | --- |
| White | butter + flour + milk (béchamel) | pasta bake, gratins |
| Tomato | onion + garlic + tomato | pasta, stew |
| Pan sauce | fond + wine/stock + butter | steak, chops |
| Vinaigrette | 3 oil : 1 acid + salt | salads |

## Rice & grains (approx)

- **Rice:** 1 cup rice : 1.5–2 cups water (varies by type)  
- **Pasta:** abundant salted water; save pasta water for sauce  
- **Oats:** 1 cup oats : 2 cups liquid

## Proteins — safe internal temps (°C / °F guide)

| Protein | Target |
| ------- | ------ |
| Chicken pieces | 74°C / 165°F |
| Ground meat | 71°C / 160°F |
| Fish (flakes) | 63°C / 145°F typical |
| Medium beef steak | user preference — note food safety for ground vs whole cuts |

Always rest meat 5–10 min after cooking.

## Vegetable methods

- **Roast:** high heat, oil, salt, space on tray  
- **Sauté:** hot pan, don’t crowd  
- **Steam:** preserve color, nutrient-sensitive veg  

## Scaling recipes

Multiply ingredients except: strong spice/chili (increase ~75% first, taste). Salt in small steps.

## Shopping list by aisle

Produce → protein → dairy → pantry → frozen — coach groups list this way.

## Prompts

- “Convert this recipe from 2 to 8 servings.”  
- “Pan sauce after pork chops with apple and thyme.”

See **reference-example-recipes.md** for starter dishes.
