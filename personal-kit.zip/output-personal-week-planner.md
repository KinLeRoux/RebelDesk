---
type: note
title: Personal week planner — output template
category: Personal & life
tags: personal, week, output
searchable: true
---

# Personal week planner — output template

## Week of

## Top 3 personal priorities

1.
2.
3.

## Appointments / fixed

| Day | What |
| --- | ---- |
| | |

## Meals sketch (optional)

| Day | Dinner idea |
| --- | ----------- |
| | |

## Errands

- [ ]

## Home / family tasks

- [ ]

## Notes for next week
