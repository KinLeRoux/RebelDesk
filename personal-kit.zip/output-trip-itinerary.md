---
type: note
title: Trip itinerary — output template
category: Personal & life
tags: travel, trip, route, holiday, output
searchable: true
---

# Trip itinerary — output template

_Use for holidays, vacations, road trips, or multi-day routes._

## Trip name

## Dates

## Travelers

## Budget vibe

## Transport

**Fly / train / car / mix:**

## Base locations (nights)

| Place | Nights | Notes |
| ----- | ------ | ----- |
| | | |

## Day-by-day plan

### Day 1 — [date]

**Location:**

| Time | Activity | Notes |
| ---- | -------- | ----- |
| | | |

**Meals:**

**Lodging:**

_(repeat per day)_

## Driving / route summary (if applicable)

| Leg | Est. time | Stops |
| --- | --------- | ----- |
| | | |

## Reservations to book

- [ ]

## Packing reminders

## Budget notes (optional)

## Verify on maps

_Times are estimates — confirm before travel._
