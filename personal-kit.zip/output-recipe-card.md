---
type: note
title: Recipe card — output template
category: Personal & life
tags: recipe, output
searchable: true
---

# Recipe card — output template

## Dish name

## Servings

## Diet / allergies noted

## Ingredients

| Item | Amount |
| ---- | ------ |
| | |

## Steps

1.

## Time

**Prep:**

**Cook:**

## Tips / substitutions

## Shopping list (this recipe only)
