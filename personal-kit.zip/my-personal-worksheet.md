---
type: note
title: My personal worksheet
category: Personal & life
tags: personal, worksheet
searchable: true
---

# My personal worksheet

## Kitchen

**Household size:**

**Allergies / never eat:**

**Diet style (preference, not medical):**

**Favorite cuisines:**

## Travel

**Dream trip:**

**Pace:** slow / packed

**Mobility needs:**

## Family

**Key dates:**

**Gift budget:**

## Home

**Rental or own:**

**Known issues:**

## Session log

| Date | Mode | Output file |
| ---- | ---- | ----------- |
| | | |
