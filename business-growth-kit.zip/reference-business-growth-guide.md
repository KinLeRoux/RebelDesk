---
type: note
title: Business growth guide (reference)
category: Business growth kit
tags: vision, strategy, validation, growth, runway, reference
searchable: true
---

# Business growth guide (reference)

One guide for the **Business growth coach** — foundation, customers, growth, cash, and founder rhythm.

## Part A — Vision, values & strategy

**Vision** = 5–10 year picture. **Mission** = daily work toward it.

**Real values** — defended when they cost money: “What have you turned down money for?”

**UVP** = what you do unusually well + urgent customer pain + hard-to-copy difference.

**Elevator pitch:** “You know how **[group]** struggles with **[pain]**? We **[solution]**. Unlike **[alternative]**, we **[proof]**. **[Ask]**.”

**SWOT** — strengths/weaknesses with evidence; opportunities/threats; **strategic not-to-dos** (what you ignore this year).

**Competitive lens:** direct + indirect competitors including “do nothing”; why choose you vs a bigger player?

## Part B — Validation & first customers

**Problem interviews** — listen, don’t pitch: “Tell me about the last time…”

**Early adopter:** has pain now, urgent, reachable, will pay/pilot soon.

**MVP types:** concierge, wizard-of-oz, landing page, thin prototype — ugliest version that delivers the outcome.

**First 10 customers:** list 30 names; manual onboarding; one success metric (paid, repeat, or referral).

**Market sanity:** bottom-up SOM (12–24 months), not fantasy TAM.

## Part C — Growth, runway & founder

**Funnel:** first touch → trust → purchase → aha → repeat/referral. Fix **one** bottleneck per month.

**Unit economics:** CAC, LTV, payback months — LTV should exceed CAC with payback that fits cash.

**Growth loops:** content, paid, sales-led, product-led, partnership — pick **one** primary.

**Runway:** cash in bank ÷ monthly net burn. Levers: collect faster, cut discretionary spend, raise price on new customers, focus highest-margin offer.

**Finance kit** for formal P&L and PDF statements.

**One Big Rock per quarter** + 3–5 leading indicators (weekly green/yellow/red).

**Founder OS:** energy 1–5 weekly; delegate $25/h tasks; decision log + pre-mortem; life alignment (run forever vs sell).

**Network:** 5–7 communities; ~3 hours/week max; value-first comments and posts. Mode 8 → `output-network-rhythm.md`. Campaigns → **Marketing kit**.
