---
type: note
title: Start here — Business growth coach
category: Business growth kit
tags: growth, coach, kit, start
searchable: true
---

# Business growth coach

From idea to paying customers to growth — plain-language coaching for founders and small-business owners.

## Simple path

1. **Settings → Chat Settings → Memory packs** → install **Business growth coach**.
2. Tap **Start in chat** (or **Memory packs** in the chat header).
3. Press **Send** and pick what you need from the coach menu.

No extra files to attach — coach and research notes load automatically.

## What’s inside

| Kind | Use |
| ---- | --- |
| **Business growth coach** | Guided interviews — pick a topic, one question at a time |
| **Business growth guide** | One reference note — attached on Start in chat |
| **Five output files** | Snapshot, vision & strategy, customers & growth, execution/runway/founder, network rhythm |

Works even better when **Brand kit** or **Marketing kit** outputs already exist — they attach when filled.

## Tips

- Do **one topic per session** (e.g. validation OR runway, not both).
- Use **my-growth-worksheet.md** for rough numbers and notes before you chat.
- For bank statements and P&L detail, use **Finance kit** alongside mode 6 (cash & runway).
