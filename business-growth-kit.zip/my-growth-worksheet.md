---
type: note
title: My growth worksheet
category: Business growth kit
tags: growth, worksheet
searchable: true
---

# My growth worksheet

Scratch notes for the **Business growth coach**.

## Stage (circle one)

Idea → First customers → Growth → Scaling → Stuck

## Urgent pain (one sentence)

What one problem, solved this week, would change everything?

## Clarity (1–10)

| Area | Score |
| ---- | ----- |
| Vision | |
| Real values | |
| Uniqueness | |
| Ideal customer | |
| Cash / runway | |

## Resources (rough)

**Paying customers (count):**

**Team (who):**

**Runway (months):**

## Notes
