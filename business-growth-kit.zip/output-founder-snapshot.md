---
type: note
title: Founder snapshot — output template
category: Business growth kit
tags: snapshot, founder, output
searchable: true
---

# Founder snapshot — output template

_Filled by the Business growth coach (Mode 0)._

## Date

## Stage

Idea / First customers / Growth / Scaling / Stuck

## Urgent pain (one sentence)

## Clarity scores (1–10)

| Area | Score | Note |
| ---- | ----- | ---- |
| Vision | | |
| Real values | | |
| Uniqueness | | |
| Ideal customer | | |
| Cash / runway | | |

## Resources (rough)

**Paying customers:**

**Team:**

**Runway (months):**

## Recommended next focus

**Mode to run next:**

**Why:**
