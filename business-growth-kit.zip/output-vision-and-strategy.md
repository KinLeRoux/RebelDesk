---
type: note
title: Vision & strategy — output template
category: Business growth kit
tags: vision, values, strategy, output
searchable: true
---

# Vision & strategy — output template

_Filled by the Business growth coach (Modes 1 & 3)._

## Vision (5–10 years)

## Mission (daily)

## Real values (3–5)

| Value | What it looks like in practice |
| ----- | ----------------------------- |
| | |

## Uniqueness / UVP

## Elevator pitch (60–120 sec)

## Positioning statement

For **[customer]** who **[pain]**, we **[solution]** unlike **[alternative]** because **[difference]**.

## SWOT (evidence-based)

| Strengths | Weaknesses |
| --------- | ---------- |
| | |

| Opportunities | Threats |
| ------------- | ------- |
| | |

## Why we are the safe choice

## Strategic not-to-dos (what we ignore this year)

1.
2.
3.
