---
type: note
title: Customers & growth — output template
category: Business growth kit
tags: validation, customers, growth, gtm, output
searchable: true
---

# Customers & growth — output template

_Filled by the Business growth coach (Modes 2 & 4)._

## Early-adopter persona

## Problem hypothesis

## Interview questions (5–8)

1.
2.

## MVP approach

**Type:**

**Ugliest version that still works:**

**Success metric (one number):**

## First 10 customers — action list

| Name / segment | Channel | Next step | Date |
| -------------- | ------- | --------- | ---- |
| | | | |

## Primary growth loop

Content / Paid / Sales-led / Product-led / Partnership

## Funnel sketch

| Step | What happens | Drop-off guess | Fix to test |
| ---- | ------------ | -------------- | ----------- |
| First touch | | | |
| Trust | | | |
| Purchase | | | |
| Aha moment | | | |
| Repeat / refer | | | |

## Unit economics (rough)

**CAC:**

**LTV or gross profit per customer:**

**Payback (months):**

## 90-day experiments (max 3)

| Experiment | Owner | By when | Success metric |
| ---------- | ----- | ------- | ---------------- |
| | | | |

## Pricing / messaging move to test
