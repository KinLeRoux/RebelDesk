---
type: note
title: Network rhythm — output template
category: Business growth kit
tags: network, linkedin, visibility, output
searchable: true
---

# Network rhythm — output template

_Filled by the Business growth coach (Mode 8)._

## Where buyers already are (5–7 communities)

| Community | Link / name | Give-first action |
| --------- | ----------- | ----------------- |
| | | |

## Weekly time budget (target ≤ 3 hours)

## Sample week

| Day | Activity | Minutes |
| --- | -------- | ------- |
| | | |

## Post themes (2–3 per week)

1.
2.

## Value-first outreach template (no hard pitch)

## Newsletter (optional)

**Tool:**

**Cadence:**

**First 3 issue ideas:**
