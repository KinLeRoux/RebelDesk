---
type: note
title: Execution, runway & founder — output template
category: Business growth kit
tags: execution, runway, founder, quarterly, output
searchable: true
---

# Execution, runway & founder — output template

_Filled by the Business growth coach (Modes 5, 6 & 7)._

## Quarterly execution

### Quarter

### The one Big Rock (must-win)

### Not doing this quarter

1.
2.

### Leading indicators (3–5)

| KPI | Green | Yellow | Red | Current |
| --- | ----- | ------ | --- | ------- |
| | | | | |

### Weekly cadence

**When:**

**Who:**

**Agenda (30–60 min):**

### Delegate / hire note

## Runway & cash

### Cash in bank (as of date)

### Monthly cash in / out (avg)

### Net burn & runway (months)

_Show math:_

### Default alive? (Y/N + why)

### Top 3 levers

| Lever | Impact | Effort | Owner |
| ----- | ------ | ------ | ----- |
| | | | |

### Finance kit follow-up

## Founder OS

### Energy snapshot (1–5)

| Area | Score | One change |
| ---- | ----- | ---------- |
| Sleep | | |
| Focus | | |
| Movement | | |
| Delegation | | |

### Decision log entry

**Decision:**

**Assumption:**

**Confidence (1–10):**

**Review date:**

### Life alignment

**Run forever / build to sell / not sure:**
