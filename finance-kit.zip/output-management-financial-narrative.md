---
type: note
title: Management financial narrative — output template
category: Finance
tags: report, narrative, output
searchable: true
---

# Management financial narrative — output template

_For owner, board, or bank — plain language._

## Audience

## Period

## Headline

## Performance summary

## Wins

-

## Challenges & risks

-

## Cash & runway

## Outlook (next period)

## Asks (decisions / support needed)

-

## Appendix pointer

_Detail lives in: P&L analysis / variance report / attached statement note._
