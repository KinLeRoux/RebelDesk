---
type: note
title: Budget variance report — output template
category: Finance
tags: budget, variance, output
searchable: true
---

# Budget variance report — output template

## Period

**Compared to:** Budget / Forecast [circle one]

## Executive summary

## Variance table

| Line | Plan | Actual | Var $ | Var % | Category (timing / one-off / structural) |
| ---- | ---- | ------ | ----- | ----- | ---------------------------------------- |
| | | | | | |

## Material variances explained

### Favorable

-

### Unfavorable

-

## Recommended actions

| Action | Owner | By when |
| ------ | ----- | ------- |
| | | |

## Next forecast tweak

-
