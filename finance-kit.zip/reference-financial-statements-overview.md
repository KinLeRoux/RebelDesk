---
type: note
title: Financial statements overview (reference)
category: Finance
tags: financial statements, reference
searchable: true
---

# Financial statements overview (reference)

Three statements most small businesses use — attach for any statement mode.

## Income statement (P&L)

**Question it answers:** Did we make or lose money this period?

| Section | Plain meaning |
| ------- | ------------- |
| Revenue / sales | Money earned from customers |
| Cost of goods sold (COGS) | Direct cost to deliver product/service |
| **Gross profit** | Revenue − COGS |
| Operating expenses | Rent, payroll, marketing, software, etc. |
| **Operating profit** | Gross profit − operating expenses |
| Other income/expense | Interest, one-offs |
| **Net profit** | Bottom line (before tax often shown separately) |

Compare **same period last year** or **last quarter** when you can.

## Balance sheet

**Question it answers:** What do we own and owe *right now*?

| Side | Examples |
| ---- | -------- |
| **Assets** | Cash, receivables, inventory, equipment |
| **Liabilities** | Payables, loans, tax owed |
| **Equity** | Owner investment + retained profits |

Assets ≈ Liabilities + Equity (accounting equation).

## Cash flow statement

**Question it answers:** Where did cash actually move?

| Block | Plain meaning |
| ----- | ------------- |
| **Operating** | Cash from running the business |
| **Investing** | Equipment, acquisitions |
| **Financing** | Loans, repayments, owner draws |

**Profit ≠ cash** — you can be profitable and cash-poor (receivables, inventory).

## Prompts alone

- “Explain this P&L line to a non-accountant owner.”  
- “What should I ask my bookkeeper about a negative gross margin?”
