---
type: note
title: P&L analysis — output template
category: Finance
tags: profit and loss, output
searchable: true
---

# P&L analysis — output template

## Period & currency

**Period:**

**Currency:**

## Headline (one paragraph)

## Revenue

| Line | This period | Prior period | Change |
| ---- | ----------- | ------------ | ------ |
| | | | |

## Profitability

| Metric | Value | Comment |
| ------ | ----- | ------- |
| Gross margin % | | |
| Operating margin % | | |
| Net margin % | | |

## Top drivers (up and down)

1.
2.
3.

## Trends & flags

-

## Questions for accountant / bookkeeper

1.

## Data gaps

-
