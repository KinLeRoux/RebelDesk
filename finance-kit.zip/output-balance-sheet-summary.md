---
type: note
title: Balance sheet summary — output template
category: Finance
tags: balance sheet, output
searchable: true
---

# Balance sheet summary — output template

## As of date

## Snapshot (plain language)

**What we have (assets):**

**What we owe (liabilities):**

**What’s left for owners (equity):**

## Liquidity notes

| Item | Amount | Note |
| ---- | ------ | ---- |
| Cash | | |
| Receivables | | |
| Payables | | |

## Leverage / loans (if any)

## Changes vs prior period

-

## Follow-up questions

1.
