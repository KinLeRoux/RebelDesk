---
type: note
title: Finance guide (reference)
category: Finance
tags: financial statements, ratios, budget, pdf, reference
searchable: true
---

# Finance guide (reference)

One guide for the **Finance coach** — statements, ratios, budgets, and PDF import.

## Part A — Financial statements overview

Three statements most small businesses use.

### Income statement (P&L)

**Question it answers:** Did we make or lose money this period?

| Section | Plain meaning |
| ------- | ------------- |
| Revenue / sales | Money earned from customers |
| Cost of goods sold (COGS) | Direct cost to deliver product/service |
| **Gross profit** | Revenue − COGS |
| Operating expenses | Rent, payroll, marketing, software, etc. |
| **Operating profit** | Gross profit − operating expenses |
| Other income/expense | Interest, one-offs |
| **Net profit** | Bottom line (before tax often shown separately) |

Compare **same period last year** or **last quarter** when you can.

### Balance sheet

**Question it answers:** What do we own and owe *right now*?

| Side | Examples |
| ---- | -------- |
| **Assets** | Cash, receivables, inventory, equipment |
| **Liabilities** | Payables, loans, tax owed |
| **Equity** | Owner investment + retained profits |

Assets ≈ Liabilities + Equity (accounting equation).

### Cash flow statement

**Question it answers:** Where did cash actually move?

| Block | Plain meaning |
| ----- | ------------- |
| **Operating** | Cash from running the business |
| **Investing** | Equipment, acquisitions |
| **Financing** | Loans, repayments, owner draws |

**Profit ≠ cash** — you can be profitable and cash-poor (receivables, inventory).

## Part B — Ratios, trends, and red flags

Plain-language analytics — not a full modeling course.

### Trend questions (always ask)

- Revenue: up, flat, down vs last period?
- Gross margin %: improving or compressing?
- Big new expense lines?
- One-off items distorting the period?

### Useful ratios (when you have the inputs)

| Metric | Formula (concept) | Why it matters |
| ------ | ----------------- | -------------- |
| **Gross margin %** | Gross profit ÷ revenue | Pricing / COGS health |
| **Net margin %** | Net profit ÷ revenue | Overall profitability |
| **Current ratio** | Current assets ÷ current liabilities | Short-term bill-paying ability (rough) |
| **Runway (months)** | Cash ÷ monthly burn | How long until cash out (startups / loss-makers) |
| **DSO** (days sales outstanding) | Receivables ÷ (revenue/365) | How fast customers pay |

Skip ratios if the imported PDF doesn't include the lines needed — say what's missing.

### Red flags (investigate, don't panic alone)

- Revenue up but cash down for several periods
- Payables growing much faster than revenue
- Inventory rising while sales flat
- Consistent losses with shrinking cash and no plan
- Large "other" or uncategorized expenses
- Related-party payments without explanation (flag for accountant)

### Seasonality

Retail, tourism, B2B with annual contracts — compare to **same month last year**, not only last month.

## Part C — Budget, forecast, and variance

| Term | Meaning |
| ---- | ------- |
| **Budget** | Plan approved for the period (often annual, split monthly) |
| **Forecast** | Updated best guess mid-year (reality-adjusted) |
| **Actual** | What really happened |

Variance = **Actual − Budget** (or − Forecast — say which base you use).

**Favorable vs unfavorable** depends on the line: revenue above budget is usually favorable; expense below budget is usually favorable. Always state **direction** and **amount** (currency and %).

### Variance report structure

| Line | Budget | Actual | Variance $ | Variance % | Notes / action |
| ---- | ------ | ------ | ------------ | ---------- | -------------- |

Group variances: **material**, **timing**, **one-off**, **structural**.

### Rolling forecast habit

Each month: actuals closed → revise next 3–6 months forecast → explain top 3 changes to leadership.

## Part D — PDF financial statements in DeskMemory

**Attach when** the user works from bank packs, accountant PDFs, or exports.

### What works today

1. **Text-based PDF** (you can select/copy text in another app).
2. **Up to 20 pages** per import.
3. **Add file…** (sidebar) or **drag** PDF onto the file list.
4. DeskMemory **extracts text** → you complete **Save** (title, category **Finance**, tags).
5. Result is a **Markdown note** in your vault — searchable and attachable to chat.

### Good practices

- Name clearly: `P-and-L-2025-Q3.md`.
- In chat: **Start in chat** (Finance kit) or attach the note + ask for trends.
- Paste **key tables** from Excel into the note if PDF layout broke columns.
- Keep **currency and period** in the note title or first line.

### Limitations (v1)

| Limitation | What to do |
| ---------- | ---------- |
| Scanned PDF (image only) | Export CSV from accounting software, or ask accountant for text PDF |
| More than 20 pages | Split by quarter or import sections separately |
| Messy columns after extract | Fix in the note or attach a cleaner export |
| Confidential data | Your vault is local — still avoid sharing chat exports you don't trust |

## Prompts alone

- "Explain this P&L line to a non-accountant owner."
- "Top 5 trends in the attached quarterly statement."
- "Variance narrative for marketing spend 40% over budget."
- "I attached our Q2 P&L import — what trends do you see?"
