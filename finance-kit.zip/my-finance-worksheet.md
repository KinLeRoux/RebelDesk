---
type: note
title: My finance worksheet
category: Finance
tags: finance, worksheet
searchable: true
---

# My finance worksheet

## Reporting periods

| Period | Close date | Notes imported? |
| ------ | ---------- | --------------- |
| | | |

## Statements in vault (from PDF import)

| File name | Type (P&L / BS / CF) |
| --------- | -------------------- |
| | | |

## Open questions for accountant

-

## Session log

| Date | Mode | Output |
| ---- | ---- | ------ |
| | | |
