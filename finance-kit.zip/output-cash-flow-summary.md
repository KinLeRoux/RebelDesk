---
type: note
title: Cash flow summary — output template
category: Finance
tags: cash flow, output
searchable: true
---

# Cash flow summary — output template

## Period

## Story in one paragraph

## Operating cash

**Main inflows:**

**Main outflows:**

## Investing & financing (if applicable)

## Net change in cash

| Opening cash | Closing cash | Net change |
| ------------ | ------------ | ---------- |
| | | |

## Runway / cushion (if relevant)

## Profit vs cash gap

_Why profit and cash differ this period:_

## Actions to discuss

-
