---
type: note
title: Budget, forecast, and variance (reference)
category: Finance
tags: budget, forecast, reference
searchable: true
---

# Budget, forecast, and variance (reference)

## Budget vs forecast vs actual

| Term | Meaning |
| ---- | ------- |
| **Budget** | Plan approved for the period (often annual, split monthly) |
| **Forecast** | Updated best guess mid-year (reality-adjusted) |
| **Actual** | What really happened |

Variance = **Actual − Budget** (or − Forecast — say which base you use).

## Favorable vs unfavorable

Depends on the line:

- Revenue: actual **above** budget = usually favorable  
- Expense: actual **below** budget = usually favorable  

Always state **direction** and **amount** (currency and %).

## Variance report structure

| Line | Budget | Actual | Variance $ | Variance % | Notes / action |
| ---- | ------ | ------ | ------------ | ---------- | -------------- |

Group variances:

1. **Material** (over threshold, e.g. 10% and $X)  
2. **Timing** (invoice shifted months)  
3. **One-off** (legal fee, equipment)  
4. **Structural** (new hire, lost client)

## Rolling forecast habit

Each month: actuals closed → revise next 3–6 months forecast → explain top 3 changes to leadership.

## Prompts alone

- “Variance narrative for marketing spend 40% over budget.”  
- “Simple annual budget skeleton for a 12-person agency.”
