---
type: note
title: Financial metrics dashboard — output template
category: Finance
tags: metrics, kpi, output
searchable: true
---

# Financial metrics dashboard — output template

## Period

## Metrics

| Metric | Definition | This period | Target | Trend | Notes |
| ------ | ---------- | ----------- | ------ | ----- | ----- |
| Revenue | | | | | |
| Gross margin % | | | | | |
| Net margin % | | | | | |
| Cash balance | | | | | |
| Burn / runway | | | | | |
| | | | | | |

## Traffic light summary

| Green | Amber | Red |
| ----- | ----- | --- |
| | | |

## Review cadence

**Next review date:**
