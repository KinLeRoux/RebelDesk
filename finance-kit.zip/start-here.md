---
type: note
title: Start here — Finance kit
category: Finance
tags: finance, start
searchable: true
---

# Finance kit

Summaries, variances, metrics, and plain-language reports — for owners, bookkeepers, and finance leads.

**Not tax, audit, or investment advice.** Confirm numbers and compliance with your accountant.

## Simple path

1. **Settings → Chat Settings → Memory packs** → install **Finance kit**.
2. Tap **Start in chat**.
3. Press **Send** and say what you need (P&L review, cash flow, financial planning, metrics, etc.).

## What's inside

| Kind | Use |
| ---- | --- |
| **Finance coach** | Step-by-step for each finance task |
| **reference-finance-guide.md** | Statements, ratios, budgets, PDF import |
| **output-*** | P&L, cash flow, planning, metrics dashboard |

## Working with PDF statements (today)

DeskMemory can turn **text-based PDFs** (up to **20 pages**) into a Markdown note:

1. **Add file…** or **drag** the PDF onto your file list.
2. Save the note (e.g. category **Finance**).
3. **Start in chat** on Finance kit — or attach that note and ask: *"Summarize trends in this statement."*

Scanned/image-only PDFs need OCR (not supported yet). See **reference-finance-guide.md** Part D.
