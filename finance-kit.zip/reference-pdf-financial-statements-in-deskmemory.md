---
type: note
title: PDF financial statements in DeskMemory (reference)
category: Finance
tags: pdf, import, reference
searchable: true
---

# PDF financial statements in DeskMemory (reference)

**Attach when** the user works from bank packs, accountant PDFs, or exports.

## What works today

1. **Text-based PDF** (you can select/copy text in another app).  
2. **Up to 20 pages** per import.  
3. **Add file…** (sidebar) or **drag** PDF onto the file list.  
4. DeskMemory **extracts text** → you complete **Save** (title, category **Finance**, tags).  
5. Result is a **Markdown note** in your vault — searchable and attachable to chat.

## Good practices

- Name clearly: `P-and-L-2025-Q3.md`.  
- In chat: **Start in chat** (Finance kit) or attach the note + Mode 7 / “find trends.”  
- Paste **key tables** from Excel into the note if PDF layout broke columns.  
- Keep **currency and period** in the note title or first line.

## Limitations (v1)

| Limitation | What to do |
| ---------- | ---------- |
| Scanned PDF (image only) | Export CSV from accounting software, or ask accountant for text PDF |
| More than 20 pages | Split by quarter or import sections separately |
| Messy columns after extract | Fix in the note or attach a cleaner export |
| Confidential data | Your vault is local — still avoid sharing chat exports you don’t trust |

## Future improvements (may ship later)

Higher page limits for finance notes, table-aware extraction, dedicated “Import financial statement” flow — see project ADR when accepted.

## Prompts alone

- “I attached our Q2 P&L import — what trends do you see?”  
- “What’s missing from this PDF extract to compute gross margin?”
