---
type: note
title: Financial planning — output template
category: Finance
tags: balance sheet, budget, narrative, planning, output
searchable: true
---

# Financial planning — output template

_Combined balance sheet snapshot, budget variance, and management narrative._

## Period & audience

**Period:**

**As-of date (balance sheet):**

**Audience:** (owner / board / bank)

**Compared to:** Budget / Forecast [circle one]

## Headline (one paragraph)

## Balance sheet snapshot (plain language)

**What we have (assets):**

**What we owe (liabilities):**

**What's left for owners (equity):**

### Liquidity notes

| Item | Amount | Note |
| ---- | ------ | ---- |
| Cash | | |
| Receivables | | |
| Payables | | |

### Leverage / loans (if any)

### Changes vs prior period

-

## Budget variance summary

### Executive summary

### Variance table

| Line | Plan | Actual | Var $ | Var % | Category (timing / one-off / structural) |
| ---- | ---- | ------ | ----- | ----- | ---------------------------------------- |
| | | | | | |

### Material variances explained

**Favorable:**

-

**Unfavorable:**

-

### Recommended actions

| Action | Owner | By when |
| ------ | ----- | ------- |
| | | |

### Next forecast tweak

-

## Management narrative

### Performance summary

### Wins

-

### Challenges & risks

-

### Cash & runway

### Outlook (next period)

### Asks (decisions / support needed)

-

## Follow-up questions

1.

## Appendix pointer

_Detail lives in: P&L analysis / cash flow summary / attached statement note._
