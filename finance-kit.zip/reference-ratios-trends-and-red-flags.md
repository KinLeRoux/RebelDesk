---
type: note
title: Ratios, trends, and red flags (reference)
category: Finance
tags: ratios, trends, reference
searchable: true
---

# Ratios, trends, and red flags (reference)

Plain-language analytics — not a full modeling course.

## Trend questions (always ask)

- Revenue: up, flat, down vs last period?  
- Gross margin %: improving or compressing?  
- Big new expense lines?  
- One-off items distorting the period?

## Useful ratios (when you have the inputs)

| Metric | Formula (concept) | Why it matters |
| ------ | ----------------- | -------------- |
| **Gross margin %** | Gross profit ÷ revenue | Pricing / COGS health |
| **Net margin %** | Net profit ÷ revenue | Overall profitability |
| **Current ratio** | Current assets ÷ current liabilities | Short-term bill-paying ability (rough) |
| **Runway (months)** | Cash ÷ monthly burn | How long until cash out (startups / loss-makers) |
| **DSO** (days sales outstanding) | Receivables ÷ (revenue/365) | How fast customers pay |

Skip ratios if the imported PDF doesn’t include the lines needed — say what’s missing.

## Red flags (investigate, don’t panic alone)

- Revenue up but cash down for several periods  
- Payables growing much faster than revenue  
- Inventory rising while sales flat  
- Consistent losses with shrinking cash and no plan  
- Large “other” or uncategorized expenses  
- Related-party payments without explanation (flag for accountant)

## Seasonality

Retail, tourism, B2B with annual contracts — compare to **same month last year**, not only last month.

## Prompts alone

- “Top 5 trends in the attached quarterly statement.”  
- “Which ratios can I compute from these lines?”
