---
type: note
title: Debt and savings — output template
category: Personal finance kit
tags: debt, savings, output, personal
searchable: true
---

# Debt and savings — output template

## Debt payoff

### Strategy (snowball / avalanche)

### Debts

| Debt | Balance | Min payment | Rate % | Order |
| ---- | ------- | ----------- | ------ | ----- |
| | | | | |

### Extra payment per month

### Target debt-free date

### Milestones

---

## Savings goals

### Goal name

### Target amount

### Current saved

### Monthly contribution

### Target date

### Where money lives (account)

### If behind plan

### Additional goals (sinking funds)

| Goal | Target | Monthly | Date |
| ---- | ------ | ------- | ---- |
| | | | |
