---
type: note
title: Purchase decision — output template
category: Personal finance kit
tags: purchase, output, personal
searchable: true
---

# Purchase decision — output template

## Item

## Total cost (all-in)

## Need vs want

## Can cash-flow without hurting emergency fund?

## Decision: buy now / delay / skip

## If delay — revisit date
