---
type: note
title: My finance worksheet
category: Personal finance kit
tags: personal, finance, worksheet
searchable: true
---

# My finance worksheet

## Monthly take-home income

## Fixed bills

## Top money stress

## Notes
