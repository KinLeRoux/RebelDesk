---
type: note
title: Personal finance guide (reference)
category: Personal finance kit
tags: budget, debt, savings, purchases, personal, reference
searchable: true
---

# Personal finance guide (reference)

Household money — budgets, bills, debt, savings, and purchase decisions. **Not** tax, legal, or investment advice.

## Household budgeting

### Simple method (50/30/20 style — adjust to their life)

- **Needs** ~50%: housing, utilities, food, transport, minimum debt  
- **Wants** ~30%: dining, hobbies, subscriptions  
- **Future** ~20%: savings, extra debt paydown, irregular bills fund  

Percentages are a **starting point**, not law.

### Steps

1. List **take-home** income (after tax).  
2. List **fixed** bills with dates.  
3. List **variable** (groceries, fuel) — use last 3 months average if known.  
4. **Irregular** bucket: gifts, car repair, insurance annual — divide by 12.  
5. Income − planned expenses = surplus or gap.

### Red flags

- Credit card balance growing monthly  
- No emergency buffer  
- More subscriptions than they can name  

### Review rhythm

**15 minutes weekly:** check bank, move money to savings, note overspend category.  
**30 minutes monthly:** adjust next month’s plan.

---

## Debt and savings

### Emergency fund (personal)

| Stage | Target | Notes |
| ----- | ------ | ----- |
| Starter | $500–$1k | Stop small surprises becoming debt |
| Core | 1 month expenses | |
| Strong | 3–6 months | If income is unstable |

### Debt payoff strategies

**Snowball:** smallest balance first — quick wins, motivation.  
**Avalanche:** highest interest rate first — mathematically cheaper.

Always pay **minimums** on all debts; put extra toward the chosen target.

### Good debt vs stressful debt (plain language)

- Mortgage / reasonable student loan — often planned  
- Credit cards for daily spending without payoff — high risk  
- Buy-now-pay-later stack — easy to lose track  

### Savings goals

Name the goal, target amount, monthly contribution, realistic date.  
Separate **sinking funds** (holiday, car service) from emergency money.

### When to pause extra debt paydown

Job loss risk, no starter emergency fund, or legal collection — stabilize first.

---

## Big purchases and goals

### Purchase decision checklist

1. **Need or want?** Can something else work 6 more months?  
2. **Total cost** — price + tax + delivery + insurance + ongoing fees  
3. **Cash vs finance** — true interest cost if financed  
4. **Opportunity cost** — what savings goal slows down?  
5. **Sleep test** — still comfortable after 48 hours?

### Delay tactics

- 30-day wish list for non-urgent wants  
- Buy used / previous model  
- Split “must have now” vs “nice later”

### Goal types

| Type | Example | Track by |
| ---- | ------- | -------- |
| Short | New appliance | Balance |
| Medium | Vacation fund | Balance + date |
| Long | House down payment | % of target |

### Red lines

Don’t drain emergency fund for a want.  
Don’t finance depreciating items at high APR without a payoff date.
