---
type: note
title: Start here — Personal finance kit
category: Personal finance kit
tags: personal, finance, start
searchable: true
---

# Start here — Personal finance kit

Household budgets, bills, debt, savings, and purchase decisions — **not** business accounting. One reference guide and three output templates.

**Memory packs** → install **Personal finance & household kit** → **Start in chat**.

**Not tax or investment advice** — consult licensed professionals when needed.
