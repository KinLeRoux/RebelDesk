---
type: note
title: Budget and bills — output template
category: Personal finance kit
tags: budget, bills, output, personal
searchable: true
---

# Budget and bills — output template

## Monthly budget

### Month

### Take-home income

### Needs (planned)

| Category | Planned | Actual |
| -------- | ------- | ------ |
| | | |

### Wants (planned)

| Category | Planned | Actual |
| -------- | ------- | ------ |

### Savings / debt extra

### Surplus or gap

### One change next month

---

## Bill calendar

| Bill | Amount | Due day | Autopay? | Account |
| ---- | ------ | ------- | -------- | ------- |
| | | | | |

### Paydays

### Weekly check (5 min)

- [ ] Balances OK
- [ ] No surprise charges
