---
type: note
title: Creative direction — output template
category: Creative & client
tags: mood, visual, presentation, slides, output
searchable: true
---

# Creative direction — output template

_Filled in by the Creative & client coach. Use Part A for mood and visual direction; use Part B for presentation storylines and slide flow._

---

## Part A — Mood board narrative

_Words for look & feel — share with designer, photographer, or client._

### Project link

### Mood in one line

### Mood words (3–5)

### Feels like / not like

**Like:**

**Not like:**

### Color direction (words)

**Primary:**

**Accent:**

**Avoid:**

### Typography feel

**Headlines:**

**Body:**

### Photography / illustration

**Style:**

**Subjects:**

**Avoid:**

### Texture & layout

### Sample image search phrases

1.
2.
3.

### Notes for production

---

## Part B — Presentation storyline

### Presentation title

### Audience

### Duration / slide count target

### Goal of the deck

### Storyline

| # | Slide headline (takeaway) | Key points on slide | Speaker notes |
| - | ------------------------- | ------------------- | ------------- |
| 1 | | | |
| 2 | | | |

### The ask (final slide)

### Backup slides (optional)

-

### Prep checklist

- [ ] Rehearse timing
- [ ] Export PDF
- [ ] Send pre-read if needed
