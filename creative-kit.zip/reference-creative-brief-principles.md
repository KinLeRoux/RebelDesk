---
type: note
title: Creative brief principles (reference)
category: Creative & client
tags: brief, creative, reference
searchable: true
---

# Creative brief principles (reference)

Turn chaos into a brief designers and writers can execute.

## Every strong brief answers

1. **Who is the client / brand?**  
2. **What are we making?** (deliverables + formats)  
3. **Who is it for?** (audience)  
4. **What should it achieve?** (one business goal)  
5. **What must be included?** (mandatories)  
6. **What is forbidden?** (legal, brand, taste)  
7. **When is it due?** (milestones)  
8. **How will we judge success?**

## From a client call — capture quotes

- Verbatim phrases for tone (“make it pop” → ask what that means).  
- List **decision makers** and who only gives opinions.  
- Note **competitors** they mention.

## Red flags to clarify

- “Make it viral” → pick one measurable action.  
- “Like Apple” → which aspect (minimal, premium, friendly)?  
- Unlimited revisions → suggest rounds.  
- Missing audience → stop until defined.

## Deliverables table (example)

| Item | Format | Size / length | Due |
| ---- | ------ | ------------- | --- |
| Hero concept | 2 routes | — | [date] |
| Final files | per spec | — | [date] |

## Prompts alone

- “Turn these call notes into a creative brief.”  
- “What questions should I email back before starting?”  
- “One-page brief for a rebrand + website copy.”

Output: **output-creative-brief.md**.
