---
type: note
title: Portfolio writeup — output template
category: Creative & client
tags: portfolio, case study, output
searchable: true
---

# Portfolio writeup — output template

_For website, PDF, or proposal — confirm client approval before publishing._

## Project title (headline)

## Client & industry

_(Anonymize if needed: “Global B2B SaaS”)_

## One-line teaser

## Challenge

## Your role & scope

## Approach

1.
2.
3.

## Deliverables

## Results

| Metric or outcome | |
| ----------------- | |

## Client quote

> “[Confirm before publish]”
> — Name, title

## Credits (team / tools if relevant)

## Gallery captions (optional)

| Image | Caption |
| ----- | ------- |
| | |
