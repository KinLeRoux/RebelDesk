---
type: note
title: Creative brief — output template
category: Creative & client
tags: brief, creative, output
searchable: true
---

# Creative brief — output template

_Filled in by the Creative & client coach (Mode 1)._

## Project

**Client:**

**Project name:**

**Date / version:**

## Objective (one sentence)

## Audience

## Deliverables

| Item | Format / specs | Due |
| ---- | -------------- | --- |
| | | |

## Mandatories (must include)

-

## Out of scope / don’ts

-

## Tone & brand notes

## References (client mentioned)

**Like:**

**Avoid:**

## Timeline & milestones

| Milestone | Date |
| --------- | ---- |
| | |

## Success criteria

## Open questions for client

1.

## Stakeholders

| Name / role | Decision maker? |
| ----------- | --------------- |
| | |
