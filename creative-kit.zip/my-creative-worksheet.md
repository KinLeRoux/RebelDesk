---
type: note
title: My creative worksheet
category: Creative & client
tags: creative, worksheet
searchable: true
---

# My creative worksheet

## Active projects

| Client | Deliverable | Due | Status |
| ------ | ----------- | --- | ------ |
| | | | |

## Call notes (scratch)

## Feedback waiting on

## Portfolio pieces to write

-

## Session log

| Date | Mode | Output |
| ---- | ---- | ------ |
| | | |
