---
type: note
title: Mood and visual direction (reference)
category: Creative & client
tags: mood, visual, direction, reference
searchable: true
---

# Mood and visual direction (reference)

**Words for look & feel** — for designers, photographers, or AI image briefs. No pixels required.

## Mood board in text

Combine:

- **3–5 mood words** (e.g. calm, artisan, bold)  
- **Feels like / not like** brands or films  
- **Color words** (not only hex — “warm terracotta, cream, charcoal”)  
- **Typography feel** (editorial serif, geometric sans, hand label)  
- **Photo / illustration** style  
- **Texture & shape** (rounded, grid, organic, gritty)

## Photo direction cheatsheet

| Mood | Lighting | Subject | Composition |
| ---- | -------- | ------- | ----------- |
| Premium | soft, controlled | detail shots | negative space |
| Friendly | natural, bright | people candid | eye-level |
| Bold | high contrast | strong shapes | tight crop |
| Natural | golden hour | outdoors | rule of thirds |

## For UI / digital

- Spacing: airy vs dense  
- Corners: sharp vs rounded  
- Illustration vs photography vs icon-only  
- Motion feel: snappy vs gentle (for brief only)

## Image search phrases

Give Pinterest/Stock keywords: e.g. “minimal skincare flat lay muted green” — helps juniors and clients align.

## Link to Brand kit

If **output-visual-identity-brief.md** or **output-brand-card.md** exists, extend — don’t contradict.

## Prompts alone

- “Mood narrative for a craft brewery rebrand — earthy, not hipster cliché.”  
- “Photo brief for B2B SaaS — trustworthy, diverse teams, no stock handshake.”

Output: **output-mood-board-narrative.md**.
