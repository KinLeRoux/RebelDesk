---
type: note
title: Start here — Creative & client kit
category: Creative & client
tags: creative, client, start
searchable: true
---

# Creative & client kit

For freelancers, studios, and in-house creatives — briefs, mood direction, decks, feedback rounds, and portfolio stories.

## Simple path

1. Install **Creative & client kit** in **Settings → Chat Settings → Memory packs**.
2. Tap **Start in chat**.
3. Press **Send** and pick your task.

Works even better with **Brand kit** (voice and brief attach when filled).

## What’s inside

| Kind | Use |
| ---- | --- |
| **Coach** | Client briefs, mood words, presentations, feedback, portfolio |
| **Research** | Brief principles, feedback triage, presentations & portfolio |
| **Extra reference** | Mood & visual direction (attach alone) |
