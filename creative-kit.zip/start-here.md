---
type: note
title: Start here — Creative & client kit
category: Creative & client
tags: creative, client, start
searchable: true
---

# Creative & client kit

For freelancers, studios, and in-house creatives — briefs, mood direction, decks, feedback rounds, and portfolio stories.

## Simple path

1. Install **Creative & client kit** in **Settings → Chat Settings → Memory packs**.
2. Tap **Start in chat**.
3. Press **Send** and pick your task.

Works even better with **Brand kit** (voice, brief, and visual identity attach when filled).

## What’s inside

| Kind | Use |
| ---- | --- |
| **Coach** | Client briefs, mood words, presentations, feedback, portfolio |
| **Creative guide** | One reference for briefs, mood, presentations, and feedback |

## Outputs

- **output-creative-brief.md** — structured client brief
- **output-creative-direction.md** — mood narrative or presentation storyline
- **output-client-delivery.md** — feedback triage or portfolio writeup

## Attach the guide alone

Example: attach **Creative guide** and ask *“Sort this client feedback into must-fix vs push back.”*
