---
type: note
title: Feedback triage — output template
category: Creative & client
tags: feedback, revisions, output
searchable: true
---

# Feedback triage — output template

## Project / round

**Date:**

**Source:** (client email / call / shared doc)

## Raw feedback (paste)

## Sorted

### Must-fix

-

### Clarify (questions to ask)

| Comment | Question |
| ------- | -------- |
| | |

### Push back (with rationale)

| Comment | Our response |
| ------- | ------------ |
| | |

### Later / v2

-

## Consolidated direction for team

## Draft reply to client (bullets)

-

## Internal time / scope note
