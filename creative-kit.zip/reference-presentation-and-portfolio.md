---
type: note
title: Presentation and portfolio (reference)
category: Creative & client
tags: presentation, portfolio, reference
searchable: true
---

# Presentation and portfolio (reference)

Decks and project stories — attach for **Creative & client coach** or alone.

## Presentation arc (default)

1. **Hook** — why listen (30 sec)  
2. **Problem** — their world today  
3. **Insight** — what you learned (research, brief)  
4. **Solution** — your concept / plan  
5. **Proof** — examples, metrics, testimonial  
6. **Process** — how you work (brief timeline)  
7. **Ask** — approval, budget, next step  

## Slide discipline

- **One idea per slide**  
- Headline = takeaway, not label (“Revenue up 40%” not “Results”)  
- Speaker notes: what to **say**, not paragraph on slide  
- 10–15 slides for 20–30 min pitch typical  

## Portfolio case study structure

| Block | Content |
| ----- | ------- |
| Headline | Outcome or hook |
| Client & context | Industry, constraint |
| Challenge | Before state |
| Your role | Scope honestly |
| Approach | 3 bullets max |
| Outcome | Numbers if real |
| Quote | [client confirm] |

## Proposal vs portfolio

- **Proposal** = why hire you for *upcoming* work.  
- **Portfolio piece** = what you did for *past* work.

## Prompts alone

- “Storyline for a 12-slide brand pitch to a CEO.”  
- “Portfolio blurb for a packaging project — sustainable food startup.”  
- “Speaker notes for slides I’ll paste next message.”

Outputs: **output-presentation-storyline.md**, **output-portfolio-writeup.md**.
