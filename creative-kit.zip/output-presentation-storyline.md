---
type: note
title: Presentation storyline — output template
category: Creative & client
tags: presentation, slides, output
searchable: true
---

# Presentation storyline — output template

## Presentation title

## Audience

## Duration / slide count target

## Goal of the deck

## Storyline

| # | Slide headline (takeaway) | Key points on slide | Speaker notes |
| - | ------------------------- | ------------------- | ------------- |
| 1 | | | |
| 2 | | | |

## The ask (final slide)

## Backup slides (optional)

-

## Prep checklist

- [ ] Rehearse timing
- [ ] Export PDF
- [ ] Send pre-read if needed
