---
type: note
title: Client delivery — output template
category: Creative & client
tags: feedback, revisions, portfolio, case study, output
searchable: true
---

# Client delivery — output template

_Filled in by the Creative & client coach. Use Part A for feedback triage and revision rounds; use Part B for portfolio and case study writeups._

---

## Part A — Feedback triage

### Project / round

**Date:**

**Source:** (client email / call / shared doc)

### Raw feedback (paste)

### Sorted

#### Must-fix

-

#### Clarify (questions to ask)

| Comment | Question |
| ------- | -------- |
| | |

#### Push back (with rationale)

| Comment | Our response |
| ------- | ------------ |
| | |

#### Later / v2

-

### Consolidated direction for team

### Draft reply to client (bullets)

-

### Internal time / scope note

---

## Part B — Portfolio writeup

_For website, PDF, or proposal — confirm client approval before publishing._

### Project title (headline)

### Client & industry

_(Anonymize if needed: “Global B2B SaaS”)_

### One-line teaser

### Challenge

### Your role & scope

### Approach

1.
2.
3.

### Deliverables

### Results

| Metric or outcome | |
| ----------------- | |

### Client quote

> “[Confirm before publish]”
> — Name, title

### Credits (team / tools if relevant)

### Gallery captions (optional)

| Image | Caption |
| ----- | ------- |
| | |
