---
type: note
title: Client feedback and revisions (reference)
category: Creative & client
tags: feedback, client, revisions, reference
searchable: true
---

# Client feedback and revisions (reference)

Sort feedback so you stay sane and the client feels heard.

## Four buckets

| Bucket | Meaning | Action |
| ------ | ------- | ------ |
| **Must-fix** | Wrong fact, off-brief, legal, broken UX | Do in this round |
| **Clarify** | Vague (“make it bolder”) | Ask one question or offer 2 options |
| **Push back** | Out of scope or weakens work | Explain trade-off politely |
| **Later** | Good idea, not this phase | Park for v2 |

## Responding well

- Thank them; mirror priority (“We’ll tackle X and Y first”).  
- No defensive tone; use **we**.  
- Offer **structured choices** (A vs B), not open-ended “what do you think?”  
- Reference the **approved brief** when pushing back.

## Revision round hygiene

- Number rounds in contract when possible (e.g. 2 included).  
- Batch feedback — one email, not 12 DMs.  
- Confirm **one decision-maker** signs off.

## Common client lines decoded

| They say | Often means |
| -------- | ----------- |
| “Pop more” | contrast, color, or size — ask which |
| “Modern” | cleaner layout, sans type, more whitespace |
| “Friendlier” | rounder shapes, warmer copy, faces |
| “Just one small change” | still track time; may cascade |

## Prompts alone

- “Sort this feedback into four buckets and draft a reply.”  
- “Client wants 15 rounds — suggest boundary email.”  
- “Merge conflicting comments from two stakeholders.”

Output: **output-feedback-triage.md**.
