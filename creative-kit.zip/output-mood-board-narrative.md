---
type: note
title: Mood board narrative — output template
category: Creative & client
tags: mood, visual, output
searchable: true
---

# Mood board narrative — output template

_Words for look & feel — share with designer, photographer, or client._

## Project link

## Mood in one line

## Mood words (3–5)

## Feels like / not like

**Like:**

**Not like:**

## Color direction (words)

**Primary:**

**Accent:**

**Avoid:**

## Typography feel

**Headlines:**

**Body:**

## Photography / illustration

**Style:**

**Subjects:**

**Avoid:**

## Texture & layout

## Sample image search phrases

1.
2.
3.

## Notes for production
