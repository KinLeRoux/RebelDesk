---
type: note
title: Creative guide (reference)
category: Creative & client
tags: brief, creative, feedback, presentation, mood, reference
searchable: true
---

# Creative guide (reference)

Briefs, mood direction, presentations, portfolio stories, and client feedback — attach for the **Creative & client coach** or alone.

---

## Creative brief principles

Turn chaos into a brief designers and writers can execute.

### Every strong brief answers

1. **Who is the client / brand?**
2. **What are we making?** (deliverables + formats)
3. **Who is it for?** (audience)
4. **What should it achieve?** (one business goal)
5. **What must be included?** (mandatories)
6. **What is forbidden?** (legal, brand, taste)
7. **When is it due?** (milestones)
8. **How will we judge success?**

### From a client call — capture quotes

- Verbatim phrases for tone (“make it pop” → ask what that means).
- List **decision makers** and who only gives opinions.
- Note **competitors** they mention.

### Red flags to clarify

- “Make it viral” → pick one measurable action.
- “Like Apple” → which aspect (minimal, premium, friendly)?
- Unlimited revisions → suggest rounds.
- Missing audience → stop until defined.

### Deliverables table (example)

| Item | Format | Size / length | Due |
| ---- | ------ | ------------- | --- |
| Hero concept | 2 routes | — | [date] |
| Final files | per spec | — | [date] |

---

## Mood and visual direction

**Words for look & feel** — for designers, photographers, or AI image briefs. No pixels required.

### Mood board in text

Combine:

- **3–5 mood words** (e.g. calm, artisan, bold)
- **Feels like / not like** brands or films
- **Color words** (not only hex — “warm terracotta, cream, charcoal”)
- **Typography feel** (editorial serif, geometric sans, hand label)
- **Photo / illustration** style
- **Texture & shape** (rounded, grid, organic, gritty)

### Photo direction cheatsheet

| Mood | Lighting | Subject | Composition |
| ---- | -------- | ------- | ----------- |
| Premium | soft, controlled | detail shots | negative space |
| Friendly | natural, bright | people candid | eye-level |
| Bold | high contrast | strong shapes | tight crop |
| Natural | golden hour | outdoors | rule of thirds |

### For UI / digital

- Spacing: airy vs dense
- Corners: sharp vs rounded
- Illustration vs photography vs icon-only
- Motion feel: snappy vs gentle (for brief only)

### Image search phrases

Give Pinterest/Stock keywords: e.g. “minimal skincare flat lay muted green” — helps juniors and clients align.

### Link to Brand kit

If **output-visual-brand-identity.md** exists, extend — don’t contradict.

---

## Presentation and portfolio

Decks and project stories.

### Presentation arc (default)

1. **Hook** — why listen (30 sec)
2. **Problem** — their world today
3. **Insight** — what you learned (research, brief)
4. **Solution** — your concept / plan
5. **Proof** — examples, metrics, testimonial
6. **Process** — how you work (brief timeline)
7. **Ask** — approval, budget, next step

### Slide discipline

- **One idea per slide**
- Headline = takeaway, not label (“Revenue up 40%” not “Results”)
- Speaker notes: what to **say**, not paragraph on slide
- 10–15 slides for 20–30 min pitch typical

### Portfolio case study structure

| Block | Content |
| ----- | ------- |
| Headline | Outcome or hook |
| Client & context | Industry, constraint |
| Challenge | Before state |
| Your role | Scope honestly |
| Approach | 3 bullets max |
| Outcome | Numbers if real |
| Quote | [client confirm] |

### Proposal vs portfolio

- **Proposal** = why hire you for *upcoming* work.
- **Portfolio piece** = what you did for *past* work.

---

## Client feedback and revisions

Sort feedback so you stay sane and the client feels heard.

### Four buckets

| Bucket | Meaning | Action |
| ------ | ------- | ------ |
| **Must-fix** | Wrong fact, off-brief, legal, broken UX | Do in this round |
| **Clarify** | Vague (“make it bolder”) | Ask one question or offer 2 options |
| **Push back** | Out of scope or weakens work | Explain trade-off politely |
| **Later** | Good idea, not this phase | Park for v2 |

### Responding well

- Thank them; mirror priority (“We’ll tackle X and Y first”).
- No defensive tone; use **we**.
- Offer **structured choices** (A vs B), not open-ended “what do you think?”
- Reference the **approved brief** when pushing back.

### Revision round hygiene

- Number rounds in contract when possible (e.g. 2 included).
- Batch feedback — one email, not 12 DMs.
- Confirm **one decision-maker** signs off.

### Common client lines decoded

| They say | Often means |
| -------- | ----------- |
| “Pop more” | contrast, color, or size — ask which |
| “Modern” | cleaner layout, sans type, more whitespace |
| “Friendlier” | rounder shapes, warmer copy, faces |
| “Just one small change” | still track time; may cascade |

---

## Prompts alone

- “Turn these call notes into a creative brief.”
- “Mood narrative for a craft brewery rebrand — earthy, not hipster cliché.”
- “Storyline for a 12-slide brand pitch to a CEO.”
- “Sort this feedback into four buckets and draft a reply.”
- “Portfolio blurb for a packaging project — sustainable food startup.”

**Outputs:** **output-creative-brief.md**, **output-creative-direction.md**, **output-client-delivery.md**.
