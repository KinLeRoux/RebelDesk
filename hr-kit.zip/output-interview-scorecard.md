---
type: note
title: Interview scorecard — output template
category: Human resources
tags: interview, hiring, output
searchable: true
---

# Interview scorecard — output template

## Role & stage

**Role:**

**Stage:** (phone / interview 1 / panel / practical)

**Duration:**

**Interviewers:**

## Competencies we’re assessing

1.
2.
3.

## Questions & scorecard

| Competency | Question | Strong signals (4–5) | Adequate (3) | Concern (1–2) | Score |
| ---------- | -------- | -------------------- | ------------ | ------------- | ----- |
| | | | | | |
| | | | | | |

## Practical / work sample (if any)

**Task:**

**What we evaluate:**

## Candidate questions they asked

## Overall recommendation

- [ ] Strong yes
- [ ] Yes
- [ ] Hold — need another interview
- [ ] No

**Summary notes:**

## Next steps
