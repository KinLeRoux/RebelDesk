---
type: note
title: Hiring and interviews (reference)
category: Human resources
tags: hiring, interview, reference
searchable: true
---

# Hiring and interviews (reference)

Attach for **Mode 2**, **Mode 4**, or posting polish.

## Job posting structure (external)

1. **Hook** — why the role matters (1–2 lines)  
2. **What you’ll do** — outcomes + sample tasks  
3. **What we’re looking for** — must-haves, nice-to-haves  
4. **About us** — short, honest  
5. **Practicals** — location, type, start window (salary range if you publish one — [confirm])  
6. **How to apply** — one clear CTA

Keep scannable: bullets, short paragraphs, inclusive **you/we** language.

## Inclusive hiring basics

- Describe **job requirements**, not stereotyped “culture fit” that excludes.  
- Avoid coded language (“ninja,” “young team,” “native speaker” unless truly required).  
- Same questions for all candidates at the same stage (**scorecard**).  
- Focus on **past behavior** and work samples where possible.

## Questions to avoid (many regions)

Marital status, age, religion, plans for children, health/disability (unless reasonable accommodation process), nationality except where work authorization is legally required.

When unsure → **reference-employment-compliance-reminders.md** + professional counsel.

## Interview scorecard pieces

| Competency | Sample question | Strong answer signals | Concerns |
| ---------- | --------------- | --------------------- | -------- |
| e.g. Client communication | “Tell me about a time you…” | Specific story, role clarity | Vague, blames only others |

**Stages:** screen (15–20 min) → deep dive (45–60) → practical/task (if role needs it).

## After interview

- Notes within 24 hours.  
- Compare to scorecard, not gut alone.  
- Debrief hiring manager + one other interviewer when possible.

## Prompts alone

- “Rewrite this posting to sound warmer but still professional.”  
- “Scorecard for office manager — customer focus + Excel comfort.”  
- “Phone screen questions for junior designer.”
