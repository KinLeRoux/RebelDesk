---
type: note
title: KPIs and performance goals (reference)
category: Human resources
tags: kpi, performance, reference
searchable: true
---

# KPIs and performance goals (reference)

Attach for **Mode 3** or when refining reviews.

## KPI vs goal

| Term | Meaning |
| ---- | ------- |
| **Goal** | Direction — “Improve client retention” |
| **KPI** | Measurable signal — “Churn rate ≤ 4% monthly” |

Good KPIs are **specific, trackable, owned, and reviewed** on a rhythm (weekly / monthly / quarterly).

## SMART-ish checklist (plain)

- **Specific** — what exactly is measured?  
- **Measurable** — number or clear yes/no milestone  
- **Achievable** — stretch OK, fantasy not  
- **Relevant** — ties to role and business  
- **Time-bound** — by when?

## Types of metrics

| Type | Example |
| ---- | ------- |
| **Output** | Units shipped, tickets closed |
| **Quality** | Error rate, CSAT, rework % |
| **Efficiency** | Cycle time, cost per unit |
| **Growth** | Pipeline added, skills certified |
| **Behavior** | Use sparingly — define observable behaviors |

## KPI table template

| KPI | Definition | Target | How measured | Cadence |
| --- | ---------- | ------ | ------------ | ------- |
| | | | | |

## Common mistakes

- Too many KPIs (7+ dilutes focus) — **3–7** per role is plenty.  
- Vanity metrics (page views with no business link).  
- KPIs the employee cannot influence.  
- Moving targets mid-quarter without discussion.

## Review cadence

| Rhythm | Use for |
| ------ | ------- |
| Weekly | Ops roles, short-cycle teams |
| Monthly | Most individual contributors |
| Quarterly | Strategic outcomes, OKR-style alignment |
| Annual | Compensation, promotion, career narrative |

## Prompts alone

- “Five KPIs for a part-time bookkeeper at a 10-person agency.”  
- “This KPI is vague — make it measurable.”  
- “Split KPIs for sales vs customer success on this hybrid JD.”
