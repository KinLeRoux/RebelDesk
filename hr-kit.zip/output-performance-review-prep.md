---
type: note
title: Performance review prep — output template
category: Human resources
tags: performance review, output
searchable: true
---

# Performance review prep — output template

_Not a final rating form — prep for a fair conversation._

## Review details

**Employee:**

**Role:**

**Period:**

**Review type:** (annual / mid-year / probation)

**Prepared by:** (manager / self / both)

## Highlights & evidence

| Outcome / KPI | Evidence (projects, metrics, feedback) |
| ------------- | -------------------------------------- |
| | |

## What went well

-

## What to improve (specific, actionable)

-

## Goals for next period

1.
2.
3.

## Development & support needed

-

## Employee talking points (if self-prep)

-

## Manager talking points

-

## Questions to ask each other

-

## Follow-up after meeting

| Action | Owner | By when |
| ------ | ----- | ------- |
| | | |
