---
type: note
title: New hire onboarding — output template
category: Human resources
tags: onboarding, output
searchable: true
---

# New hire onboarding — output template

## New hire

**Name:**

**Role:**

**Start date:**

**Manager:**

**Buddy / mentor:**

## Before day 1

- [ ] Offer / contract signed [confirm with HR]
- [ ] Equipment & accounts ordered
- [ ] Workspace / remote setup
- [ ] Welcome email scheduled
- [ ] Day-1 agenda sent

## Day 1

- [ ] Welcome & team intros
- [ ] HR / policies overview [confirm materials]
- [ ] Tool access verified
- [ ] Role expectations conversation

## Week 1

- [ ] Key meetings scheduled
- [ ] First small win defined
- [ ] Training plan started

## Day 30 check-in

**Goals met:**

**Blockers:**

**Adjustments:**

## Day 90 check-in

**Outcomes vs job description:**

**KPI baseline set?** (link **output-role-kpis.md**)

**Still on track for role success:**

## Internal contacts

| Area | Who |
| ---- | --- |
| IT | |
| HR | |
| Payroll | |
