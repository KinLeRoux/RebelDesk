---
type: note
title: Job description — output template
category: Human resources
tags: job description, output
searchable: true
---

# Job description — output template

_Internal job card / position profile._

## Role

**Title:**

**Department / team:**

**Reports to:**

**Employment type:** (full-time / part-time / contract)

**Location:**

**Level:** (junior / mid / senior / lead)

## Role purpose

## Key outcomes (90 days+)

1.
2.
3.

## Responsibilities

-

## Must-have skills & experience

-

## Nice-to-have

-

## Tools & systems

-

## Working conditions (if relevant)

## Success in first 90 days

## Version

**Draft date:**

**Approved by:** [confirm]
