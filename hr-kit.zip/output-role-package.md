---
type: note
title: Role package — output template
category: Human resources
tags: job description, job posting, kpi, output
searchable: true
---

# Role package — output template

_Combined internal job card, external posting, and role KPIs._

## Role overview

**Title:**

**Department / team:**

**Reports to:**

**Employment type:** (full-time / part-time / contract)

**Location:**

**Level:** (junior / mid / senior / lead)

## Role purpose

## Key outcomes (90 days+)

1.
2.
3.

## Responsibilities

-

## Must-have skills & experience

-

## Nice-to-have

-

## Tools & systems

-

## Success in first 90 days

---

## External job posting

_Review for inclusive language and local law before publishing._

### Headline

### The opportunity (hook)

### What you'll do

-

### What we're looking for

**Must-have:**

-

**Nice-to-have:**

-

### About us

### Practical details

| Item | |
| ---- | |
| Location | |
| Type | |
| Start | |
| Compensation | [confirm if published] |

### How to apply

### Equal opportunity note

[Add your company's standard EEO / inclusion statement — confirm with HR]

---

## Role KPIs

**Review period:** (e.g. Q2 2026)

**Manager:**

### Business context this period

### KPIs

| # | KPI | Definition | Target | How measured | Cadence |
| - | --- | ---------- | ------ | ------------ | ------- |
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

### Development goals (learning / behavior)

1.

### Not in scope / deprioritized

-

## Version

**Draft date:**

**Approved by:** [confirm]
