---
type: note
title: Hiring & onboarding — output template
category: Human resources
tags: interview, onboarding, hiring, output
searchable: true
---

# Hiring & onboarding — output template

_Combined interview scorecard and new-hire onboarding checklist._

## Role

**Title:**

**Start date (if known):**

**Manager:**

---

## Interview scorecard

**Stage:** (phone / interview 1 / panel / practical)

**Duration:**

**Interviewers:**

### Competencies we're assessing

1.
2.
3.

### Questions & scorecard

| Competency | Question | Strong signals (4–5) | Adequate (3) | Concern (1–2) | Score |
| ---------- | -------- | -------------------- | ------------ | ------------- | ----- |
| | | | | | |
| | | | | | |

### Practical / work sample (if any)

**Task:**

**What we evaluate:**

### Candidate questions they asked

### Overall recommendation

- [ ] Strong yes
- [ ] Yes
- [ ] Hold — need another interview
- [ ] No

**Summary notes:**

### Next steps

---

## New hire onboarding

**Name:**

**Buddy / mentor:**

### Before day 1

- [ ] Offer / contract signed [confirm with HR]
- [ ] Equipment & accounts ordered
- [ ] Workspace / remote setup
- [ ] Welcome email scheduled
- [ ] Day-1 agenda sent

### Day 1

- [ ] Welcome & team intros
- [ ] HR / policies overview [confirm materials]
- [ ] Tool access verified
- [ ] Role expectations conversation

### Week 1

- [ ] Key meetings scheduled
- [ ] First small win defined
- [ ] Training plan started

### Day 30 check-in

**Goals met:**

**Blockers:**

**Adjustments:**

### Day 90 check-in

**Outcomes vs job description:**

**KPI baseline set?** (link **output-role-package.md**)

**Still on track for role success:**

### Internal contacts

| Area | Who |
| ---- | --- |
| IT | |
| HR | |
| Payroll | |
