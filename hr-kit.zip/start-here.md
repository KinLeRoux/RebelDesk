---
type: note
title: Start here — Human resources kit
category: Human resources
tags: hr, start
searchable: true
---

# Human resources kit

Job descriptions, postings, KPIs, interview guides, new-hire onboarding, and performance review prep — in plain language for small teams.

**Not legal or employment-law advice.** Templates are general; confirm policies with qualified HR or legal counsel in your country.

## Simple path

1. **Settings → Chat Settings → Memory packs** → install **Human resources kit**.
2. Tap **Start in chat**.
3. Press **Send** and pick what you need.

## What’s inside

| Kind | Use |
| ---- | --- |
| **HR coach** | Step-by-step for each HR writing task |
| **Research** | Job descriptions, KPIs, hiring interviews |
| **output-*** | Job card, posting, KPIs, scorecard, onboarding, review prep |

## Example later

Attach **KPIs and performance goals** alone and say: *“Turn this role into 5 measurable KPIs for a quarterly review.”*
