---
type: note
title: My HR worksheet
category: Human resources
tags: hr, worksheet
searchable: true
---

# My HR worksheet

## Open roles

| Title | Status | Target start |
| ----- | ------ | ------------ |
| | | |

## Candidates in pipeline

| Name | Role | Stage | Next step |
| ---- | ---- | ----- | --------- |
| | | | |

## KPIs to revisit this quarter

-

## Policy / legal questions for counsel

-

## Session log

| Date | Mode | Output file |
| ---- | ---- | ----------- |
| | | |
