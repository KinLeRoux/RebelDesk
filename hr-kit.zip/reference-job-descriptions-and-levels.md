---
type: note
title: Job descriptions and levels (reference)
category: Human resources
tags: job description, role, reference
searchable: true
---

# Job descriptions and levels (reference)

Internal **job card** vs external **posting** — attach for **Mode 1** or solo.

## Job card (internal)

Answers: *What does this role exist to achieve? Who is it for?*

| Section | Content |
| ------- | ------- |
| Role title | Clear, one title (avoid “rockstar”) |
| Department / team | |
| Reports to | Role, not only a name |
| Employment type | Full-time, part-time, contract |
| Location | On-site, hybrid, remote |
| Role purpose | 2–3 sentences — outcomes, not task laundry |
| Key outcomes | 3–5 bullets — “By end of quarter…” |
| Responsibilities | 5–8 bullets, verb-led |
| Must-have skills | Hard requirements |
| Nice-to-have | Trainable or bonus |
| Tools & systems | CRM, ERP, etc. |
| Level | See levels below |
| Success in 90 days | Onboarding bar |

## Level hints (plain language)

| Level | Typical signals |
| ----- | ---------------- |
| **Junior** | Executes defined tasks; learns tools; needs guidance |
| **Mid** | Owns a workstream; minimal daily direction |
| **Senior** | Shapes approach; mentors others; handles ambiguity |
| **Lead / manager** | People or project ownership; prioritization; hiring input |

## Writing tips

- **Outcomes before tasks** — “Grow newsletter to 5k subs” beats “write newsletters.”  
- **One role per card** — split hybrid roles if they hire separately.  
- **Avoid internal jargon** in postings; keep jargon in internal card if needed.  
- **Physical requirements** only if truly essential — describe the task, not a person type.

## Prompts alone

- “Turn these bullets into a job card for a warehouse supervisor.”  
- “What’s missing from this JD for a customer support lead?”  
- “Same role but senior level — what changes?”
