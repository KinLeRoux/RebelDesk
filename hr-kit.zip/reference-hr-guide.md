---
type: note
title: HR guide (reference)
category: Human resources
tags: job description, kpi, hiring, interview, compliance, reference
searchable: true
---

# HR guide (reference)

One guide for the **Human resources coach** — job cards, KPIs, hiring, interviews, and compliance reminders.

## Part A — Job descriptions and levels

Internal **job card** vs external **posting**.

### Job card (internal)

Answers: *What does this role exist to achieve? Who is it for?*

| Section | Content |
| ------- | ------- |
| Role title | Clear, one title (avoid "rockstar") |
| Department / team | |
| Reports to | Role, not only a name |
| Employment type | Full-time, part-time, contract |
| Location | On-site, hybrid, remote |
| Role purpose | 2–3 sentences — outcomes, not task laundry |
| Key outcomes | 3–5 bullets — "By end of quarter…" |
| Responsibilities | 5–8 bullets, verb-led |
| Must-have skills | Hard requirements |
| Nice-to-have | Trainable or bonus |
| Tools & systems | CRM, ERP, etc. |
| Level | See levels below |
| Success in 90 days | Onboarding bar |

### Level hints (plain language)

| Level | Typical signals |
| ----- | ---------------- |
| **Junior** | Executes defined tasks; learns tools; needs guidance |
| **Mid** | Owns a workstream; minimal daily direction |
| **Senior** | Shapes approach; mentors others; handles ambiguity |
| **Lead / manager** | People or project ownership; prioritization; hiring input |

### Writing tips

- **Outcomes before tasks** — "Grow newsletter to 5k subs" beats "write newsletters."
- **One role per card** — split hybrid roles if they hire separately.
- **Avoid internal jargon** in postings; keep jargon in internal card if needed.
- **Physical requirements** only if truly essential — describe the task, not a person type.

## Part B — KPIs and performance goals

### KPI vs goal

| Term | Meaning |
| ---- | ------- |
| **Goal** | Direction — "Improve client retention" |
| **KPI** | Measurable signal — "Churn rate ≤ 4% monthly" |

Good KPIs are **specific, trackable, owned, and reviewed** on a rhythm (weekly / monthly / quarterly).

### SMART-ish checklist (plain)

- **Specific** — what exactly is measured?
- **Measurable** — number or clear yes/no milestone
- **Achievable** — stretch OK, fantasy not
- **Relevant** — ties to role and business
- **Time-bound** — by when?

### Types of metrics

| Type | Example |
| ---- | ------- |
| **Output** | Units shipped, tickets closed |
| **Quality** | Error rate, CSAT, rework % |
| **Efficiency** | Cycle time, cost per unit |
| **Growth** | Pipeline added, skills certified |
| **Behavior** | Use sparingly — define observable behaviors |

### KPI table template

| KPI | Definition | Target | How measured | Cadence |
| --- | ---------- | ------ | ------------ | ------- |

### Common mistakes

- Too many KPIs (7+ dilutes focus) — **3–7** per role is plenty.
- Vanity metrics (page views with no business link).
- KPIs the employee cannot influence.
- Moving targets mid-quarter without discussion.

### Review cadence

| Rhythm | Use for |
| ------ | ------- |
| Weekly | Ops roles, short-cycle teams |
| Monthly | Most individual contributors |
| Quarterly | Strategic outcomes, OKR-style alignment |
| Annual | Compensation, promotion, career narrative |

## Part C — Hiring and interviews

### Job posting structure (external)

1. **Hook** — why the role matters (1–2 lines)
2. **What you'll do** — outcomes + sample tasks
3. **What we're looking for** — must-haves, nice-to-haves
4. **About us** — short, honest
5. **Practicals** — location, type, start window (salary range if you publish one — [confirm])
6. **How to apply** — one clear CTA

Keep scannable: bullets, short paragraphs, inclusive **you/we** language.

### Inclusive hiring basics

- Describe **job requirements**, not stereotyped "culture fit" that excludes.
- Avoid coded language ("ninja," "young team," "native speaker" unless truly required).
- Same questions for all candidates at the same stage (**scorecard**).
- Focus on **past behavior** and work samples where possible.

### Questions to avoid (many regions)

Marital status, age, religion, plans for children, health/disability (unless reasonable accommodation process), nationality except where work authorization is legally required.

### Interview scorecard pieces

| Competency | Sample question | Strong answer signals | Concerns |
| ---------- | --------------- | --------------------- | -------- |
| e.g. Client communication | "Tell me about a time you…" | Specific story, role clarity | Vague, blames only others |

**Stages:** screen (15–20 min) → deep dive (45–60) → practical/task (if role needs it).

### After interview

- Notes within 24 hours.
- Compare to scorecard, not gut alone.
- Debrief hiring manager + one other interviewer when possible.

## Part D — Employment compliance reminders

**General reminders only; not legal advice.** Confirm with qualified HR and employment lawyers in your country/state.

### Topics that need professional counsel

- Contracts & offer letters
- Termination, layoffs, redundancy
- Discrimination, harassment, accommodations
- Wage/hour, overtime, classification (employee vs contractor)
- Collective agreements, works councils, union rules
- Visa / work authorization
- Background checks & privacy (GDPR, etc.)

### Fair documentation habits

- Keep **job-related** criteria in hiring and reviews.
- Store interview notes consistently.
- Avoid casual chat that could be misread as decisions already made.

### Performance & PIP

Performance improvement plans vary by jurisdiction and company policy. Coach can help **structure goals and check-ins** — not declare someone "fired" or "safe to dismiss."

## Prompts alone

- "Turn these bullets into a job card for a warehouse supervisor."
- "Five KPIs for a part-time bookkeeper at a 10-person agency."
- "Scorecard for office manager — customer focus + Excel comfort."
- "What should I ask legal before posting this role in Germany?" → list topics, not legal answers.
