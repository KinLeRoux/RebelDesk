---
type: note
title: Employment compliance reminders (reference)
category: Human resources
tags: compliance, legal, reference
searchable: true
---

# Employment compliance reminders (reference)

**Attach when needed** — not included in default **Start in chat**. General reminders only; **not legal advice.**

## Always say when topics touch law

- Contracts & offer letters  
- Termination, layoffs, redundancy  
- Discrimination, harassment, accommodations  
- Wage/hour, overtime, classification (employee vs contractor)  
- Collective agreements, works councils, union rules  
- Visa / work authorization  
- Background checks & privacy (GDPR, etc.)

→ User should confirm with **qualified HR and employment lawyers** in their country/state.

## Fair documentation habits

- Keep **job-related** criteria in hiring and reviews.  
- Store interview notes consistently.  
- Avoid casual chat that could be misread as decisions already made.

## Performance & PIP

Performance improvement plans vary by jurisdiction and company policy. Coach can help **structure goals and check-ins** — not declare someone “fired” or “safe to dismiss.”

## Prompts alone

- “What should I ask legal before posting this role in Germany?” → list topics, not legal answers.  
- “Checklist before first hire in a US LLC” → general topics (EIN, workers comp, handbook) with counsel disclaimer.
