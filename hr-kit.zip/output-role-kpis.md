---
type: note
title: Role KPIs — output template
category: Human resources
tags: kpi, performance, output
searchable: true
---

# Role KPIs — output template

## Role & period

**Role title:**

**Review period:** (e.g. Q2 2026)

**Manager:**

## Role purpose (one line)

## Business context this period

## KPIs

| # | KPI | Definition | Target | How measured | Cadence |
| - | --- | ---------- | ------ | ------------ | ------- |
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

## Development goals (learning / behavior)

1.

## Not in scope / deprioritized

-

## Review notes

| Date | Check-in summary |
| ---- | ---------------- |
| | |
