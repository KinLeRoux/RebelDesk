---
type: note
title: Job posting — output template
category: Human resources
tags: job posting, hiring, output
searchable: true
---

# Job posting — output template

_External ad — review for inclusive language and local law before publishing._

## Headline

## The opportunity (hook)

## What you’ll do

-

## What we’re looking for

**Must-have:**

-

**Nice-to-have:**

-

## About us

## Practical details

| Item | |
| ---- | |
| Location | |
| Type | |
| Start | |
| Compensation | [confirm if published] |

## How to apply

## Equal opportunity note

[Add your company’s standard EEO / inclusion statement — confirm with HR]
