---
type: note
title: Learning guide (reference)
category: Hobbies & learning kit
tags: learning, practice, resources, personal, reference
searchable: true
---

# Learning guide (reference)

How adults learn, practice effectively, and pick resources — plain language for busy people.

## How adults learn

### What works for busy people

- **Specific goal:** “Play 3 songs on guitar” beats “learn guitar.”  
- **Spaced repetition:** short sessions most days > one long weekend.  
- **Active practice:** doing > watching. Cap passive video at ~30% of time.  
- **Feedback loop:** record yourself, checklist, or simple rubric weekly.

### Realistic time budgets

| Minutes/day | Good for |
| ----------- | -------- |
| 10–15 | Maintenance, vocab, one drill |
| 20–30 | Solid hobby progress |
| 45–60 | Serious sprint (hard to sustain) |

### Motivation leaks

- No clear “done for today”  
- Tool/course hopping  
- Comparing to experts on day 3  
- Skipping sleep (hurts memory)

### First week design

One **visible win**: perform, show, or ship something tiny (phrase, stitch, chord, hello world).

### When to slow down

Illness, life crunch — halve minutes, keep the chain (even 5 min counts).

---

## Practice and feedback

### Deliberate practice (simple)

1. **Isolate** one sub-skill (not whole piece).  
2. **Slow** until clean, then speed up.  
3. **Repeat** until boring-then-automatic.  
4. **Test** in a slightly harder context.

### Session template (25–30 min)

| Block | Time | Focus |
| ----- | ---- | ----- |
| Warm-up | 3 min | Easy review |
| Core drill | 15 min | One weakness |
| Apply | 7 min | Song, sentence, project slice |
| Cool-down | 2 min | Note what improved |

### Feedback without a coach

- Phone video / mirror  
- Checklist rubric (0–3 per criterion)  
- Peer swap (language exchange, jam buddy)  
- “Teach back” — explain step aloud

### Plateau fixes

- Change input (different genre, topic, tool)  
- Smaller chunk size  
- Sleep on it — don’t grind 3 hours once  
- Return to fundamentals 1 session/week

### Avoid

Only consuming content.  
Practicing only what’s already easy.  
No log → can’t see progress.

---

## Learning resources

Pick **one primary** path + **one backup**. More tabs = slower progress.

### Resource types

| Type | Best for | Watch out |
| ---- | -------- | --------- |
| Structured course | Beginners wanting path | Never finishing module 2 |
| Book + exercises | Deep concepts | No accountability |
| App (language, music) | Daily streak | Subscription creep |
| YouTube / free | Tips, inspiration | Rabbit holes |
| Community / class | Accountability | Schedule fit |
| Project tutorial | Coding, crafts | Copy-paste without understanding |

### Selection questions

1. Do I learn better watching, reading, or doing?  
2. Free-only or budget [TBD]?  
3. Need human feedback (tutor, class)?  
4. Offline possible?

### Language (patterns, not endorsements)

Apps for drills + tutor/community for speaking.  
Label media by level; don’t start with native news on day 1.

### Music / craft

One method book OR one online series — master Week 1 before buying more gear.

### Document choices

In **output-progress-and-resources.md**: name, cost, time/week, start here, quit if…

### Pair with other kits

- **Daily habit chain** → Wellness & habits kit (**output-habit-plan.md**)  
- **Week structure** → Personal & life kit (**output-personal-week-planner.md**)  
- **90-day life project** → Life transitions kit
