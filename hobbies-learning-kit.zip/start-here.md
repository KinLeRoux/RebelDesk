---
type: note
title: Start here — Hobbies & learning kit
category: Hobbies & learning kit
tags: personal, learning, start
searchable: true
---

# Start here — Hobbies & learning kit

Learn languages, instruments, crafts, or any skill with a **realistic plan** and short daily practice — not endless course shopping. Two combined outputs plus links to **Wellness & habits** and **Personal & life** planners.

**Memory packs** → install **Hobbies & learning kit** → **Start in chat** → pick a mode (30-day sprint, practice schedule, resources, etc.).

Under **Personal** in the pack picker.
