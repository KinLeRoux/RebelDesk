---
type: note
title: Progress and resources — output template
category: Hobbies & learning kit
tags: progress, resources, learning, output, personal
searchable: true
---

# Progress and resources — output template

## Skill progress log

### Skill

### Started

| Date | Minutes | What I practiced | Felt (1–5) | Next tweak |
| ---- | ------- | ---------------- | ---------- | ---------- |
| | | | | |

### Milestones hit

- [ ]

### Plateau notes

### What to practice next week

---

## Learning resource map

### Skill

### Primary resource (start here)

| Name | Type | Cost | Time/week | Link / where |
| ---- | ---- | ---- | --------- | ------------ |
| | | | | |

### Backup resource

| Name | Type | When to use |
| ---- | ---- | ----------- |
| | | |

### Community / feedback

### Stop using if…

### Resources I’m **not** buying yet (avoid overload)
