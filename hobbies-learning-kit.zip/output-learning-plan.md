---
type: note
title: Learning plan — output template
category: Hobbies & learning kit
tags: learning, plan, practice, output, personal
searchable: true
---

# Learning plan — output template

## Learning snapshot

### Skill / topic

### Why I’m learning it

### Current level (honest)

### Minutes per day (realistic)

### Target in 30 days

### Biggest blocker

### First micro-win (week 1)

---

## 30-day plan

### Goal (specific)

### Daily minimum (minutes)

### Week 1 — theme & micro-win

| Day | Focus (15–30 min) |
| --- | ----------------- |
| | |

### Week 2

### Week 3

### Week 4

### Project piece (optional)

### If I fall behind

### Celebration at day 30

---

## Practice schedule

### Skill

### Session length

### Weekly grid

| Day | Time | Warm-up | Core drill | Apply |
| --- | ---- | ------- | ---------- | ----- |
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Rest / light day

### Gear / setup ready checklist
