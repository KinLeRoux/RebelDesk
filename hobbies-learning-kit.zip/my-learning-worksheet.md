---
type: note
title: My learning worksheet
category: Hobbies & learning kit
tags: personal, learning, worksheet
searchable: true
---

# My learning worksheet

## What I want to learn

## Why now

## Minutes per day (honest)

## Current level

## Notes
