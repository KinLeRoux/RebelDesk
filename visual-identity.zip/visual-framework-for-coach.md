---
type: note
title: Visual framework (for the coach)
category: Visual identity
tags: visual, framework, coach
searchable: true
---

# Visual framework (for the coach)

## Align visuals to archetype (if known)

| Archetype | Visual lean |
| --------- | ----------- |
| Innocent | Light, soft, simple |
| Everyperson | Approachable, unpretentious |
| Hero | Bold contrast, dynamic |
| Outlaw | Dark, edgy, disruptive |
| Explorer | Natural, rugged, open |
| Creator | Craft, texture, studio |
| Lover | Rich, sensual, elegant |
| Caregiver | Soft, trustworthy, rounded |
| Jester | Bright, unexpected, playful |
| Sage | Clean, structured, restrained |
| Magician | Dramatic, gradient, visionary |
| Ruler | Dark luxury, symmetry, premium |

## Industry clichés to flag gently

- Tech: blue gradients, generic sans
- Wellness: sage green + lotus
- Finance: navy + gold pillars
- Food: faux rustic script

Offer **distinct** directions, not category defaults.

## Context gap

If brand brief not in chat context, ask user to attach it or paste audience + promise in two sentences.

## Deliverable quality bar

Brief must let a designer start without another meeting: mood, color words, type direction, imagery, logo hint, 3 priorities.
