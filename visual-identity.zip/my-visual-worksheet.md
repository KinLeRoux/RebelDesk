---
type: note
title: My visual worksheet
category: Visual identity
tags: visual, worksheet
searchable: true
---

# My visual worksheet

## Look words (3)

## References

**Visual style I love:**

**Visual style I hate:**

## Color gut check

**Warm / cool:**

**Light / dark:**

**Colors I like (words):**

**Colors I avoid:**

## Type & layout

**Headline feel:**

**Layout feel:**

## Imagery

**Photo vs illustration:**

**Mood:**

## Logo & touchpoints

**Logo idea:**

**Shows up most on:**

## Notes

---

## Session log

| Date | Direction chosen |
| ---- | ---------------- |
|      |                  |
