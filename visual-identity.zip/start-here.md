---
type: note
title: Start here — Visual identity
category: Visual identity
tags: visual, brand, design, start
searchable: true
---

# Start here — Visual identity

You do not need design software. This pack helps you describe **how your brand should look** in words a designer (or an AI image tool) can follow.

Open **Chat**, attach **Visual identity coach** (crown icon), and say:

> **Help me create our visual identity brief.**

Works best after **Build your brand**, **Your brand voice**, and/or **Brand archetypes** — attach those filled notes too if you have them.

## What you will end up with

- Mood and **color direction** (in plain English, not design-school terms)
- **Typography** feel (modern classic, friendly rounded, etc.)
- **Photo / illustration** style
- A short **brief you can hand to a designer**

## Tips

- Bring one website or Instagram account you like the *look* of (describe it — no technical setup needed).
- You are not picking exact hex codes unless you want to — “warm terracotta and cream” is enough.

## After your brief is done

Ask:

- “Write a creative brief for a logo designer using our visual identity note.”
- “Describe three homepage hero image concepts that match our look.”
- “Does this flyer description match our visual rules? Adjust it.”
