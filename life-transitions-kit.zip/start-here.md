---
type: note
title: Start here — Life transitions kit
category: Life transitions kit
tags: personal, transitions, start
searchable: true
---

# Start here — Life transitions kit

Moving, decluttering, renovations, big life changes, and caregiving rhythms. Home projects share one output; money questions pull **Personal finance kit** templates.

Install → **Start in chat**. For recipes and vacations, use **Personal & life kit**.
