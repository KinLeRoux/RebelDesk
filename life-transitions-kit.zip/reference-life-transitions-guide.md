---
type: note
title: Life transitions guide (reference)
category: Life transitions kit
tags: moving, declutter, projects, personal, reference
searchable: true
---

# Life transitions guide (reference)

Moving, decluttering, renovations, life changes, and caregiving rhythms. **Not legal advice** — check local requirements for leases and deposits.

## Moving checklist

### 8+ weeks out

- [ ] Budget move (truck, movers, deposits)  
- [ ] Notify landlord / buyer timeline  
- [ ] Declutter sell/donate (see declutter section)

### 4 weeks

- [ ] Change-of-address list (post, bank, employer, subscriptions, GP, voting)  
- [ ] Utilities end/start dates  
- [ ] School / childcare transfer if applicable

### 2 weeks

- [ ] Pack non-essentials by room  
- [ ] Label boxes (room + contents)  
- [ ] Essentials box (kettle, toiletries, chargers, documents)

### Move week

- [ ] Meter readings photos  
- [ ] Keys handover checklist  
- [ ] First night kit

### After move

- [ ] Update driving licence / ID when required (jurisdiction varies)  
- [ ] Test smoke alarms, locate stopcock/fuse box  
- [ ] Neighbour intro optional

---

## Declutter — good enough

### Principles

- **One room at a time** — visible win beats whole-house overwhelm.  
- Sort: **keep / donate / recycle / trash / unsure box** (review unsure in 30 days).  
- **15-minute** sessions count.  
- If it hasn’t been used in 12 months and isn’t sentimental or seasonal — strong donate candidate.

### Order that works

1. Trash bag sweep  
2. Flat surfaces (counter, table)  
3. Clothes (wear what fits **today**)  
4. Paper (shred, file, action pile)  
5. Garage / loft last

### Sentimental items

Limit one box per person; photo digitize instead of keeping every object.

### Stop rules

Room is “good enough” when you can clean it in 20 minutes and find daily items fast.

### Don’t

Buy storage containers before reducing volume.

---

## Life project planning

For **personal** projects (not client work — use **Business operations kit** for that).

### One-page project shape

- **Outcome** — what “done” looks like in plain words  
- **Why now**  
- **Deadline** (real or target)  
- **Big rocks** — 3–5 milestones max  
- **Next action** — one physical step  

### 90-day rhythm

| Week | Focus |
| ---- | ----- |
| 1–2 | Setup + quick win |
| 3–8 | Main work in chunks |
| 9–12 | Finish + celebrate + rest |

### Weekly review (15 min)

What moved? Blocker? One priority next week?

### Caregiving overlay

Recurring appointments, meds reminders (they track — you don’t diagnose), respite time for carer.

### Pair with other kits

- **Move / declutter / renovation** → **output-home-projects.md**  
- **Money for project** → Personal finance kit (**output-debt-and-savings.md**, **output-purchase-decision.md**)  
- **Stress** → Wellness & habits kit  
- **Trips** → Personal & life kit
