---
type: note
title: Home projects — output template
category: Life transitions kit
tags: moving, declutter, renovation, output, personal
searchable: true
---

# Home projects — output template

Use the section that matches the project — move, declutter, or renovation.

---

## Moving house

### From / To dates

### Budget [TBD]

### Movers / DIY

### Room packing order

### Change-of-address list

### Utilities

### Essentials box contents

### Week-by-week checklist

---

## Declutter

### Scope (room / home)

### Goal (good enough = …)

### Room order

| Room | Session date | Done? |
| ---- | ------------ | ----- |
| | | |

### Donate / sell outlets

### 15-minute sessions scheduled

---

## Renovation / improvement

### Project (what & why)

### Budget range [TBD]

### Must-haves vs nice-to-haves

### DIY vs hire trades

### Permits / landlord rules [TBD]

### Timeline phases

### Quotes to get
