---
type: note
title: Caregiving week plan — output template
category: Life transitions kit
tags: caregiving, output, personal
searchable: true
---

# Caregiving week plan — output template

## Who we support

## Appointments this week

| When | What | Who goes |
| ---- | ---- | -------- |
| | | |

## Meds / routines (they manage — reminders only)

## Our respite block

## Family / helper contacts

## One thing that would help most
