---
type: note
title: Transition timeline — output template
category: Life transitions kit
tags: transitions, output, personal
searchable: true
---

# Transition timeline — output template

## What is changing

## Target outcome

## Key dates

| Date | Milestone |
| ---- | --------- |
| | |

## Big rocks (max 5)

## Next action (one step)

## Support people

## Snapshot stress & mitigation
