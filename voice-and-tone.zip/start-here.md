---
type: note
title: Start here — Your brand voice
category: Voice & tone
tags: voice, tone, brand, start
searchable: true
---

# Start here — Your brand voice

Already did **Build your brand**? Great — this pack turns your brief into **how you sound** everywhere you write.

Open **Chat**, attach **Voice & tone coach** (crown icon), and say:

> **Help me define our brand voice.**

Or:

> **Make this paragraph sound like us:** (paste your draft)

## What you will end up with

- A **voice & tone guide** (how you sound, words to use or avoid)
- **Before / after** examples in your voice
- Short rules for **email, social, and website** (plain language, no marketing degree required)

## Tips

- If you have a **brand brief** from the other pack, mention it — the coach will use it.
- Bring one real email or post you have written; the coach can tune from that.
- You can run this in one sitting (~15 minutes) or in short passes.

## After your guide is done

Ask:

- “Rewrite this customer email in our voice.”
- “Give me five Instagram captions for our new offer.”
- “This sounds too corporate — fix it using our voice guide.”
