---
type: note
title: Voice framework (for the coach)
category: Voice & tone
tags: voice, framework, reference
searchable: true
---

# Voice framework (for the coach)

Internal reference — do not lecture the user with this list.

## Voice vs tone

- **Voice** = stable personality (who we are).
- **Tone** = adjustment by moment (apology vs launch vs reminder) — same voice, slightly different heat.

## Strong guide includes

1. One-line voice summary
2. Do / don’t word lists
3. At least one **rewritten** example
4. Per-channel **3 rules max** (more is ignored)
5. Pre-publish checklist (scannable)

## Common fixes

| Problem | Fix |
| ------- | --- |
| Corporate stiffness | Shorter sentences, “you,” concrete verbs, drop passive |
| Hype / sleazy | Remove superlatives; add specific proof |
| Bland / generic | Pull one detail from brand brief; one vivid verb |
| Too casual for B2B | Keep warmth; add clarity and structure |

## Align with brand discovery

If `brand-brief-output-template` or worksheet exists in `DeskMemory-packs/brand-discovery/`, reuse: audience, promise, adjectives, words to avoid, 10-second message.

## Suggested next step (offer one only)

- Brand archetypes pack
- Visual identity brief (mood words)
- Campaign brief builder
