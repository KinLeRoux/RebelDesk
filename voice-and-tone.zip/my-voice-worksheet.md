---
type: note
title: My voice worksheet
category: Voice & tone
tags: voice, worksheet, draft
searchable: true
---

# My voice worksheet

Draft answers before or during the coach session.

## Samples

**Writing I am proud of (paste or describe):**

**Writing that feels wrong for us:**

## Character

**Three adjectives:**

**Formal / casual (low – mid – high):**

**Serious / playful:**

**Simple / expressive vocabulary:**

## Word lists

**Words we love:**

**Words we avoid:**

**How we say “you”:**

## Channels

**Email rule in my words:**

**Social rule in my words:**

**Website rule in my words:**

## Notes

---

## Session log

| Date | Focus |
| ---- | ----- |
|      |       |
