---
type: note
title: Operations guide (reference)
category: Business operations
tags: operations, meetings, sop, client, reference
searchable: true
---

# Operations guide (reference)

Meetings, SOPs, and client communication — attach for the **Business operations coach** or alone before a meeting, kickoff, or onboarding.

---

## Effective meetings

### Before

- **Purpose in one sentence** — decision, brainstorm, or status?
- **Invite only** people who contribute or must approve.
- **Agenda sent early** — outcome per item, not vague topics.
- **Time box** each item; put decisions first if energy drops.

### Agenda shape

1. Context (2 min)
2. Decision items (bulk of time)
3. Actions & owners (last 5 min)
4. Optional: parking lot for off-topic

### Notes that help

| Section | Capture |
| ------- | ------- |
| Decisions | What was agreed |
| Actions | Who / what / by when |
| Open questions | Owner to resolve |
| Parking lot | Discuss later |

### After

- Send summary within 24 hours.
- One line per action with owner and date.
- No transcript dumps — only what matters.

### Meeting anti-patterns

- No agenda → reschedule or shorten to 15 min stand-up.
- Status-only meetings that could be an email.
- More than 8 people for a working session.

---

## SOP and process principles

Standard Operating Procedure — a repeatable recipe for work.

### When you need an SOP

- You do it more than twice a month.
- Someone else might cover for you.
- Mistakes are costly (money, compliance, client trust).

### Good SOP structure

1. **Title & owner**
2. **Purpose** (why this exists)
3. **When to use** (trigger)
4. **Who** (role, not necessarily a name)
5. **Tools / links** needed
6. **Steps** (numbered, one action per step)
7. **Checks** (“confirm X before continuing”)
8. **Exceptions** (if client is X, do Y)
9. **Revision date**

### Writing steps

- Start each step with a verb: *Send, Check, Save, Call*.
- One decision per step.
- Screenshots optional — describe in words if no images.
- Target reader: smart newcomer on day one.

### Maintenance

- Review every 6–12 months or after an incident.
- Version at bottom: “v1.2 — added backup step.”

---

## Client and project communication

Expectations, onboarding, and updates — plain and professional.

### Onboarding goals

- Client feels **welcomed** and knows what happens next.
- **Clear asks** — what we need from them and by when.
- **One main contact** on each side.
- **Rhythm** — when they hear from us (weekly email, portal, calls).

### Welcome pack ingredients

1. Short hello (what we’re excited to do)
2. Timeline or phases
3. Checklist for them (files, logins, approvals)
4. How to reach us (hours, response time)
5. What success looks like together

### Project updates (without fluff)

**Format:** Done since last time → Next → Blockers (need from you).

Keep under 200 words unless they asked for detail.

### Difficult messages

- Bad news early; propose options.
- No blame language; facts + next step.
- Confirm in writing after verbal agreement.

### Kickoff vs onboarding

- **Kickoff** = internal + client alignment on scope.
- **Onboarding** = client experience of starting work.

Pair with **output-voice-and-tone-guide.md** (Brand kit) for client-facing wording when available.

---

## Prompts alone

- “Agenda for a 45-min client check-in — decision on timeline.”
- “Turn my bullet list into an SOP for invoicing.”
- “Client onboarding email for a bookkeeping client.”
- “Weekly update template for a website project.”
- “Draft a 5-line follow-up email from this meeting.”

**Outputs:** **output-meetings-and-projects.md**, **output-client-onboarding.md**, **output-sop.md**, **output-weekly-priorities.md**.
