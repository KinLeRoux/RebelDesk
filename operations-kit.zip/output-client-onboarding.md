---
type: note
title: Client onboarding — output template
category: Business operations
tags: client, onboarding, output
searchable: true
---

# Client onboarding — output template

_Filled in by the Business operations coach (Mode 3)._

## Client

## What we are doing for them

## Timeline (phases)

| Phase | What happens | Rough dates |
| ----- | ------------ | ----------- |
| | | |

## Welcome message (draft)

_(Email or letter — warm, clear)_

## What we need from the client

| Item | By when | Notes |
| ---- | ------- | ----- |
| | | |

## How we work together

**Main contacts:**

**Response time:**

**Tools / portal:**

## Internal checklist (our team)

- [ ]
- [ ]

## Success looks like
