---
type: note
title: Weekly priorities — output template
category: Business operations
tags: weekly, planning, output
searchable: true
---

# Weekly priorities — output template

_Filled in by the Business operations coach (Mode 5)._

## Week of

## Top 3 outcomes (must ship)

1.
2.
3.

## Key meetings / fixed commitments

| Day | What |
| --- | ---- |
| | |

## Blockers (need action)

| Blocker | Who can unblock |
| ------- | --------------- |
| | |

## People to ping

-

## Not doing this week (on purpose)

-

## End-of-week check (fill Friday)

- [ ] Outcome 1
- [ ] Outcome 2
- [ ] Outcome 3

**Notes for next week:**
