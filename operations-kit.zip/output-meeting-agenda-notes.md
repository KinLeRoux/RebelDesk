---
type: note
title: Meeting agenda and notes — output template
category: Business operations
tags: meeting, agenda, output
searchable: true
---

# Meeting agenda and notes — output template

_Filled in by the Business operations coach (Mode 1)._

## Meeting

**Title:**

**Date / time:**

**Duration:**

**Purpose (one sentence):**

**Attendees:**

## Agenda

| Time | Topic | Desired outcome |
| ---- | ----- | ----------------- |
| | | |

## Notes

### Decisions

-

### Action items

| Action | Owner | Due |
| ------ | ----- | --- |
| | | |

### Open questions

-

### Parking lot

-

## Follow-up email (draft bullets)

-
