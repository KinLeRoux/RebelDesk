---
type: note
title: My operations worksheet
category: Business operations
tags: operations, worksheet
searchable: true
---

# My operations worksheet

## Active clients / projects

| Name | Status | Next step |
| ---- | ------ | --------- |
| | | |

## Recurring processes to document

-

## This week (scratch)

**Must do:**

**Waiting on others:**

## Session log

| Date | Output | Done? |
| ---- | ------ | ----- |
| | | |
