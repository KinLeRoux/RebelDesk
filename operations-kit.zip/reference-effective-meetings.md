---
type: note
title: Effective meetings (reference)
category: Business operations
tags: meetings, reference
searchable: true
---

# Effective meetings (reference)

For the **Business operations coach** or attach alone before a important meeting.

## Before

- **Purpose in one sentence** — decision, brainstorm, or status?  
- **Invite only** people who contribute or must approve.  
- **Agenda sent early** — outcome per item, not vague topics.  
- **Time box** each item; put decisions first if energy drops.

## Agenda shape

1. Context (2 min)  
2. Decision items (bulk of time)  
3. Actions & owners (last 5 min)  
4. Optional: parking lot for off-topic

## Notes that help

| Section | Capture |
| ------- | ------- |
| Decisions | What was agreed |
| Actions | Who / what / by when |
| Open questions | Owner to resolve |
| Parking lot | Discuss later |

## After

- Send summary within 24 hours.  
- One line per action with owner and date.  
- No transcript dumps — only what matters.

## Prompts alone

- “Agenda for a 45-min client check-in — decision on timeline.”  
- “Turn these bullet notes into action items with owners.”  
- “Draft a 5-line follow-up email from this meeting.”

## Anti-patterns

- No agenda → reschedule or shorten to 15 min stand-up.  
- Status-only meetings that could be an email.  
- More than 8 people for a working session.
