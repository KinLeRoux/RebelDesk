---
type: note
title: Project kickoff brief — output template
category: Business operations
tags: project, kickoff, output
searchable: true
---

# Project kickoff brief — output template

_Filled in by the Business operations coach (Mode 2)._

## Project name

## Goal (one sentence)

## Stakeholders

| Name / role | Responsibility |
| ----------- | -------------- |
| | |

## Scope & deliverables

-

## Out of scope

-

## Timeline & milestones

| Milestone | Target date | Owner |
| --------- | ----------- | ----- |
| | | |

## Definition of done

## Risks & assumptions

| Risk / assumption | Mitigation |
| ----------------- | ---------- |
| | |

## Communication rhythm

**Client updates:**

**Internal check-ins:**

## Budget / resources (if relevant)
