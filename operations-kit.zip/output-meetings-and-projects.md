---
type: note
title: Meetings and projects — output template
category: Business operations
tags: meeting, project, kickoff, agenda, output
searchable: true
---

# Meetings and projects — output template

_Filled in by the Business operations coach (Mode 1 or 2). Use the meeting section for one-off meetings; use the project section for kickoffs and scope alignment._

---

## Part A — Meeting (agenda & notes)

### Meeting

**Title:**

**Date / time:**

**Duration:**

**Purpose (one sentence):**

**Attendees:**

### Agenda

| Time | Topic | Desired outcome |
| ---- | ----- | ----------------- |
| | | |

### Notes

#### Decisions

-

#### Action items

| Action | Owner | Due |
| ------ | ----- | --- |
| | | |

#### Open questions

-

#### Parking lot

-

### Follow-up email (draft bullets)

-

---

## Part B — Project kickoff (scope & milestones)

### Project name

### Goal (one sentence)

### Stakeholders

| Name / role | Responsibility |
| ----------- | -------------- |
| | |

### Scope & deliverables

-

### Out of scope

-

### Timeline & milestones

| Milestone | Target date | Owner |
| --------- | ----------- | ----- |
| | | |

### Definition of done

### Risks & assumptions

| Risk / assumption | Mitigation |
| ----------------- | ---------- |
| | | |

### Communication rhythm

**Client updates:**

**Internal check-ins:**

### Budget / resources (if relevant)
