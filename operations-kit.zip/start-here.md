---
type: note
title: Start here — Business operations kit
category: Business operations
tags: operations, start
searchable: true
---

# Business operations kit

Meetings, projects, client onboarding, procedures, and weekly focus — without project-management jargon.

## Simple path

1. **Settings → Chat Settings → Memory packs** → install **Business operations kit**.
2. Tap **Start in chat**.
3. Press **Send** and pick what you need.

## What’s inside

| Kind | Use |
| ---- | --- |
| **Operations coach** | Step-by-step for each task type |
| **Operations guide** | One reference for meetings, SOPs, and client communication |
| **output-*** | Ready-to-use templates in your vault |

## Outputs

- **output-meetings-and-projects.md** — meeting agendas/notes or project kickoffs
- **output-client-onboarding.md** — welcome pack for new clients
- **output-sop.md** — step-by-step procedures
- **output-weekly-priorities.md** — weekly focus plan

## Example later

Attach only **Operations guide** and say: *“Turn my notes into an SOP for onboarding new clients.”*
