---
type: note
title: SOP and process principles (reference)
category: Business operations
tags: sop, process, reference
searchable: true
---

# SOP and process principles (reference)

Standard Operating Procedure — a repeatable recipe for work. Attach for **Mode 4** or solo.

## When you need an SOP

- You do it more than twice a month.  
- Someone else might cover for you.  
- Mistakes are costly (money, compliance, client trust).

## Good SOP structure

1. **Title & owner**  
2. **Purpose** (why this exists)  
3. **When to use** (trigger)  
4. **Who** (role, not necessarily a name)  
5. **Tools / links** needed  
6. **Steps** (numbered, one action per step)  
7. **Checks** (“confirm X before continuing”)  
8. **Exceptions** (if client is X, do Y)  
9. **Revision date**

## Writing steps

- Start each step with a verb: *Send, Check, Save, Call*.  
- One decision per step.  
- Screenshots optional — describe in words if no images.  
- Target reader: smart newcomer on day one.

## Maintenance

- Review every 6–12 months or after a incident.  
- Version at bottom: “v1.2 — added backup step.”

## Prompts alone

- “Turn my bullet list into an SOP for invoicing.”  
- “What’s missing from this SOP for safety?”  
- “Simplify this procedure for a part-time assistant.”
