---
type: note
title: Client and project communication (reference)
category: Business operations
tags: client, project, communication, reference
searchable: true
---

# Client and project communication (reference)

Expectations, onboarding, and updates — plain and professional.

## Onboarding goals

- Client feels **welcomed** and knows what happens next.  
- **Clear asks** — what we need from them and by when.  
- **One main contact** on each side.  
- **Rhythm** — when they hear from us (weekly email, portal, calls).

## Welcome pack ingredients

1. Short hello (what we’re excited to do)  
2. Timeline or phases  
3. Checklist for them (files, logins, approvals)  
4. How to reach us (hours, response time)  
5. What success looks like together  

## Project updates (without fluff)

**Format:** Done since last time → Next → Blockers (need from you).

Keep under 200 words unless they asked for detail.

## Difficult messages

- Bad news early; propose options.  
- No blame language; facts + next step.  
- Confirm in writing after verbal agreement.

## Kickoff vs onboarding

- **Kickoff** = internal + client alignment on scope.  
- **Onboarding** = client experience of starting work.

## Prompts alone

- “Client onboarding email for a bookkeeping client.”  
- “Weekly update template for a website project.”  
- “Polite email asking for overdue assets.”

Pair with voice guide from Brand kit when available.
