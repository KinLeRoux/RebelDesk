---
type: note
title: Voice & tone guide — output template
category: Brand kit
tags: voice, tone, guide, output
searchable: true
---

# Voice & tone guide — output template

_Filled in by the Brand kit coach (Mode 2). Edit anytime._

## Voice in one line

<!-- e.g. Warm, direct, and confident — like a knowledgeable friend, never a billboard. -->

## Who we sound like

**Three adjectives:**

**Energy in a room:**

**We always sound like ______:**

## Tone sliders (plain words)

| Dimension | Where we sit | Example |
| --------- | ------------ | ------- |
| Formal ↔ Casual | | |
| Serious ↔ Playful | | |
| Simple ↔ Expressive | | |

## Word rules

### Words we love

-

### Words we avoid

-

### How we address people

-

### Sentence & format

**Length & rhythm:**

**Bullets, lists, emoji:** (yes/no and when)

## Channel cheat sheet

### Email

**Opener style:**

**Sign-off:**

**Rules (max 3):**

1.
2.
3.

### Social

**Length:**

**Emoji / hashtags:**

**Rules (max 3):**

1.
2.
3.

### Website / landing

**Headlines:**

**Body copy:**

**Rules (max 3):**

1.
2.
3.

## Say it like this (examples)

**Headline:**

**Email opener:**

**Social line:**

## Before you publish (checklist)

- [ ]
- [ ]
- [ ]
- [ ]
- [ ]

## Before / after

**Before (off-brand sample):**

**After (our voice):**

## Linked brand context

**From brand brief (if any):**

**Core message to repeat:**
