---
type: note
title: Brand card — output template
category: Brand kit
tags: brand, card, fonts, colors, output
searchable: true
---

# Brand card — output template

_Visual snapshot: fonts, colors, mood — often built from **reference-fontology-and-color-psychology.md** plus your brief and voice guide._

## Brand name

## Mood in one line

## Font pairing

| Role | Font direction (name or style) | Why it fits |
| ---- | ------------------------------ | ----------- |
| Headlines | | |
| Body text | | |
| Logo / accent (if any) | | |

## Color palette

| Role | Description | Hex (optional) |
| ---- | ------------- | -------------- |
| Primary | | |
| Secondary | | |
| Accent | | |
| Background / neutral | | |

**Colors to avoid:**

## Imagery direction (short)

## Sample in context

**Headline:**

**Subhead:**

**Button / CTA style:**

## Linked strategy notes

**From brand brief:**

**From voice guide:**

**From archetype profile:**

## Designer handoff (optional)

**Deliverables:**

**References to avoid looking like:**
