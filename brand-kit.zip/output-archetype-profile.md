---
type: note
title: Archetype profile — output template
category: Brand kit
tags: archetypes, profile, output
searchable: true
---

# Archetype profile — output template

_Filled in by the Brand kit coach (Mode 3)._

## Our archetype blend

| Role | Archetype | Why it fits |
| ---- | --------- | ----------- |
| Primary | | |
| Secondary | | |

## Character in plain language

**At a party, our brand is the person who:**

**Three words:**

**We are the brand that ______:**

## What customers should feel

**Before:**

**After:**

## Voice from this character

**We sound like:**

**We never sound like:**

## Do / don’t (behaviours)

### Do

-

### Don’t

-

## Misfit archetypes (avoid)

| Archetype | Why it’s a poor fit |
| --------- | ------------------- |
| | |

## When to lean secondary

<!-- e.g. Social = more Jester; crisis email = more Caregiver -->

## Ready-to-use copy

### Homepage hero

**Headline:**

**Subhead:**

### Social caption

### Email opener

## Campaign angles (3)

1.
2.
3.

## Linked notes

**Brand brief used:**

**Voice guide used:**
