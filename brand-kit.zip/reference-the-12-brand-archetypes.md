---
type: note
title: The 12 brand archetypes (reference)
category: Brand kit
tags: archetypes, reference, jung
searchable: true
---

# The 12 archetypes — reference

Use with the **Brand kit coach** or attach alone for character and messaging work.

## Why archetypes matter

People connect with **character and story**, not feature lists. Picking a primary + secondary archetype keeps marketing, email, and social feeling like the same person wrote them.

---

## 1. The Innocent

- **Desire:** Safety, simplicity, happiness.
- **Voice:** Optimistic, honest, pure, nostalgic.
- **Examples:** Dove, Coca‑Cola, Innocent Drinks.
- **Fit when:** Comfort, wellbeing, simple pleasures.

## 2. The Everyperson

- **Desire:** Belonging, connection, realism.
- **Voice:** Down‑to‑earth, friendly, unpretentious.
- **Examples:** IKEA, Levi’s.
- **Fit when:** “One of us” — no status games.

## 3. The Hero

- **Desire:** Mastery, courage, winning the challenge.
- **Voice:** Bold, confident, inspiring.
- **Examples:** Nike, FedEx.
- **Fit when:** You help them overcome big obstacles.

## 4. The Outlaw

- **Desire:** Freedom, revolution, breaking rules.
- **Voice:** Rebellious, provocative, raw.
- **Examples:** Harley‑Davidson, Liquid Death.
- **Fit when:** Disrupting a stale industry.

## 5. The Explorer

- **Desire:** Freedom through discovery.
- **Voice:** Curious, adventurous, independent.
- **Examples:** Patagonia, Jeep.
- **Fit when:** Experiences, growth, breaking routine.

## 6. The Creator

- **Desire:** Build, express, innovate.
- **Voice:** Imaginative, passionate, craft‑focused.
- **Examples:** Lego, Adobe.
- **Fit when:** Customers make something or value design.

## 7. The Lover

- **Desire:** Connection, pleasure, intimacy.
- **Voice:** Warm, sensory, elegant.
- **Examples:** Fine chocolate, luxury beauty.
- **Fit when:** Beauty, indulgence, emotional bonds.

## 8. The Caregiver

- **Desire:** Protect and nurture.
- **Voice:** Compassionate, reassuring, helpful.
- **Examples:** Johnson & Johnson, Volvo (safety).
- **Fit when:** Safety, support, care.

## 9. The Jester

- **Desire:** Joy, humour, living now.
- **Voice:** Witty, playful, irreverent.
- **Examples:** Old Spice, Dollar Shave Club.
- **Fit when:** Fun is the differentiator.

## 10. The Sage

- **Desire:** Truth, understanding, expertise.
- **Voice:** Clear, intelligent, trustworthy.
- **Examples:** BBC, The Economist.
- **Fit when:** Education, research, authority.

## 11. The Magician

- **Desire:** Transformation, “make it real.”
- **Voice:** Aspirational, visionary, stirring.
- **Examples:** Disney, Tesla.
- **Fit when:** Big before/after change.

## 12. The Ruler

- **Desire:** Control, excellence, leadership.
- **Voice:** Polished, commanding, exclusive.
- **Examples:** Mercedes‑Benz, Rolex.
- **Fit when:** Premium, status, best‑in‑class.

---

## Common blends

| Blend | Works for |
| ----- | --------- |
| Hero + Explorer | Outdoor, fitness, adventure |
| Sage + Caregiver | Health, finance education, parenting |
| Creator + Magician | Courses, coaching, creative tools |
| Everyperson + Jester | Accessible consumer apps |
| Ruler + Lover | Luxury lifestyle |

## Prompts to try

- “Which two archetypes fit us? Explain in plain English.”
- “Write a homepage hero blending [primary] + [secondary].”
- “This sounds off‑brand — which archetype is leaking through?”
