---
type: note
title: Brand kit guide (reference)
category: Brand kit
tags: brand, archetypes, voice, fonts, colors, reference
searchable: true
---

# Brand kit guide (reference)

One guide for the **Brand kit coach** — character, voice, fonts, and colors.

## Part A — Brand voice

**Voice** = who you are on the page (stable). **Tone** = how hot/cold you turn the dial (apology vs launch vs reminder).

**Strong voice guide includes:** one-line summary, words you love/avoid, one before/after example, short rules for email/social/web, five-point publish checklist.

| Dimension | Low end | High end |
| --------- | ------- | -------- |
| Formality | Casual, contractions | Formal, complete sentences |
| Energy | Calm, measured | Bold, urgent |
| Vocabulary | Simple, everyday | Rich, technical |
| Humour | Serious | Playful |

| Problem | Fix |
| ------- | --- |
| Sounds corporate | Shorter sentences, "you," active verbs |
| Sounds salesy | Drop superlatives; add one specific proof point |
| Sounds bland | One concrete detail from the brand brief |
| Sounds wrong for audience | Re-check archetype and who you serve |

## Part B — The 12 archetypes

People connect with **character and story**, not feature lists. Pick **primary + secondary** so marketing, email, and social feel like the same person wrote them.

| # | Archetype | Desire | Voice | Fit when |
| - | --------- | ------ | ----- | -------- |
| 1 | Innocent | Safety, simplicity | Optimistic, honest | Comfort, wellbeing |
| 2 | Everyperson | Belonging | Down-to-earth, friendly | "One of us" — no status games |
| 3 | Hero | Mastery, courage | Bold, confident | Overcoming big obstacles |
| 4 | Outlaw | Freedom, revolution | Rebellious, provocative | Disrupting a stale industry |
| 5 | Explorer | Discovery | Curious, adventurous | Experiences, growth |
| 6 | Creator | Build, express | Imaginative, craft-focused | Customers make something |
| 7 | Lover | Connection, pleasure | Warm, sensory, elegant | Beauty, indulgence |
| 8 | Caregiver | Protect, nurture | Compassionate, reassuring | Safety, support, care |
| 9 | Jester | Joy, humour | Witty, playful | Fun is the differentiator |
| 10 | Sage | Truth, expertise | Clear, intelligent | Education, authority |
| 11 | Magician | Transformation | Aspirational, visionary | Big before/after change |
| 12 | Ruler | Control, excellence | Polished, commanding | Premium, status |

**Common blends:** Hero + Explorer (outdoor/fitness); Sage + Caregiver (health/finance); Creator + Magician (courses/tools); Everyperson + Jester (consumer apps); Ruler + Lover (luxury).

**Prompts:** "Which two archetypes fit us?" · "Write a homepage hero blending [primary] + [secondary]." · "This sounds off-brand — which archetype is leaking?"

## Part C — Fonts, colors & brand card

Use after **brand brief** and **voice guide** when possible. Mode 3 → `output-visual-brand-identity.md`.

### Font psychology

| Style | Signals | Good for |
| ----- | ------- | -------- |
| Serif | Tradition, authority, trust | Law, finance, luxury, editorial |
| Sans-serif | Modern, clear, honest | Tech, startups, health, corporate |
| Script / handwritten | Personal, creative | Logos, short headlines only |
| Display / decorative | Bold, unique | Campaign headlines — pair with readable sans |

**Pairing:** serif headline + sans body = authority + clarity; one sans family, multiple weights = modern; display logo + sans elsewhere = personality without chaos.

### Color psychology

| Color | Emotion | Typical use |
| ----- | ------- | ----------- |
| Red | Energy, urgency | Sales, youth, food |
| Blue | Trust, calm | Finance, B2B, health |
| Green | Growth, wellness | Eco, money, health |
| Yellow / orange | Optimism, enthusiasm | Friendly brands, CTAs |
| Purple | Luxury, creativity | Premium, creative tools |
| Black / white / grey | Elegance, minimalism | Luxury, tech |
| Brown | Earthy, reliable | Organic, heritage |

**Harmony:** analogous = calm; complementary = energetic; monochrome = refined.

### Personality cheat sheet

| Personality | Font lean | Colors |
| ------------- | --------- | ------ |
| Trustworthy | Serif | Dark blue + gold accent |
| Modern & clean | Sans | White/grey + one bright accent |
| Creative & playful | Display + sans | Orange/yellow + purple accent |
| Luxurious | Serif | Black, gold, deep purple |
| Calm & wellness | Rounded sans | Soft green, light blue |
| Bold & rebellious | Heavy sans / display | Red, black, metal accent |

**Brand card prompt:** "Using my brief, voice guide, and archetype, fill **output-visual-brand-identity.md** (brand card section) with font pairing, palette in plain words and hex, mood line, and sample hero headline."
