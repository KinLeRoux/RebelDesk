---
type: note
title: Visual brand identity — output template
category: Brand kit
tags: archetypes, visual, brand card, output
searchable: true
---

# Visual brand identity — output template

_Filled by the Brand kit coach (Mode 3). Archetypes, visual brief, and brand card in one place._

## Archetype blend

| Role | Archetype | Why it fits |
| ---- | --------- | ----------- |
| Primary | | |
| Secondary | | |

**At a party, our brand is the person who:**

**Three words:**

**We are the brand that ______:**

**Before customers feel:** · **After they feel:**

**We sound like:** · **We never sound like:**

### Do / don't (behaviours)

| Do | Don't |
| -- | ----- |
| | |

**Misfit archetypes to avoid:**

**When to lean secondary:**

### Ready-to-use copy

**Homepage hero — headline / subhead:**

**Social caption:**

**Email opener:**

**Campaign angles (3):** 1. · 2. · 3.

---

## Visual identity brief

**Look in one sentence:**

**Three look words:** · **Feels like:** · **Not like:**

### Color direction

| Role | Description (plain words) | Notes |
| ---- | ------------------------- | ----- |
| Primary | | |
| Secondary | | |
| Accent | | |
| Background / neutrals | | |

**Colors to avoid:**

### Typography direction

**Headlines:** · **Body text:** · **Overall type personality:**

### Layout & imagery

**Whitespace / grid:** · **Photo style:** · **Subjects to show / avoid:** · **Illustration / icons:**

### Logo direction

**Style:** · **Must include / must avoid:**

**Admire (visual):** · **Avoid looking like:**

**Applications (priority):** 1. · 2. · 3.

**Designer handoff paragraph:**

---

## Brand card

**Brand name:** · **Mood in one line:**

### Font pairing

| Role | Font direction | Why it fits |
| ---- | -------------- | ----------- |
| Headlines | | |
| Body text | | |
| Logo / accent | | |

### Color palette

| Role | Description | Hex (optional) |
| ---- | ------------- | -------------- |
| Primary | | |
| Secondary | | |
| Accent | | |
| Background / neutral | | |

**Colors to avoid:**

### Sample in context

**Headline:** · **Subhead:** · **Button / CTA style:**

## Linked brand strategy

**From brand brief:** · **From voice guide:**
