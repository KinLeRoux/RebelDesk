---
type: note
title: Brand brief — output template
category: Brand kit
tags: brand, brief, template, output
searchable: true
---

# Brand brief — output template

_Filled in by the Brand kit coach (Mode 1). Edit anytime._

## Brand in one sentence

<!-- e.g. We help busy parents pack healthy lunches without guilt or last-minute panic. -->

## Who we serve

**Ideal customer (human description):**

**What they care about most:**

**What they are tired of:**

## Problem → transformation

| Before (pain / desire) | After (result / feeling) |
| ---------------------- | ------------------------ |
|                        |                          |

## Promise

**Our promise in plain language:**

**What we will always deliver:**

**What we will never promise:**

## Why us (differentiators)

1.
2.
3.

**Only we…** (positioning line):

## Personality

**Three adjectives:**

**Feeling we want people to have:**

**Brand as a person (one line):**

## Voice

**Words we love:**

**Words we avoid:**

**Sentence length & tone:** (e.g. short and direct / warm and story-led)

**Brand we admire (and why):**

## Proof

**Credentials, results, social proof:**

## Competition

| Name / type | How we are different |
| ----------- | -------------------- |
|             |                      |

## Channels

**Where people usually discover us:**

**Primary channel to focus on next:**

## Core message

**10-second memory line:**

## Next 90 days

1.
2.
3.

## Optional (coach may add)

### Tagline options

- A:
- B:
- C:

### About us (short paragraph)

### Suggested next pack or task
