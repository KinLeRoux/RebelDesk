---
type: note
title: Visual identity brief — output template
category: Brand kit
tags: visual, brief, output
searchable: true
---

# Visual identity brief — output template

_Filled in by the Brand kit coach (Mode 4). Share with a designer or use in creative chats._

## Look in one sentence

## Mood & personality (visual)

**Three look words:**

**Feels like:**

**Not like:**

## Color direction

| Role | Description (plain words) | Notes |
| ---- | ------------------------- | ----- |
| Primary | | |
| Secondary | | |
| Accent | | |
| Background / neutrals | | |

**Colors to avoid:**

## Typography direction

**Headlines:**

**Body text:**

**Overall type personality:** (e.g. modern editorial, soft startup, luxury classic)

## Layout & spacing

**Whitespace:**

**Grid / structure:**

**Buttons & UI feel (if digital):**

## Imagery

**Photo style:**

**Subjects to show:**

**Subjects to avoid:**

**Illustration / icons:**

## Logo direction

**Style:**

**Must include / must avoid:**

## Reference brands (visual only)

**Admire:**

**Avoid looking like:**

## Applications (priority order)

1.
2.
3.

## Designer handoff

**Deliverables requested:**

**Deadline / phase (if any):**

**Budget tier (if shared):** (e.g. logo only / full identity)

**One paragraph creative brief:**

## Linked brand strategy

**From brand brief:**

**From voice guide:**

**From archetypes:**
