---
type: note
title: Start here — Brand kit
category: Brand kit
tags: brand, kit, start
searchable: true
---

# Brand kit

Everything for **strategy, voice, character, look, and fonts/colors** — in one install.

## The simple path

1. **Settings → Chat Settings → Memory packs** → install **Brand kit**.
2. Tap **Start in chat**.
3. Press **Send** and pick what you need (brief, voice, or visual brand identity).

## What's inside

| Kind | Files | How you use them |
| ---- | ----- | ---------------- |
| **Guide** | Brand kit coach (crown) | **Start in chat** — interviews and fills your outputs |
| **Research** | Brand kit guide (voice, archetypes, fonts & colors) | Attached automatically with the coach; also open alone for deeper work |
| **Your results** | `output-*.md` | Filled in as you go — reuse in any chat |
| **Deep interviews** | `guide-*-interview.md` | Optional — attach with the coach for a longer session |

## Example later

After your **brand brief** and **voice guide** exist, open chat with only the **Brand kit guide** attached and say: *"Build my visual brand identity using my brief and voice guide."*
