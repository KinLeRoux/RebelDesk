---
type: note
title: Brand voice — principles (reference)
category: Brand kit
tags: brand, voice, tone, reference
searchable: true
---

# Brand voice — principles (reference)

Research note for the **Brand kit coach** or for any chat on its own. Pair with your filled **output-voice-and-tone-guide.md** or **output-brand-brief.md**.

## Voice vs tone

- **Voice** = who you are on the page (stable).
- **Tone** = how hot/cold you turn the dial (apology vs launch vs reminder).

## Strong voice guide includes

1. One-line summary (“We sound like…”)
2. Words you love / words you avoid
3. One rewritten before/after example
4. Short rules for email, social, website (max 3 each)
5. A five-point “before you publish” checklist

## Dimensions (plain words)

| Dimension | Low end | High end |
| --------- | ------- | -------- |
| Formality | Casual, contractions | Formal, complete sentences |
| Energy | Calm, measured | Bold, urgent |
| Vocabulary | Simple, everyday | Rich, technical |
| Humour | Serious | Playful |

## Fixes that help non-writers

| Problem | Fix |
| ------- | --- |
| Sounds corporate | Shorter sentences, “you,” active verbs |
| Sounds salesy | Drop superlatives; add one specific proof point |
| Sounds bland | One concrete detail from the brand brief |
| Sounds wrong for audience | Re-check archetype and who you serve |

## Prompts to use alone

- “Rewrite this email in our voice” (attach your voice guide).
- “Does this headline match our voice? Fix it.”
- “Give me three social captions in our voice for [offer].”

## Links to other references in this kit

- **Archetypes** → character and emotional angle.
- **Fontology & color** → visual expression of the same personality.
