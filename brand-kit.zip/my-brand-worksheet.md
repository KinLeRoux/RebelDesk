---
type: note
title: My brand worksheet
category: Brand kit
tags: brand, worksheet
searchable: true
---

# My brand worksheet

One place for rough notes across the whole kit. The **Brand kit coach** skips questions you already answered here.

## Business

**Name:**

**What we offer:**

**Who it is for:**

## Strategy

**Customer frustration:**

**Why us:**

**Only we…:**

**Proof we can show:**

## Voice (words)

**Three adjectives:**

**Words we love / avoid:**

## Character & look

**Archetype gut feel:**

**Look words (3):**

**Colors I like / avoid:**

## Session log

| Date | Mode (brief / voice / archetypes / visual / card) | Done? |
| ---- | ----------------------------------------------- | ----- |
|      |                                                 |       |
