---
type: note
title: Fontology and color psychology (reference)
category: Brand kit
tags: brand, fonts, colors, psychology, reference
searchable: true
---

# Fontology and color psychology (reference)

Use with the **Brand kit coach** or attach alone — especially after you have a **brand brief** and **voice guide**. Ideal for building **output-brand-card.md**.

## How to use this note

Ask in chat:

- “Using my brand brief and voice guide, recommend fonts and a color palette — explain why.”
- “Draft a brand card: fonts, colors, mood, and one sample headline.”
- “What colors should we avoid in our industry?”

---

## Font psychology

### Serif (Georgia, Garamond, Times)
- **Signals:** Tradition, authority, trust, elegance.
- **Good for:** Law, finance, luxury, editorial.

### Sans-serif (Inter, Helvetica, Montserrat)
- **Signals:** Modern, clear, honest, minimal.
- **Good for:** Tech, startups, health apps, corporate.

### Script / handwritten
- **Signals:** Personal, creative, warm.
- **Use for:** Logos, short headlines only — not body text.

### Display / decorative
- **Signals:** Bold, unique, playful or rebellious.
- **Use for:** Posters, campaign headlines — pair with a readable sans for body.

### Pairing tactics
- Serif headline + sans body = authority + clarity.
- One sans family, multiple weights = modern and cohesive.
- Display logo + sans everything else = personality without chaos.

---

## Color psychology

| Color | Emotion | Typical use |
| ----- | ------- | ----------- |
| Red | Energy, urgency, passion | Sales, youth, food |
| Blue | Trust, calm, professionalism | Finance, B2B, health |
| Green | Growth, nature, wellness | Eco, money, health |
| Yellow | Optimism, warmth | Friendly brands, accents |
| Orange | Enthusiasm, confidence | CTAs, adventurous brands |
| Purple | Luxury, creativity, wisdom | Premium, creative tools |
| Pink | Warmth, compassion, play | Beauty, modern lifestyle |
| Black / white / grey | Elegance, minimalism | Luxury, tech |
| Brown | Earthy, reliable | Organic, heritage, coffee |

**Harmony:** analogous = calm; complementary = energetic; monochrome = refined.

---

## Combine with voice (cheat sheet)

| Personality | Font lean | Colors |
| ------------- | --------- | ------ |
| Trustworthy | Serif | Dark blue + gold accent |
| Modern & clean | Sans | White/grey + one bright accent |
| Creative & playful | Display + sans | Orange/yellow + purple accent |
| Luxurious | Serif | Black, gold, deep purple |
| Calm & wellness | Rounded sans | Soft green, light blue |
| Bold & rebellious | Heavy sans / display | Red, black, metal accent |

---

## Brand card prompt

> Using my brand brief, voice guide, and archetype (attached), fill **output-brand-card.md** with font pairing, color palette in plain words and hex codes, mood line, and a sample hero headline.
