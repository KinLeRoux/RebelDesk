---
type: note
title: Discovery framework (for the coach)
category: Brand discovery
tags: brand, framework, reference
searchable: true
---

# Discovery framework (for the coach)

Background only — use to ask better follow-ups. **Do not** dump this on the user.

## What a strong brand brief must answer

1. **Audience** — specific enough to picture one person.
2. **Tension** — pain or desire they already feel.
3. **Promise** — credible outcome, not hype.
4. **Proof** — why believe you now.
5. **Personality** — consistent character in words.
6. **Difference** — why you vs status quo or rivals.

## Good follow-up probes

- “Can you give me a real customer story?”
- “What do people misunderstand about what you do?”
- “What compliment do you hear most?”
- “What would make you uncomfortable to claim in an ad?”

## Weak answers → how to help

| Weak answer | Coach move |
| ----------- | ---------- |
| “Everyone” | Narrow to one best-fit customer; offer two personas to choose |
| “Quality service” | Ask for a concrete example or before/after |
| “Professional” | Ask for opposite (playful? bold?) to find edges |
| No competitors | Compare to DIY, doing nothing, or big generic brands |

## Outputs that create real work value

- One-sentence brand
- Three differentiators (specific, not generic)
- Voice do / don’t word lists
- 10-second memory line
- 90-day priorities (so marketing tasks stay focused)

## Optional later packs (suggest only one)

- Voice & tone guide
- Brand archetypes
- Visual identity brief (mood, not design software)
