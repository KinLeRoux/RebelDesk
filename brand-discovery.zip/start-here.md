---
type: note
title: Start here — Build your brand
category: Brand discovery
tags: brand, onboarding, start
searchable: true
---

# Start here — Build your brand

You do not need to learn any tech. Open **Chat**, attach **Brand discovery coach** (the file with the crown icon), and say:

> **Help me discover my brand.**

The assistant will ask simple questions, one at a time, and turn your answers into a clear **brand brief** you can reuse for websites, social posts, ads, and client work.

## What you will end up with

- A **one-page brand brief** (who you serve, what you promise, how you sound)
- Notes you can reuse every time you write something new
- Optional next steps (tagline ideas, archetype, voice rules)

## Tips

- Answer in your own words — rough notes are fine.
- If you are not sure, say “not sure yet” and the coach will offer examples.
- Come back anytime; your answers stay in your library under **DeskMemory-packs/brand-discovery/**.

## After your brief is done

Ask things like:

- “Write three homepage headlines using my brand brief.”
- “Turn my differentiators into five social posts.”
- “Does this email sound like our brand? Fix it.”
