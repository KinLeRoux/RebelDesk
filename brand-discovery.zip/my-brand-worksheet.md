---
type: note
title: My brand worksheet
category: Brand discovery
tags: brand, worksheet, draft
searchable: true
---

# My brand worksheet

Your working draft — fill in what you already know. The **Brand discovery coach** will read this and skip questions you answered.

## Quick facts

**Business or project name:**

**What I offer (1–2 sentences):**

**Website or main link (if any):**

## Customer

**Who it is for:**

**Their biggest frustration before me:**

**What success looks like for them:**

## Position

**Why pick me:**

**Competitors or alternatives:**

**Only we…:**

## Feel & voice

**Three adjectives:**

**Feeling when they see us:**

**Words I like:**

**Words I never want:**

## Proof & limits

**Proof I can show today:**

**What we do NOT do:**

## Discovery notes

_Use this space for rough notes during the interview._

---

## Session log

| Date | What we finished |
| ---- | ---------------- |
|      |                  |
