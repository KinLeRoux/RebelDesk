---
type: note
title: Start here — Writing kit
category: Writing kit
tags: writing, content, start
searchable: true
---

# Writing kit

Newsletters, blogs, social posts, case studies, and a clear editing pass — without wrestling with blank pages.

## Simple path

1. **Settings → Chat Settings → Memory packs** → install **Writing kit**.
2. Tap **Start in chat**.
3. Press **Send** and say what you are writing.

Works even better after **Brand kit** and **Marketing kit** (those notes attach when you have them).

## What's inside

| Kind | Use |
| ---- | --- |
| **Writing kit coach** | Plans and drafts with you step by step |
| **Research** | Writing guide (clarity, editing checklist, formats) |
| **output-*** | Long-form content and social captions saved in your vault |

## Example later

Attach only the **Writing guide** and paste a draft: *"Second-pass edit this announcement."*
