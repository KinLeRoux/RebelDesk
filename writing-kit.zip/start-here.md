---
type: note
title: Start here — Writing kit
category: Writing kit
tags: writing, content, start
searchable: true
---

# Writing kit

Newsletters, blogs, social posts, case studies, and a clear editing pass — without wrestling with blank pages.

## Simple path

1. **Settings → Chat Settings → Memory packs** → install **Writing kit**.
2. Tap **Start in chat**.
3. Press **Send** and say what you are writing.

Works even better after **Brand kit** and **Marketing kit** (those notes attach when you have them).

## What’s inside

| Kind | Use |
| ---- | --- |
| **Writing kit coach** | Plans and drafts with you step by step |
| **Research** | Clear writing, editing checklist, email/social formats |
| **output-*** | Saved plans and drafts in your vault |

## Example later

Attach only **Editing pass checklist** and paste a draft: *“Second-pass edit this announcement.”*
