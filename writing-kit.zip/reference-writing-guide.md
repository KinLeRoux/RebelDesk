---
type: note
title: Writing guide (reference)
category: Writing kit
tags: writing, clarity, editing, formats, reference
searchable: true
---

# Writing guide (reference)

One guide for the **Writing kit coach** — clarity, editing, and format shapes.

## Part A — Clear and human writing

Goal: readers understand on first skim.

1. **One idea per paragraph.**
2. **Strong first line** — promise or tension, not throat-clearing.
3. **Write to one person** — "you," not "users" or "stakeholders."
4. **Cut filler:** very, really, in order to, it is important to note.
5. **Verbs over nouns:** "We improved speed" not "We implemented an improvement."
6. **Specific beats vague:** numbers, examples, timeframes when true.

**Structure:** hook → context → substance → CTA. Subheads every 3–5 short paragraphs. Bullets for 3+ items. Bold sparingly.

**Voice alignment:** if a voice guide exists, check words we love/avoid, formality, sentence length.

**Busy readers:** front-load the point; ~20 words per sentence average; one CTA at the end.

## Part B — Editing pass checklist

### Clarity
- [ ] First sentence earns the next
- [ ] Jargon removed or explained
- [ ] Every pronoun has a clear referent
- [ ] "So what?" — each section matters

### Structure
- [ ] Logical order · subheads match content · one main CTA

### Voice
- [ ] Matches brand voice guide · consistent tense · contractions match formality

### Credibility
- [ ] Claims have proof or [confirm] · no fake urgency · numbers verified

### Polish
- [ ] Typos · repeated words · cut 10–15% if fluffy

### Platform fit
- [ ] Length fits medium · subject + preview (email) · descriptive link labels

**Ask:** "Run this checklist on my draft. List top 5 fixes, then show a revised version."

## Part C — Email, blog & social formats

### Newsletter (one issue)

| Element | Guidance |
| ------- | -------- |
| Subject | 40–50 chars; curiosity + benefit |
| Preview | Complements subject |
| Body | 1 main idea; 3–5 short sections |
| CTA | One primary link |
| Length | ~400–800 words B2B; shorter for consumers |

**Structure:** subject options → hook → teach/story → proof (optional) → CTA.

### Blog post

| Element | Guidance |
| ------- | -------- |
| Title | Clear benefit or question |
| Intro | Problem or promise in 3 sentences |
| H2 sections | 3–7 typical |
| Length | 800–1,500 words typical |

### Social (approximate)

| Platform | Notes |
| -------- | ----- |
| LinkedIn | First 2 lines = hook; ~1,300 char max; line breaks |
| Instagram | First line = hook; ~2,200 max |
| Facebook | Short question or story |
| X | ~280 punchy; thread optional |

**Caption batch:** vary story, tip, proof, question, CTA — same message, different angles. Mode 1 → `output-long-form-content.md`. Mode 3 → `output-social-captions.md`.
