---
type: note
title: Case study — output template
category: Writing kit
tags: case study, story, output
searchable: true
---

# Case study — output template

_Filled in by the Writing kit coach (Mode 4)._

## Client (name or anonymized label)

## Industry / situation

## Challenge (before)

## Approach (what we did)

## Results (after)

| Metric | Before | After |
| ------ | ------ | ----- |
| | | |

## Quote

> “[Confirm with client before publishing]”
> — Name, role

## Key takeaway (one sentence)

## CTA

## Approval checklist

- [ ] Client approved names and numbers
- [ ] Legal / compliance OK
