---
type: note
title: Social and email formats (reference)
category: Writing kit
tags: email, social, formats, reference
searchable: true
---

# Social and email formats (reference)

Practical lengths and shapes — not platform algorithm theory.

## Email newsletter (one issue)

| Element | Guidance |
| ------- | -------- |
| Subject | 40–50 chars ideal; curiosity + benefit |
| Preview | Complements subject; no repeat |
| Opening | 1–2 sentences — why read now |
| Body | 1 main idea; 3–5 short sections max |
| CTA | One primary button or link |
| Length | ~400–800 words for busy B2B; shorter for consumers |

**Structure:** Subject options → hook → teach/story → proof (optional) → CTA → sign-off.

## Blog post

| Element | Guidance |
| ------- | -------- |
| Title | Clear benefit or question (not clickbait) |
| Intro | Problem or promise in 3 sentences |
| H2 sections | 3–7 for a standard post |
| Conclusion | Recap + one next step |
| Length | 800–1,500 words typical; longer only if teaching |

## Social (approximate)

| Platform | Hook | Body | Notes |
| -------- | ---- | ---- | ----- |
| LinkedIn | First 2 lines visible | ~1,300 char max post | Line breaks for skim |
| Instagram caption | First line = hook | ~2,200 max | Hashtags 3–8 if used |
| Facebook | Short question or story | Variable | Conversational |
| X / Twitter | ~280 (or long post) | Punchy one-liner + thread optional | |

## Caption batch pattern

For one campaign, vary: **story, tip, proof, question, CTA** — same message, different angles.

## Prompts alone

- “Three subject lines for a newsletter about [topic].”  
- “LinkedIn post from this blog intro — under 1,200 characters.”  
- “Five Instagram captions for [offer], mix hooks.”

Pair with **reference-writing-clear-and-human.md**.
