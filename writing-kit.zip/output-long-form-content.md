---
type: note
title: Long-form content — output template
category: Writing kit
tags: newsletter, blog, case study, output
searchable: true
---

# Long-form content — output template

_Filled by the Writing kit coach (Mode 1). Newsletter, blog post, or case study — pick one format per session._

## Format chosen

<!-- newsletter | blog | case study -->

## Audience & goal

**Who:** · **After reading they will:**

---

## Newsletter section

**Send date / issue #:** · **One big idea:**

### Subject line options

1. · 2. · 3.

**Preview text:**

### Outline

1. · 2. · 3.

### Draft

**Opening:** · **Body:** · **CTA:**

**Links / assets needed:**

---

## Blog section

**Working title:** · **Question this answers (SEO-style):**

### Outline

**Introduction** · **H2 sections:** 1. · 2. · 3. · **Conclusion**

### Draft

_(paste or write below)_

**Meta description (~155 chars):** · **Internal links / CTAs:**

---

## Case study section

**Client (name or anonymized):** · **Industry / situation:**

**Challenge (before):** · **Approach (what we did):**

### Results (after)

| Metric | Before | After |
| ------ | ------ | ----- |
| | | |

**Quote:** > "[Confirm with client]" — Name, role

**Key takeaway:** · **CTA:**

**Approval:** [ ] Client approved names/numbers · [ ] Legal / compliance OK
