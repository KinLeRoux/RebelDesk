---
type: note
title: Newsletter issue — output template
category: Writing kit
tags: newsletter, email, output
searchable: true
---

# Newsletter issue — output template

_Filled in by the Writing kit coach (Mode 1)._

## Send date / issue #

## Audience reminder

## One big idea

## Subject line options

1.
2.
3.

## Preview text

## Outline

1.
2.
3.

## Draft

### Opening

### Body

### CTA

## Links / assets needed
