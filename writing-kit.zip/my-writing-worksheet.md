---
type: note
title: My writing worksheet
category: Writing kit
tags: writing, worksheet
searchable: true
---

# My writing worksheet

## Topic backlog

| Idea | Format | Priority |
| ---- | ------ | -------- |
| | | |

## Defaults

**Primary audience:**

**Default CTA:**

**Tone (3 words):**

## Current piece

**Format:**

**Deadline:**

**Raw notes:**

## Session log

| Date | Output file | Status |
| ---- | ----------- | ------ |
| | | |
