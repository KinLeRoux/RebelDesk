---
type: note
title: Editing pass checklist (reference)
category: Writing kit
tags: editing, checklist, reference
searchable: true
---

# Editing pass checklist (reference)

Second-pass editing — attach with a draft or use with **Writing kit coach** Mode 5.

## 1. Clarity

- [ ] First sentence earns the next sentence  
- [ ] Jargon removed or explained in plain words  
- [ ] Every pronoun has a clear referent  
- [ ] “So what?” — each section matters to the reader  

## 2. Structure

- [ ] Logical order (no surprises before context)  
- [ ] Subheads match content (skimmable)  
- [ ] One main CTA (not competing asks)  

## 3. Voice

- [ ] Sounds like the brand voice guide (if any)  
- [ ] Consistent tense (usually present or simple past)  
- [ ] Contractions match intended formality  

## 4. Credibility

- [ ] Claims have proof or are marked [confirm]  
- [ ] No fake urgency or invented testimonials  
- [ ] Numbers and names verified or flagged  

## 5. Polish

- [ ] Typos and grammar  
- [ ] Repeated words in adjacent sentences  
- [ ] Cut 10–15% word count if still fluffy  

## 6. Platform fit

- [ ] Length fits medium (email / blog / social)  
- [ ] Subject line + preview text (email)  
- [ ] Link labels descriptive (“Read the guide” not “Click here”)  

## How to ask the AI

> Run this checklist on my draft. List top 5 fixes, then show a revised version.
