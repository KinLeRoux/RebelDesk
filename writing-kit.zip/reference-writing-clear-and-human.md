---
type: note
title: Writing clear and human (reference)
category: Writing kit
tags: writing, clarity, reference
searchable: true
---

# Writing clear and human (reference)

For the **Writing kit coach** or any chat. Goal: readers understand on first skim.

## Core rules

1. **One idea per paragraph.**  
2. **Strong first line** — promise or tension, not throat-clearing.  
3. **Write to one person** — “you,” not “users” or “stakeholders.”  
4. **Cut filler:** very, really, in order to, it is important to note.  
5. **Verbs over nouns:** “We improved speed” not “We implemented an improvement.”  
6. **Specific beats vague:** numbers, examples, timeframes when true.

## Structure patterns

- **Hook → context → substance → CTA** (email, post, page section).  
- **Subheads every 3–5 short paragraphs** for long pieces.  
- **Bullets** for lists of 3+ items.  
- **Bold** sparingly — key phrase only.

## Voice alignment

If a voice guide exists, check: words we love/avoid, formal vs casual, sentence length.

## Accessibility for busy readers

- Front-load the point (don’t bury the lede).  
- Max ~20 words per sentence on average for general audiences.  
- One question or CTA at the end — not five.

## Prompts alone

- “Make this 30% shorter without losing meaning.”  
- “Rewrite for a tired parent, not a marketing committee.”  
- “Add a stronger opening line — three options.”
