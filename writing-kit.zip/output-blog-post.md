---
type: note
title: Blog post — output template
category: Writing kit
tags: blog, output
searchable: true
---

# Blog post — output template

_Filled in by the Writing kit coach (Mode 2)._

## Working title

## Reader & goal

**Who:**

**After reading they will:**

## SEO-style topic (plain words)

**Question this answers:**

## Outline

### Introduction

### H2 sections

1.
2.
3.

### Conclusion

## Draft

_(paste or write below)_

## Meta description (optional, ~155 chars)

## Internal links / CTAs
