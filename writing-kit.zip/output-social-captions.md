---
type: note
title: Social captions — output template
category: Writing kit
tags: social, captions, output
searchable: true
---

# Social captions — output template

_Filled in by the Writing kit coach (Mode 3)._

## Campaign / theme

## Platform(s)

## Offer or link

## Caption batch

| # | Platform | Hook / caption | CTA | Notes |
| - | -------- | -------------- | --- | ----- |
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |

## Hashtags (if used)

## Image / creative notes
