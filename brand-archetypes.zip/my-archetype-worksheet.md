---
type: note
title: My archetype worksheet
category: Brand archetypes
tags: archetypes, worksheet
searchable: true
---

# My archetype worksheet

## Quick picks

**Brands I admire (and why):**

**Brands that feel wrong for us:**

**Party description (3 words):**

**Customer fear / frustration:**

**Transformation we deliver:**

## My gut feeling

**Archetype I’m drawn to:**

**Archetype that feels wrong:**

## Coach recommendation (fill during session)

**Primary:**

**Secondary:**

**Why:**

## Notes

---

## Session log

| Date | Decision |
| ---- | -------- |
|      |          |
