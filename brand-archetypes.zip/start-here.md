---
type: note
title: Start here — Brand archetypes
category: Brand archetypes
tags: archetypes, brand, start
searchable: true
---

# Start here — Brand archetypes

Archetypes give your brand a **character** people remember — like casting a lead role in a story, not picking a logo font.

Open **Chat**, attach **Brand archetypes coach** (crown icon), and say:

> **Help me find our brand archetype.**

Best if you already did **Build your brand** or **Your brand voice** — the coach will use those notes.

## What you will end up with

- **Primary + secondary archetype** (with plain reasons)
- A short **character profile** (how you show up in ads, email, social)
- Example lines you can paste into real work

## Tips

- There is no “wrong” archetype — only fit.
- Most brands blend **two** (e.g. Caregiver + Sage for health education).
- Use **The 12 archetypes — reference** if you want to browse names yourself.

## After your profile is done

Ask:

- “Write a homepage hero as our primary archetype.”
- “Would this caption sound like our character? Fix it.”
- “Give me three campaign ideas that match our archetype mix.”
