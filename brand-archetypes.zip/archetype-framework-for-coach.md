---
type: note
title: Archetype framework (for the coach)
category: Brand archetypes
tags: archetypes, framework, coach
searchable: true
---

# Archetype framework (for the coach)

Internal only — short cues for scoring fit.

## Map customer tension → archetype

| Tension | Lean toward |
| ------- | ----------- |
| Fear, vulnerability | Caregiver, Innocent |
| Stuck, need push | Hero, Magician |
| Bored, routine | Explorer, Jester |
| Confused, need truth | Sage |
| Status, quality | Ruler, Lover |
| Oppressed by system | Outlaw |
| Want to make | Creator |

## Red flags (mismatch)

- Caregiver brand using aggressive Outlaw hype
- Ruler brand using silly Jester on serious claims
- Sage brand with no proof / overselling Magician transformation
- Innocent brand with fear‑based urgency tactics

## Scoring questions (mental)

1. Does the archetype match **proof** they actually have?
2. Does it match **audience** self‑image (not only founder taste)?
3. Can they sustain this voice for **12 months** of content?

## Vault integration

- Pull audience, promise, adjectives from `DeskMemory-packs/brand-discovery/`
- Pull word lists and channel rules from `DeskMemory-packs/voice-and-tone/`
- Output should not contradict voice guide — reconcile or note “voice tweak suggested”

## Next pack to suggest (one)

- Visual identity brief (mood, colors in words)
- Campaign brief builder
