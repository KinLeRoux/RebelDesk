---
type: note
title: Start here — Wellness & habits kit
category: Wellness & habits kit
tags: personal, wellness, start
searchable: true
---

# Start here — Wellness & habits kit

Habits, gentle movement, sleep, and stress routines — **not** medical treatment. One reference guide; **output-habit-plan.md** links to **Hobbies & learning kit**. For meals and recipes, use **Personal & life kit**.

Install → **Start in chat** → pick a mode.
