---
type: note
title: My wellness worksheet
category: Wellness & habits kit
tags: personal, wellness, worksheet
searchable: true
---

# My wellness worksheet

## Energy (1–5)

## Sleep quality

## One habit I want

## Notes
