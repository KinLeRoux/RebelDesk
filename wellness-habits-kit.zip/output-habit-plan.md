---
type: note
title: Habit plan — output template
category: Wellness & habits kit
tags: habits, output, personal
searchable: true
---

# Habit plan — output template

## Habit (tiny version)

## After [trigger], I will…

## Environment setup

## Track how

## If I miss a day

## Review date (2 weeks)
