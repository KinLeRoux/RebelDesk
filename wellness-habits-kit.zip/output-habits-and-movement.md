---
type: note
title: Habits and movement — output template
category: Wellness & habits kit
tags: habits, movement, output, personal
searchable: true
---

# Habits and movement — output template

## Habit (tiny version)

### After [trigger], I will…

### Environment setup

### Track how

### If I miss a day

### Review date (2 weeks)

---

## Weekly movement plan

### Starting point

| Day | Plan | Done? |
| --- | ---- | ----- |
| Mon | | |
| Tue | | |
| Wed | | |
| Thu | | |
| Fri | | |
| Sat | | |
| Sun | | |

### Progression rule

### Safety note
