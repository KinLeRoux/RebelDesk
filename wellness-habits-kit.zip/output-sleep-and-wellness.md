---
type: note
title: Sleep and wellness — output template
category: Wellness & habits kit
tags: sleep, wellness, output, personal
searchable: true
---

# Sleep and wellness — output template

## Sleep routine

### Target wake time

### Target lights-out

### Wind-down (30–60 min)

1.
2.
3.

### Morning anchor

### Screen / caffeine rules

### When to get professional help

---

## Wellness check-in

### Date

### Energy / mood (1–5)

### Sleep

### Movement this week

### Stress level

### Wins

### One tweak next week

### Stress reset tools that work for me
