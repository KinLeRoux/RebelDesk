---
type: note
title: Wellness guide (reference)
category: Wellness & habits kit
tags: habits, movement, sleep, stress, personal, reference
searchable: true
---

# Wellness guide (reference)

Sustainable habits, gentle movement, sleep, and stress routines. **Not medical advice** — chronic pain, eating disorders, or medication questions → healthcare provider.

## Habit design

### Tiny habit formula

**After [existing routine], I will [tiny action].**

Examples: After morning coffee, I will stretch 2 minutes. After dinner, I will walk to the mailbox.

### Make it easy

- Environment prep (shoes by door, water bottle filled)  
- **Two-minute** version counts as success  
- Stack on something you already do daily

### Track simply

Checkbox calendar or one sentence journal — not complex apps unless they want one.

### Relapse is normal

Missed days ≠ failure. Rule: **never miss twice in a row** (optional).  
Shrink the habit before quitting.

### Avoid

- Five new habits at once  
- All-or-nothing (“gym 6 days” with zero history)  
- Shame-based motivation

---

## Movement basics

**Not** a training program for athletes — sustainable activity for everyday life.

### Weekly structure (gentle)

| Day | Idea |
| --- | ---- |
| Most days | 20–30 min walk or equivalent |
| 2× week | Strength-ish (bodyweight, bands, carry groceries counts) |
| 1× week | Longer easy session or rest |

### Progression

Add **10% time or effort** per week max. If sore or tired, repeat last week.

### Options by starting point

- **Sedentary:** 5–10 min walks after meals  
- **Some activity:** 3× structured + daily steps  
- **Already active:** focus recovery and variety, not more volume blindly

### Safety

Stop if sharp pain, dizziness, chest pain — medical help.  
Warm up 3–5 min; cool down stretch optional.

### Pair with Personal & life kit

Meal energy and travel walking goals — not duplicate recipe coaching here.

---

## Sleep and stress

Lifestyle ideas only — **not** treatment for insomnia, anxiety disorders, or trauma.

### Sleep hygiene (practical)

- Same **wake time** ±30 min daily  
- Dim lights 1 hour before bed  
- Cool, dark room; phone out of bed or night mode  
- Caffeine cutoff ~8 hours before sleep (adjust personally)  
- If awake 20+ min, get up briefly, boring activity, return when sleepy

### Wind-down menu (pick 1–2)

- Stretch, shower, fiction, breathing (4-7-8), journal dump worries on paper

### Stress reset (5–15 min)

- Walk outside  
- Box breathing  
- Name 5 things you see  
- Message a friend (not doom-scroll)

### When to seek help

Snoring + daytime sleepiness, panic attacks, stress blocking work/parenting for weeks — clinician.
